@extends('admin.layout')

@section('content')
    <div class="content">
        <div class="row">
            <div class="col-lg-12">
                <div class="card card-default">
                    <div class="card-header card-header-border-bottom">
                        <h2>Users</h2>
                    </div>
                    <div class="card-body">
                        @include('admin.partials.flash')
                        <table class="table table-bordered table-striped">
                            <thead>
                                <th>No.</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Created At</th>
                                <!-- <th>Action</th> -->
                            </thead>
                            <tbody>
                                @forelse ($workers as $worker)
                                    <tr>
                                        <td>{{ $worker->id }}</td>
                                        <td>{{ $worker->name }}</td>
                                        <td>{{ $worker->email }}</td>
                                        <td>{{ $worker->roles->implode('name', ', ') }}</td>
                                        <td>{{ $worker->created_at }}</td>
                                        <!-- <td> -->
                                        <!-- @if (!$worker->hasRole('Admin'))
                                            @can('edit_categories')
                                                <a href="{{ url('admin/workers/'. $worker->id .'/edit') }}" class="btn btn-warning btn-sm">edit</a>
                                            @endcan

                                            @can('delete_categories')
                                                {!! Form::open(['url' => 'admin/workers/'. $worker->id, 'class' => 'delete', 'style' => 'display:inline-block']) !!}
                                                {!! Form::hidden('_method', 'DELETE') !!}
                                                {!! Form::submit('remove', ['class' => 'btn btn-danger btn-sm']) !!}
                                                {!! Form::close() !!}
                                            @endcan
                                        @endif -->
                                        <!-- </td> -->
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="6">No records found</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                        {{ $users->links() }}
                    </div>

                    @can('add_workers')
                        <div class="card-footer text-right">
                            <a href="{{ url('admin/workers/create') }}" class="btn btn-primary">Add New</a>
                        </div>
                    @endcan
                </div>
            </div>
        </div>
    </div>
@endsection

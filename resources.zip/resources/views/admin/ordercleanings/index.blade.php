@extends('admin.layout')

@section('content')
	<div class="content">
		<div class="row">
			<div class="col-lg-12">
				<div class="card card-default">
					<div class="card-header card-header-border-bottom">
						<h2>Order Cleanings</h2>
					</div>
					<div class="card-body">
						@include('admin.partials.flash')
						@include('admin.ordercleanings.filter')
						<table class="table table-bordered table-striped">
							<thead>
								<th>Order Cleaning ID</th>
								<th>Grand Total</th>
								<th>Name</th>
								<th>Status</th>
								<th>Payment</th>
								<th>Action</th>
							</thead>
							<tbody>
								@forelse ($ordercleanings as $ordercleaning)
									<tr>
										<td>
											{{ $ordercleaning->code }}<br>
											<span style="font-size: 12px; font-weight: normal"> {{\General::datetimeFormat($ordercleaning->ordercleaning_date) }}</span>
										</td>
										<td>{{\General::priceFormat($ordercleaning->grand_total) }}</td>
										<td>
											{{ $ordercleaning->customer_full_name }}<br>
											<span style="font-size: 12px; font-weight: normal"> {{ $ordercleaning->customer_email }}</span>
										</td>
										<td>{{ $ordercleaning->status }}</td>
										<td>{{ $ordercleaning->payment_status }}</td>
										<td>
											@can('edit_ordercleanings')
												<a href="{{ url('admin/ordercleanings/'. $ordercleaning->id) }}" class="btn btn-info btn-sm">show</a>
											@endcan
										</td>
									</tr>
								@empty
									<tr>
										<td colspan="5">No records found</td>
									</tr>
								@endforelse
							</tbody>
						</table>
						{{ $ordercleanings->links() }}
					</div>
				</div>
			</div>
		</div>
	</div>
@endsection

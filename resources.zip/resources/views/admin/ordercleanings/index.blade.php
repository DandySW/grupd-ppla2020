@extends('admin.layout')

@section('content')
<div class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-default">
        <div class="card-header card-header-border-bottom">
          <h2>Order Cleaning Service</h2>
        </div>
        <div class="card-body">
          @include('admin.partials.flash')
          <table class="table table-bordered table-striped">
            <thead>
              <th>No.</th>
              <th>Paket</th>
              <th>Price</th>
              <th>Status</th>
              <th style="width:15%">Action</th>
            </thead>
            <tbody>

            </tbody>
          </table>

        </div>

        <div class="card-footer text-right">
          <a href="#" class="btn btn-primary">Add New</a>
        </div>

      </div>
    </div>
  </div>
</div>
@endsection

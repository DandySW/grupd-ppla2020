@extends('admin.layout')

@section('content')
<div class="content">
    <div class="row">
        <div class="col-lg-6">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom">
                    <h2>Cancel Order Cleaning #{{ $ordercleaning->code }}</h2>
                </div>
                <div class="card-body">
                    @include('admin.partials.flash', ['$errors' => $errors])
                    {!! Form::model($ordercleaning, ['url' => ['admin/ordercleanings/cancel', $ordercleaning->id], 'method' => 'PUT']) !!}
                    {!! Form::hidden('id') !!}
                    <div class="form-group">
                        {!! Form::label('cancellation_note', 'Cancellation Note') !!}
                        {!! Form::textarea('cancellation_note', null, ['class' => 'form-control']) !!}
                    </div>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Cancel the Order Cleaning</button>
                        <a href="{{ url('admin/ordercleanings') }}" class="btn btn-secondary btn-default">Back</a>
                    </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom">
                    <h2>Detail Order Cleaning</h2>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6">
                            <p class="text-dark mb-2" style="font-weight: normal; font-size:16px; text-transform: uppercase;">Billing Address</p>
                            <address>
                                {{ $ordercleaning->customer_first_name }} {{ $ordercleaning->customer_last_name }}
                                <br> {{ $ordercleaning->customer_address1 }}
                                <br> {{ $ordercleaning->customer_address2 }}
                                <br> Email: {{ $ordercleaning->customer_email }}
                                <br> Phone: {{ $ordercleaning->customer_phone }}
                                <br> Postcode: {{ $ordercleaning->customer_postcode }}
                            </address>
                        </div>
                        <div class="col-xl-6 col-lg-6">
                            <p class="text-dark mb-2" style="font-weight: normal; font-size:16px; text-transform: uppercase;">Details</p>
                            <address>
                                ID: <span class="text-dark">#{{ $ordercleaning->code }}</span>
                                <br> {{ \General::datetimeFormat($ordercleaning->$ordercleaning_date) }}
                                <br> Status: {{ $ordercleaning->status }}
                                <br> Payment Status: {{ $ordercleaning->payment_status }}
                                <br> Shipped by: {{ $ordercleaning->shipping_service_name }}
                            </address>
                        </div>
                    </div>
                    <table class="table mt-3 table-striped table-responsive table-responsive-large" style="width:100%">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Item</th>
                                <th>Qty</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($ordercleaning->orderCleaningItems as $item)
                                <tr>
                                    <td>{{ $item->sku }}</td>
                                    <td>{{ $item->name }}</td>
                                    <td>{{ $item->qty }}</td>
                                    <td>{{ \General::priceFormat($item->sub_total) }}</td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="6">Order cleaning item not found!</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                    <div class="row justify-content-end">
                        <div class="col-lg-5 col-xl-6 col-xl-3 ml-sm-auto">
                            <ul class="list-unstyled mt-4">
                                <li class="mid pb-3 text-dark">Subtotal
                                    <span class="d-inline-block float-right text-default">{{ \General::priceFormat($ordercleaning->base_total_price) }}</span>
                                </li>
                                <li class="mid pb-3 text-dark">Tax(10%)
                                    <span class="d-inline-block float-right text-default">{{ \General::priceFormat($ordercleaning->tax_amount) }}</span>
                                </li>
                                <li class="mid pb-3 text-dark">Shipping Cost
                                    <span class="d-inline-block float-right text-default">{{ \General::priceFormat($ordercleaning->shipping_cost) }}</span>
                                </li>
                                <li class="pb-3 text-dark">Total
                                    <span class="d-inline-block float-right">{{ \General::priceFormat($ordercleaning->grand_total) }}</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

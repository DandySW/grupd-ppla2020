@extends('admin.layout')

@section('content')
<div class="content">
	<div class="invoice-wrapper rounded border bg-white py-5 px-3 px-md-4 px-lg-5">
		<div class="d-flex justify-content-between">
			<h2 class="text-dark font-weight-medium">Order Cleaning ID #{{ $ordercleaning->code }}</h2>
			<!-- <div class="btn-group">
				<button class="btn btn-sm btn-secondary">
					<i class="mdi mdi-content-save"></i> Save</button>
				<button class="btn btn-sm btn-secondary">
					<i class="mdi mdi-printer"></i> Print</button>
			</div> -->
		</div>
		<div class="row pt-5">
			<div class="col-xl-4 col-lg-4">
				<p class="text-dark mb-2" style="font-weight: normal; font-size:16px; text-transform: uppercase;">Billing Address</p>
				<address>
					{{ $ordercleaning->customer_first_name }} {{ $ordercleaning->customer_last_name }}
					<br> {{ $ordercleaning->customer_address1 }}
					<br> {{ $ordercleaning->customer_address2 }}
					<br> Email: {{ $ordercleaning->customer_email }}
					<br> Phone: {{ $ordercleaning->customer_phone }}
					<br> Postcode: {{ $ordercleaning->customer_postcode }}
				</address>
			</div>
			<div class="col-xl-4 col-lg-4">
				<p class="text-dark mb-2" style="font-weight: normal; font-size:16px; text-transform: uppercase;">Shipment Address</p>
				<address>
					{{ $ordercleaning->shipment->first_name }} {{ $ordercleaning->shipment->last_name }}
					<br> {{ $ordercleaning->shipment->address1 }}
					<br> {{ $ordercleaning->shipment->address2 }}
					<br> Email: {{ $ordercleaning->shipment->email }}
					<br> Phone: {{ $ordercleaning->shipment->phone }}
					<br> Postcode: {{ $ordercleaning->shipment->postcode }}
				</address>
			</div>
			<div class="col-xl-4 col-lg-4">
				<p class="text-dark mb-2" style="font-weight: normal; font-size:16px; text-transform: uppercase;">Details</p>
				<address>
					ID: <span class="text-dark">#{{ $ordercleaning->code }}</span>
					<br> {{ \General::datetimeFormat($ordercleaning->ordercleaning_date) }}
					<br> Status: {{ $ordercleaning->status }} {{ $ordercleaning->isCancelled() ? '('. \General::datetimeFormat($ordercleaning->cancelled_at) .')' : null}}
					@if ($ordercleaning->isCancelled())
						<br> Cancellation Note : {{ $ordercleaning->cancellation_note}}
					@endif
					<br> Payment Status: {{ $ordercleaning->payment_status }}
					<br> Shipped by: {{ $ordercleaning->shipping_service_name }}
				</address>
			</div>
		</div>
		<table class="table mt-3 table-striped table-responsive table-responsive-large" style="width:100%">
			<thead>
				<tr>
					<th>#</th>
					<th>Item</th>
					<th>Description</th>
					<th>Quantity</th>
					<th>Unit Cost</th>
					<th>Total</th>
				</tr>
			</thead>
			<tbody>
				@forelse ($ordercleaning->orderCleaningItems as $item)
					<tr>
						<td>{{ $item->sku }}</td>
						<td>{{ $item->name }}</td>
						<td>{!! \General::showAttributesCleaning($item->attributescleaning) !!}</td>
						<td>{{ $item->qty }}</td>
						<td>{{ \General::priceFormat($item->base_price) }}</td>
						<td>{{ \General::priceFormat($item->sub_total) }}</td>
					</tr>
				@empty
					<tr>
						<td colspan="6">Order cleaning item not found!</td>
					</tr>
				@endforelse
			</tbody>
		</table>
		<div class="row justify-content-end">
			<div class="col-lg-5 col-xl-4 col-xl-3 ml-sm-auto">
				<ul class="list-unstyled mt-4">
					<li class="mid pb-3 text-dark">Subtotal
						<span class="d-inline-block float-right text-default">{{ \General::priceFormat($ordercleaning->base_total_price) }}</span>
					</li>
					<li class="mid pb-3 text-dark">Tax(10%)
						<span class="d-inline-block float-right text-default">{{ \General::priceFormat($ordercleaning->tax_amount) }}</span>
					</li>
					<li class="mid pb-3 text-dark">Shipping Cost
						<span class="d-inline-block float-right text-default">{{ \General::priceFormat($ordercleaning->shipping_cost) }}</span>
					</li>
					<li class="pb-3 text-dark">Total
						<span class="d-inline-block float-right">{{ \General::priceFormat($ordercleaning->grand_total) }}</span>
					</li>
				</ul>
				@if (!$ordercleaning->trashed())
					@if ($ordercleaning->isPaid() && $ordercleaning->isConfirmed())
						<a href="{{ url('admin/shipments/'. $ordercleaning->shipment->id .'/edit')}}" class="btn btn-block mt-2 btn-lg btn-primary btn-pill"> Procced to Shipment</a>
					@endif

					@if (in_array($ordercleaning->status, [\App\Models\OrderCleaning::CREATED, \App\Models\OrderCleaning::CONFIRMED]))
						<a href="{{ url('admin/ordercleanings/'. $ordercleaning->id .'/cancel')}}" class="btn btn-block mt-2 btn-lg btn-warning btn-pill"> Cancel</a>
					@endif

					@if ($ordercleaning->isDelivered())
						<a href="#" class="btn btn-block mt-2 btn-lg btn-success btn-pill" onclick="event.preventDefault();
						document.getElementById('complete-form-{{ $ordercleaning->id }}').submit();"> Mark as Completed</a>

						{!! Form::open(['url' => 'admin/ordercleanings/complete/'. $ordercleaning->id, 'id' => 'complete-form-'. $ordercleaning->id, 'style' => 'display:none']) !!}
						{!! Form::close() !!}
					@endif

					@if (!in_array($ordercleaning->status, [\App\Models\OrderCleaning::DELIVERED, \App\Models\OrderCleaning::COMPLETED]))
						<a href="#" class="btn btn-block mt-2 btn-lg btn-secondary btn-pill delete" ordercleaning-id="{{ $ordercleaning->id }}"> Remove</a>

						{!! Form::open(['url' => 'admin/ordercleanings/'. $ordercleaning->id, 'class' => 'delete', 'id' => 'delete-form-'. $ordercleaning->id, 'style' => 'display:none']) !!}
						{!! Form::hidden('_method', 'DELETE') !!}
						{!! Form::close() !!}
					@endif
				@else
					<a href="{{ url('admin/ordercleanings/restore/'. $ordercleaning->id)}}" class="btn btn-block mt-2 btn-lg btn-outline-secondary btn-pill restore"> Restore</a>
					<a href="#" class="btn btn-block mt-2 btn-lg btn-danger btn-pill delete" order-id="{{ $ordercleaning->id }}"> Remove Permanently</a>

					{!! Form::open(['url' => 'admin/ordercleanings/'. $ordercleaning->id, 'class' => 'delete', 'id' => 'delete-form-'. $ordercleaning->id, 'style' => 'display:none']) !!}
					{!! Form::hidden('_method', 'DELETE') !!}
					{!! Form::close() !!}
				@endif
			</div>
		</div>
	</div>
</div>
@endsection

@extends('admin.layout')

@section('content')
<div class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-default">
        <div class="card-header card-header-border-bottom">
          <h2>Order Cleaning Services</h2>
        </div>
        <div class="col-lg-8 sm-2">
          <form class="form-inline" method="GET">
            <div class="form-group mx-sm-2 mb-2">
              <input name="keyword" type="text" class="form-control" placeholder="Nama Petugas">
            </div>
            <button type="submit" class="btn btn-primary mb-2">Search</button>
          </form>
        </div>
        <div class="card-body">
          @include('admin.partials.flash')
          <table class="table table-bordered table-striped">
            <thead>
              <th>No.</th>
              <!-- <th>Aksi Petugas</th> -->
              <th>Aksi</th>
              <th>Waktu</th>
              <th>Nama</th>
              <th>Alamat</th>
              <th>No. HP</th>
              <th>Petugas</th>
              <th>Paket</th>
              <th>Bukti Pembayaran</th>
              <!-- <th>Info</th>
              <th>Aksi</th> -->
              <!-- <th>Status Petugas</th> -->
              <th>Status</th>
            </thead>
            <tbody>
              @foreach ($ordercleanings as $item)
                  <tr>
                      <td>{{ $loop->iteration }}</td>
                      <!-- <td>
                        @if($item->status_verifikasi == 0)
                        <a href="{{ url('admin/dashboard/' . $item->id) }}" class="btn btn-sm btn-danger">Non-Aktifkan</a>
                        @else
                        <a href="{{ url('admin/dashboard/' . $item->id) }}" class="btn btn-sm btn-success">Aktifkan</a>
                        @endif
                      </td> -->
                      <td>
                        @if($item->status_verifikasi == 1)
                        <a href="{{ url('admin/dashboard/' . $item->id) }}" class="btn btn-sm btn-danger">x</a>
                        @else
                        <a href="{{ url('admin/dashboard/' . $item->id) }}" class="btn btn-sm btn-success">✓</a>
                        @endif
                      </td>
                      <td>
												<span>{{\General::datetimeFormat($item->order_date) }}</span>
											</td>
                      <td>{{ $item->first_name }} {{ $item->last_name }}</td>
                      <td>{{ $item->address1 }}</td>
                      <td>{{ $item->phone }}</td>
                      <td>{{ $item->petugas }}</td>
                      <td>{{ $item->paket }}</td>
                      <td>
                        <a href="{{ asset('uploads/pembayaran/'.$item->image) }}" target="_blank" rel="noopener noreferrer">Lihat Bukti</a>
                      </td>
                      <!-- <td>{{ $item->info }}</td>
                      <td>
                        @if ($item->info == null)
                        <a href="{{ url('admin/dashboards/pilih/'. $item->id) }}" class="btn btn-warning btn-sm">Pilih</a>
                        @endif
                      </td> -->
                      <!-- <td><span class="badge {{ ($item->status_verifikasi == 1 ? 'badge-success' : 'badge-danger') }}">{{ ($item->status_verifikasi == 1) ? 'Kerja' : 'Tidak Kerja' }}</span></td> -->
                      <td><span class="badge {{ ($item->status_verifikasi == 0 ? 'badge-danger' : 'badge-success') }}">{{ ($item->status_verifikasi == 1) ? 'Telah Diverifikasi' : 'Belum Diverifikasi' }}</span></td>
                  </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

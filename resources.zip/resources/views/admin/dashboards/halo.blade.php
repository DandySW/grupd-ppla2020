@extends('admin.layout')

@section('content')
<div class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-default">
        <div class="card-header card-header-border-bottom">
          <h2>Order Cleaning Services</h2>
        </div>
        <div class="card-body">
          @include('admin.partials.flash')
          <table class="table table-bordered table-striped">
            <thead>
              <th>No.</th>
              <th>Nama</th>
              <th>Alamat</th>
              <th>No. HP</th>
              <th>Petugas</th>
              <th>Paket</th>
              <th>Bukti Pembayaran</th>
              <th>Info</th>
              <th>Aksi</th>
            </thead>
            <tbody>
              @foreach ($ordercleanings as $item)
                  <tr>
                      <td>{{ $loop->iteration }}</td>
                      <td>{{ $item->first_name }} {{ $item->last_name }}</td>
                      <td>{{ $item->address1 }}</td>
                      <td>{{ $item->phone }}</td>
                      <td>{{ $item->petugas }}</td>
                      <td>{{ $item->paket }}</td>
                      <td>
                        <a href="{{ asset('uploads/pembayaran/'.$item->image) }}" target="_blank" rel="noopener noreferrer">Lihat Bukti</a>
                      </td>
                      <td>{{ $item->info }}</td>
                      <td>
                        @if ($item->info == null)
                        <a href="{{ url('admin/dashboards/pilih/'. $item->id) }}" class="btn btn-warning btn-sm">Pilih</a>
                        @endif
                      </td>
                  </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

@extends('admin.layout')

@section('content')
<div class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-default">
        <div class="card-header card-header-border-bottom">
          <h2>Detail Bukti Pembayaran</h2>
        </div>
        <div class="card-body">
          @include('admin.partials.flash')

            <thead>
              <th>Bukti Pembayaran</th>
            </thead>
            <tbody>

            </tbody>

        </div>
      </div>
    </div>
  </div>
</div>
@endsection

@extends('admin.layout')

@section('content')

<div class="content">
  <div class="row">
    <div class="col-lg-9">
      <div class="card card-default">
        <div class="card-header card-header-border-bottom">
          <h2>Order Cleaning Service</h2>
        </div>
        <div class="card-body">
          <form action="{{ route('simpankirim') }}" method="POST" enctype="multipart/form-data">
            {{ csrf_field() }}
          <div class="form-group">
            <label>Nama</label>
            <input type="text" id="first_name" name="first_name" class="form-control" value="{{ $ordercleanings->first_name }}">
          </div>
          <div class="form-group">
            <label>Alamat</label>
            <input type="text" id="address1" name="address1" class="form-control" value="{{ $ordercleanings->address1 }}">
          </div>
          <div class="form-group">
            <label>No. HP</label>
            <input type="text" id="phone" name="phone" class="form-control" value="{{ $ordercleanings->phone }}">
          </div>
          <div class="form-group">
            <label>Petugas</label>
            <input type="text" id="" name="" class="form-control" value="#">
          </div>
          <div class="form-group">
            <label>Info</label>
            <input type="text" id="info" name="info" class="form-control">
          </div>
          <div class="form-footer pt-5 border-top">
            <button type="submit" class="btn btn-primary btn-default">Save</button>
          </div>
        </form>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

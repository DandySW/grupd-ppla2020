@extends('admin.layout')

@section('content')

<h3>Page Dashboard</h3>

@stop

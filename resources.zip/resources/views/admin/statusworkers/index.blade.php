@extends('admin.layout')

@section('content')
<div class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-default">
        <div class="card-header card-header-border-bottom">
          <h2>Petugas Layanan Kebersihan</h2>
        </div>
        <div class="card-body">
          @include('admin.partials.flash')
          <table class="table table-bordered table-striped">
            <thead>
              <th>No.</th>
              <th>Aksi</th>
              <th>Name</th>
              <th>Email</th>
              <th>Created At</th>
              <th>Status</th>
            </thead>
            <tbody>
              @foreach ($workers as $worker)
              <tr>
                <td>{{ $worker->id }}</td>
                <td>
                  @if($worker->status == 0)
                  <a href="{{ url('admin/statusworkers/' . $worker->id) }}" class="btn btn-sm btn-danger">x</a>
                  @else
                  <a href="{{ url('admin/statusworkers/' . $worker->id) }}" class="btn btn-sm btn-success">✓</a>
                  @endif
                </td>
                <td>{{ $worker->first_name }} {{ $worker->last_name }}</td>
                <td>{{ $worker->email }}</td>
                <td>{{ $worker->created_at }}</td>
                <td><span class="badge {{ ($worker->status == 1 ? 'badge-danger' : 'badge-success') }}">{{ ($worker->status == 0) ? 'Aktif' : 'Tidak Aktif' }}</span></td>
              </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

@extends('admin.layout')

@section('content')

@php
    $formTitle = !empty($cleaning) ? 'Update' : 'New'
@endphp

<div class="content">
    <div class="row">
        <div class="col-lg-3">

        </div>
        <div class="col-lg-9">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom">
                        <h2>{{ $formTitle }} Cleaning</h2>
                </div>
                <div class="card-body">
                    @include('admin.partials.flash', ['$errors' => $errors])
                    @if (!empty($cleaning))
                        {!! Form::model($cleaning, ['url' => ['admin/cleanings', $cleaning->id], 'method' => 'PUT']) !!}
                        {!! Form::hidden('id') !!}
                        {!! Form::hidden('type') !!}
                    @else
                        {!! Form::open(['url' => 'admin/cleanings']) !!}
                    @endif
                        <div class="form-group">
                            {!! Form::label('name', 'Paket') !!}
                            {!! Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'name']) !!}
                        </div>
                                @include('admin.cleanings.simple')

                            <div class="form-group">
                                {!! Form::label('status', 'Status') !!}
                                {!! Form::select('status', $statuses , null, ['class' => 'form-control', 'placeholder' => '-- Set Status --']) !!}
                            </div>

                        <div class="form-footer pt-5 border-top">
                            <button type="submit" class="btn btn-primary btn-default">Save</button>
                            <a href="{{ url('admin/cleanings') }}" class="btn btn-secondary btn-default">Back</a>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

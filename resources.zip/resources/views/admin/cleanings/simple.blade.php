<div class="row">
    <div class="col-md-4">
        <div class="form-group">
            {!! Form::label('price', 'Price') !!}
            {!! Form::text('price', null, ['class' => 'form-control', 'placeholder' => 'price']) !!}
        </div>
    </div>
</div>

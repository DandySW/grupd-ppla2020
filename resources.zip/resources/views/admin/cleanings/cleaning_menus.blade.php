<div class="card card-default">
    <div class="card-header card-header-border-bottom">
        <h2>Cleaning Menus</h2>
    </div>
    <div class="card-body">
        <nav class="nav flex-column">
            <a class="nav-link" href="{{ url('admin/cleanings/'. $cleaningID .'/edit') }}">Cleaning Detail</a>
            <a class="nav-link" href="{{ url('admin/cleanings/'. $cleaningID .'/images') }}">Cleaning Images</a>
        </nav>
    </div>
</div>

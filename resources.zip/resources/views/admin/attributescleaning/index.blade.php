@extends('admin.layout')

@section('content')
    <div class="content">
        <div class="row">
            <div class="col-lg-12">
                <div class="card card-default">
                    <div class="card-header card-header-border-bottom">
                        <h2>Attributes Cleaning</h2>
                    </div>
                    <div class="card-body">
                        @include('admin.partials.flash')
                        <table class="table table-bordered table-striped">
                            <thead>
                                <th>#</th>
                                <th>Code</th>
                                <th>Name</th>
                                <th>Type</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                @forelse ($attributescleaning as $attributecleaning)
                                    <tr>
                                        <td>{{ $attributecleaning->id }}</td>
                                        <td>{{ $attributecleaning->code }}</td>
                                        <td>{{ $attributecleaning->name }}</td>
                                        <td>{{ $attributecleaning->type }}</td>
                                        <td>
                                            @can('edit_attributescleaning')
                                                <a href="{{ url('admin/attributescleaning/'. $attributecleaning->id .'/edit') }}" class="btn btn-warning btn-sm">edit</a>
                                            @endcan

                                            @can('add_attributescleaning')
                                                @if ($attributecleaning->type == 'select')
                                                <a href="{{ url('admin/attributescleaning/'. $attributecleaning->id .'/options') }}" class="btn btn-success btn-sm">options</a>
                                                @endif
                                            @endcan

                                            @can('delete_attributescleaning')
                                                {!! Form::open(['url' => 'admin/attributescleaning/'. $attributecleaning->id, 'class' => 'delete', 'style' => 'display:inline-block']) !!}
                                                {!! Form::hidden('_method', 'DELETE') !!}
                                                {!! Form::submit('remove', ['class' => 'btn btn-danger btn-sm']) !!}
                                                {!! Form::close() !!}
                                            @endcan
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5">No records found</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                        {{ $attributescleaning->links() }}
                    </div>
                    @can('add_attributescleaning')
                        <div class="card-footer text-right">
                            <a href="{{ url('admin/attributescleaning/create') }}" class="btn btn-primary">Add New</a>
                        </div>
                    @endcan
                </div>
            </div>
        </div>
    </div>
@endsection

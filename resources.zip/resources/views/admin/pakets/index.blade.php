@extends('admin.layout')

@section('content')
<div class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-default">
        <div class="card-header card-header-border-bottom">
          <h2>Ketentuan Paket</h2>
        </div>
        <div class="card-body">
          <div class="form-group">
            <label>Isi Ketentuan</label>
            <textarea class="form-control" readonly="true">
            @foreach ($ketentuans as $item)
              {{ $item->isi }}
            @endforeach
          </textarea>
          </div>
          <div class="text-right">
            <a href="{{ url('admin/pakets/edit/' . $item->id) }}" class="btn btn-warning btn-sm">Edit</a>
          </div>
        </div>
      </div>
      </form>
    </div>
  </div>
</div>
@endsection

@extends('admin.layout')

@section('content')
<div class="content">
  <div class="row">
    <div class="col-lg-9">
      <div class="card card-default">
        <div class="card-header card-header-border-bottom">
          <h2>Update Form</h2>
        </div>
        <div class="card-body">
          <form action="{{ url('admin/pakets/' . $ketentuans->id) }}" method="POST">
            @method('put')
            @csrf
          <div class="form-group">
            <label>Ketentuan Paket</label>
            <textarea name="isi" class="form-control" maxlength="10000" required>"{{ $ketentuans->isi }}"</textarea>
          </div>
          <div class="form-footer pt-5 border-top">
            <button type="submit" class="btn btn-primary btn-default">Save</button>
          </div>
        </form>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

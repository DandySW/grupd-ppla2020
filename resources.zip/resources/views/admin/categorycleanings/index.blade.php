@extends('admin.layout')

@section('content')
    <div class="content">
        <div class="row">
            <div class="col-lg-12">
                <div class="card card-default">
                    <div class="card-header card-header-border-bottom">
                        <h2>Category Cleanings</h2>
                    </div>
                    <div class="card-body">
                        @include('admin.partials.flash')
                        <table class="table table-bordered table-striped">
                            <thead>
                                <th>No.</th>
                                <th>Name</th>
                                <th>Slug</th>
                                <th>Parent</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                @forelse ($categorycleanings as $categorycleaning)
                                    <tr>
                                        <td>{{ $categorycleaning->id }}</td>
                                        <td>{{ $categorycleaning->name }}</td>
                                        <td>{{ $categorycleaning->slug }}</td>
                                        <td>{{ $categorycleaning->parent ? $categorycleaning->parent->name : '' }}</td>
                                        <td>

                                                <a href="{{ url('admin/categorycleanings/'. $categorycleaning->id .'/edit') }}" class="btn btn-warning btn-sm">edit</a>


                                            <!-- @can('delete_categorycleanings')
                                                {!! Form::open(['url' => 'admin/categorycleanings/'. $categorycleaning->id, 'class' => 'delete', 'style' => 'display:inline-block']) !!}
                                                {!! Form::hidden('_method', 'DELETE') !!}
                                                {!! Form::submit('remove', ['class' => 'btn btn-danger btn-sm']) !!}
                                                {!! Form::close() !!}
                                            @endcan -->
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5">No records found</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                        {{ $categorycleanings->links() }}
                    </div>

                        <div class="card-footer text-right">
                            <a href="{{ url('admin/categorycleanings/create') }}" class="btn btn-primary">Add New</a>
                        </div>

                </div>
            </div>
        </div>
    </div>
@endsection

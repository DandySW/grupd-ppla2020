@component('mail::message')
# Thank you for your order!

Your order is on-hold until we confirm payment has been received. Your order details are shown below for your reference:

## OrderCleaning #{{ $ordercleaning->code }} ({{\General::datetimeFormat($ordercleaning->ordercleaning_date)}})

@component('mail::table')
| Cleaning       | Quantity      | Price  |
| ------------- |:-------------:| --------:|
@foreach ($ordercleaning->orderCleaningItems as $item)
| {{ $item->name }}      |  {{ $item->qty }}      | {{ \General::priceFormat($item->sub_total) }}      |
@endforeach
| &nbsp;         | <strong>Sub total</strong> | {{ \General::priceFormat($ordercleaning->base_total_price) }} |
| &nbsp;         | Tax (10%)     | {{ \General::priceFormat($ordercleaning->tax_amount) }} |
| &nbsp;         | Shipping cost | {{ \General::priceFormat($ordercleaning->shipping_cost) }} |
| &nbsp;         | <strong>Total</strong> | <strong>{{ \General::priceFormat($ordercleaning->grand_total) }}</strong>|
@endcomponent

## Billing Details:
<strong>{{ $ordercleaning->customer_first_name }} {{ $ordercleaning->customer_last_name }}</strong>
<br> {{ $ordercleaning->customer_address1 }}
<br> {{ $ordercleaning->customer_address2 }}
<br> Email: {{ $ordercleaning->customer_email }}
<br> Phone: {{ $ordercleaning->customer_phone }}
<br> Postcode: {{ $ordercleaning->customer_postcode }}

## Shipment Address (shipped by: {{ $ordercleaning->shipping_service_name }}):
<strong>{{ $ordercleaning->shipment->first_name }} {{ $ordercleaning->shipment->last_name }}</strong>
<br> {{ $ordercleaning->shipment->address1 }}
<br> {{ $ordercleaning->shipment->address2 }}
<br> Email: {{ $ordercleaning->shipment->email }}
<br> Phone: {{ $ordercleaning->shipment->phone }}
<br> Postcode: {{ $ordercleaning->shipment->postcode }}

@component('mail::button', ['url' => url('ordercleanings/received/'. $ordercleaning->id)])
Show order detail
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent

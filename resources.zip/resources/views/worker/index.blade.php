@extends('worker.layout')

@section('content')
<div class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-default">
        <div class="card-header card-header-border-bottom">
          <h2>Order Cleaning Services</h2>
        </div>
        <div class="card-body">
          <div class="alert alert-info">
            Klik <a href="{{ url('worker/ketentuanpaket') }}"><strong>disini</strong></a> untuk melihat ketentuan paket.
            </div>
          @include('admin.partials.flash')
          <table class="table table-bordered table-striped">
            <thead>
              <th>No.</th>
              <th>Waktu</th>
              <th>Nama</th>
              <th>Alamat</th>
              <th>No. HP</th>
              <th>Petugas</th>
              <th>Paket</th>
              <th>Status</th>
            </thead>
            <tbody>
              @foreach ($konfirmasi as $item)
                  <tr>
                      <td>{{ $loop->iteration }}</td>
                      <td>{{ $item->order_date }}</td>
                      <td>{{ $item->first_name }} {{ $item->last_name }}</td>
                      <td>{{ $item->address1 }}</td>
                      <td>{{ $item->phone }}</td>
                      <td>{{ $item->petugas }}</td>
                      <td>{{ $item->paket }}</td>
                      <td><span class="badge {{ ($item->status_verifikasi == 0 ? 'badge-danger' : 'badge-success') }}">{{ ($item->status_verifikasi == 1) ? 'Telah Diverifikasi' : 'Belum Diverifikasi' }}</span></td>
                  </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

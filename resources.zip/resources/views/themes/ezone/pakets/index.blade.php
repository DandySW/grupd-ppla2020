@extends('themes.ezone.layout')

@section('content')
<div class="content">
  <div class="row justify-content-center">
    <div class="col-lg-8">
      <div class="card card-default">
        <div class="card-body">
          @include('themes.ezone.partials.flash')
          <h4 class="row justify-content-center"><strong>Ketentuan Paket</strong></h4>
              @foreach ($ketentuans as $item)
                <textarea readonly>{{$item->isi}}</textarea>
              @endforeach
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

@extends('themes.ezone.layout')

@section('content')

<!-- checkout-area start -->
<div class="checkout-area ptb-100">
	<div class="container">
		@include('admin.partials.flash', ['$errors' => $errors])

		{!! Form::model($user, ['url' => 'paymentcleanings']) !!}
		<div class="alert alert-info">
			<p>
				Silahkan melakukan pembayaran sebesar Rp. {{ number_format($price) }} ke BANK MANDIRI 137-001088-3276 An. Admin Sipakan
			</p>
		</div>
		<div class="row">
			<div class="col-lg-6 col-md-12 col-12">
				<div class="checkbox-form">
					<h3>Billing Carts</h3>
					<div class="row">
						<div class="col-md-6">
							<div class="checkout-form-list">
								<label>First Name <span class="required">*</span></label>
								{!! Form::text('first_name', null, ['readonly' => true, 'required' => true]) !!}
							</div>
						</div>
						<div class="col-md-6">
							<div class="checkout-form-list">
								<label>Last Name <span class="required">*</span></label>
								{!! Form::text('last_name', null, ['required' => true]) !!}
							</div>
						</div>
						<div class="col-md-12">
							<div class="checkout-form-list">
								<label>Address <span class="required">*</span></label>
								{!! Form::text('address1', null, ['readonly' => true, 'required' => true, 'placeholder' => 'Home number and
								street name']) !!}
							</div>
						</div>
						<div class="col-md-6">
							<div class="checkout-form-list">
								<label>Phone <span class="required">*</span></label>
								{!! Form::text('phone', null, ['readonly' => true, 'required' => true, 'placeholder' => 'Phone']) !!}
							</div>
						</div>
						<div class="col-md-6">
							<div class="checkout-form-list">
								<label>Email Address </label>
								{!! Form::text('email', null, ['required' => true, 'placeholder' => 'Email', 'readonly' => true]) !!}
							</div>
						</div>
						<div class="col-md-6">
							<div class="checkout-form-list">
								<label>Petugas </label>
								{{-- {!! Form::text('petugas', null, ['required' => true, 'placeholder' => 'Petugas', 'readonly' => true]) !!} --}}
								<input type="text" name="petugas"
									value="{{ $petugas->first_name }} {{ $petugas->last_name }}" placeholder="Petugas"
									readonly>
							</div>
						</div>
						<div class="col-md-6">
							<div class="checkout-form-list">
								<label>Paket </label>
								{{-- {!! Form::text('paket', null, ['required' => true, 'placeholder' => 'Paket', 'readonly' => true]) !!} --}}
								<input type="text" name="paket"
									value="{{ $paket->name }}" placeholder="Paket"
									readonly>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-12 col-12">
				<div class="your-order">
					<h3>Your order</h3>
					<div class="your-order-table table-responsive">
						<table>
							<tfoot>
								<tr class="order-total">
									<th>Order Total</th>
									<td><strong><span class="total-amount">{{ number_format($price) }}</span></strong>
									</td>
								</tr>
							</tfoot>
						</table>
					</div>
					<div class="payment-method">
						<div class="payment-accordion">
							<div class="order-button-payment">
								<input type="submit" value="bayar sekarang" />
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		{!! Form::close() !!}
	</div>
</div>
<!-- checkout-area end -->
@endsection

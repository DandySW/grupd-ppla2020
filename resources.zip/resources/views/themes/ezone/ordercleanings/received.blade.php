@extends('themes.ezone.layout')

@section('content')

	<!-- checkout-area start -->
	<div class="cart-main-area  ptb-100">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					@include('admin.partials.flash', ['$errors' => $errors])
					<h1 class="cart-heading">Your Order:</h4>
					<div class="row">
						<div class="col-xl-3 col-lg-4">
							<p class="text-dark mb-2" style="font-weight: normal; font-size:16px; text-transform: uppercase;">Billing Address</p>
							<address>
								{{ $ordercleaning->customer_first_name }} {{ $ordercleaning->customer_last_name }}
								<br> {{ $ordercleaning->customer_address1 }}
								<br> {{ $ordercleaning->customer_address2 }}
								<br> Email: {{ $ordercleaning->customer_email }}
								<br> Phone: {{ $ordercleaning->customer_phone }}
								<br> Postcode: {{ $ordercleaning->customer_postcode }}
							</address>
						</div>
						<div class="col-xl-3 col-lg-4">
							<p class="text-dark mb-2" style="font-weight: normal; font-size:16px; text-transform: uppercase;">Shipment Address</p>
							<address>
								{{ $ordercleaning->shipment->first_name }} {{ $ordercleaning->shipment->last_name }}
								<br> {{ $ordercleaning->shipment->address1 }}
								<br> {{ $ordercleaning->shipment->address2 }}
								<br> Email: {{ $ordercleaning->shipment->email }}
								<br> Phone: {{ $ordercleaning->shipment->phone }}
								<br> Postcode: {{ $ordercleaning->shipment->postcode }}
							</address>
						</div>
						<div class="col-xl-3 col-lg-4">
							<p class="text-dark mb-2" style="font-weight: normal; font-size:16px; text-transform: uppercase;">Details</p>
							<address>
								Invoice ID:
								<span class="text-dark">#{{ $ordercleaning->code }}</span>
								<br> {{ \General::datetimeFormat($ordercleaning->ordercleaning_date) }}
								<br> Status: {{ $ordercleaning->status }}
								<br> Payment Status: {{ $ordercleaning->payment_status }}
								<br> Shipped by: {{ $ordercleaning->shipping_service_name }}
							</address>
						</div>
					</div>
					<div class="table-content table-responsive">
						<table class="table mt-3 table-striped table-responsive table-responsive-large" style="width:100%">
							<thead>
								<tr>
									<th>#</th>
									<th>Item</th>
									<th>Description</th>
									<th>Quantity</th>
									<th>Unit Cost</th>
									<th>Total</th>
								</tr>
							</thead>
							<tbody>
								@forelse ($ordercleaning->orderCleaningItems as $item)
									<tr>
										<td>{{ $item->sku }}</td>
										<td>{{ $item->name }}</td>
										<td>{!! \General::showAttributesCleaning($item->attributescleaning) !!}</td>
										<td>{{ $item->qty }}</td>
										<td>{{ \General::priceFormat($item->base_price) }}</td>
										<td>{{ \General::priceFormat($item->sub_total) }}</td>
									</tr>
								@empty
									<tr>
										<td colspan="6">Order item not found!</td>
									</tr>
								@endforelse
							</tbody>
						</table>
					</div>
					<div class="row">
						<div class="col-md-5 ml-auto">
							<div class="cart-page-total">
								<ul>
									<li> Subtotal
										<span>{{ \General::priceFormat($ordercleaning->base_total_price) }}</span>
									</li>
									<li>Tax (10%)
										<span>{{ \General::priceFormat($ordercleaning->tax_amount) }}</span>
									</li>
									<li>Shipping Cost
										<span>{{ \General::priceFormat($ordercleaning->shipping_cost) }}</span>
									</li>
									<li>Total
										<span>{{ \General::priceFormat($ordercleaning->grand_total) }}</span>
									</li>
								</ul>
								@if (!$ordercleaning->isPaid())
									<a href="{{ $ordercleaning->payment_url }}">Proceed to payment</a>
								@endif
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
@endsection

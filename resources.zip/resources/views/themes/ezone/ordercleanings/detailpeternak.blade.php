@extends('themes.ezone.layout')

@section('content')

<!-- shopping-cart-area start -->
<div class="cart-main-area pt-95 pb-100">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h3 class="cart-heading">Order Cleaning Services</h3>
				<div class="table-content table-responsive">
					<table>
						<thead>
							<tr>
								<th>No.</th>
								<th>Waktu</th>
								<th>Petugas</th>
								<th>Bukti Pembayaran</th>
								<th>Konfirmasi Tugas</th>
							</tr>
						</thead>
						<tbody>
              @foreach ($ordercleanings as $item)
                  <tr>
                      <td>{{ $loop->iteration }}</td>
											<td>
												<span>{{\General::datetimeFormat($item->order_date) }}</span>
											</td>
											<td>{{ $item->petugas }}</td>
                      <td>
                        <a href="{{ asset('uploads/pembayaran/'.$item->image) }}" target="_blank" rel="noopener noreferrer">Lihat Gambar</a>
                      </td>
											<td>
												<button class="btn btn-warning"data-toggle="modal" data-target="#selesai" id="Konf" onclick="myFunction()">Konfirmasi Selesai</button>
                   <!-- openmodal -->
                    <div class="modal fade" id="selesai" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
								      <div class="modal-dialog  modal-dialog-centered" role="document">
								        <div class="modal-content">
								          <div class="modal-header">
								            <h5 class="modal-title" id="exampleModalLabel">Peringatan!</h5>
								          </div>
								          <div class="modal-body">“Apakah Anda yakin ingin menyelesaikan status pekerjaan petugas kebersihan?”</div>
								          <div class="modal-footer">
								            <button class="btn btn-secondary" type="button" data-dismiss="modal">Tidak</button>
								            <form method="post" action="{{url('detailpeternak/'.$item->id)}}">
								             {{csrf_field()}}
								             	<input name="status" hidden="" readonly="" value="0">
								            	<button class="btn btn-primary" type="submit" id="Btn">Ya</button>
															<!-- <script>
															document.getElementById("Konf").addEventListener("click", myFunction);

															function myFunction() {
															    document.getElementById('Konf').disabled = true;
															}
															</script> -->
								            </form>
								          </div>
								        </div>
								      </div>
								    </div>
    							<!-- end modal -->
										</td>
                  </tr>
              @endforeach
						</tbody>
					</table>
				</div>
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="coupon-all">
						</div>
					</div>
				</div>
				{!! Form::close() !!}
			</div>
		</div>
	</div>
</div>
<!-- shopping-cart-area end -->
@endsection

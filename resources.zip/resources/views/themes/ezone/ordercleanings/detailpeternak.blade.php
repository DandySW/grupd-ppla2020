@extends('themes.ezone.layout')

@section('content')

<!-- shopping-cart-area start -->
<div class="cart-main-area pt-95 pb-100">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h3 class="cart-heading">Order Cleaning Services</h3>
				<div class="table-content table-responsive">
					<table>
						<thead>
							<tr>
								<th>No.</th>
								<th>Petugas</th>
								<th>Bukti Pembayaran</th>
							</tr>
						</thead>
						<tbody>
              @foreach ($ordercleanings as $item)
                  <tr>
                      <td>{{ $loop->iteration }}</td>
											<td>#</td>
                      <td>
                        <a href="{{ asset('uploads/pembayaran/'.$item->image) }}" target="_blank" rel="noopener noreferrer">Lihat Gambar</a>
                      </td>
                  </tr>
              @endforeach
						</tbody>
					</table>
				</div>
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="coupon-all">
						</div>
					</div>
				</div>
				{!! Form::close() !!}
			</div>
		</div>
	</div>
</div>
<!-- shopping-cart-area end -->
@endsection

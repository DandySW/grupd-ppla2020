@extends('themes.ezone.layout')

@section('content')
	<div class="shop-page-wrapper shop-page-padding ptb-100">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-3">
					@include('themes.ezone.partials.user_menu')
				</div>
				<div class="col-lg-9">
					<div class="d-flex justify-content-between">
						<h2 class="text-dark font-weight-medium">Order ID #{{ $ordercleaning->code }}</h2>
					</div>
					<div class="row pt-5">
						<div class="col-xl-4 col-lg-4">
							<p class="text-dark mb-2" style="font-weight: normal; font-size:16px; text-transform: uppercase;">Billing Address</p>
							<address>
								{{ $ordercleaning->customer_first_name }} {{ $ordercleaning->customer_last_name }}
								<br> {{ $ordercleaning->customer_address1 }}
								<br> {{ $ordercleaning->customer_address2 }}
								<br> Email: {{ $ordercleaning->customer_email }}
								<br> Phone: {{ $ordercleaning->customer_phone }}
							</address>
						</div>
						@if ($ordercleaning->shipment)
							<div class="col-xl-4 col-lg-4">
								<p class="text-dark mb-2" style="font-weight: normal; font-size:16px; text-transform: uppercase;">Shipment Address</p>

							</div>
						@endif
						<div class="col-xl-4 col-lg-4">
							<p class="text-dark mb-2" style="font-weight: normal; font-size:16px; text-transform: uppercase;">Carts</p>
							<address>
								ID: <span class="text-dark">#{{ $ordercleaning->code }}</span>
								<br> {{ \General::datetimeFormat($ordercleaning->order_date) }}
								<br> Status: {{ $ordercleaning->status }} {{ $ordercleaning->isCancelled() ? '('. \General::datetimeFormat($ordercleaning->cancelled_at) .')' : null}}
								@if ($ordercleaning->isCancelled())
									<br> Cancellation Note : {{ $ordercleaning->cancellation_note}}
								@endif
								<br> Payment Status: {{ $ordercleaning->payment_status }}
								<br> Shipped by: {{ $ordercleaning->shipping_service_name }}
							</address>
						</div>
					</div>
					<div class="table-content table-responsive">
						<table class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>#</th>
									<th>Item</th>
									<th>Description</th>
									<th>Quantity</th>
									<th>Unit Cost</th>
									<th>Total</th>
								</tr>
							</thead>
							<tbody>
								@forelse ($ordercleaning->orderCleans as $clean)
									<tr>
										<td>{{ $clean->sku }}</td>
										<td>{{ $clean->name }}</td>
										<td>{!! \General::showAttributes($clean->attributes) !!}</td>
										<td>{{ $clean->qty }}</td>
										<td>{{ \General::priceFormat($clean->base_price) }}</td>
										<td>{{ \General::priceFormat($clean->sub_total) }}</td>
									</tr>
								@empty
									<tr>
										<td colspan="6">Order item not found!</td>
									</tr>
								@endforelse
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
@endsection

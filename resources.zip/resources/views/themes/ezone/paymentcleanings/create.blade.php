 @extends('themes.ezone.layout')
 @section('content')

 <!-- checkout-area start -->
 <div class="checkout-area ptb-100">
 	<div class="container">
    @if ($errors->any())
    <div class="alert alert-danger">
      <ul>
        @foreach ($errors->all() as $error)
          <li>{{ $error }}</li>
        @endforeach
      </ul>
    </div>
    @endif

 		{!! Form::model($user, ['url' => ['/'], 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
    @csrf
 		<div class="alert alert-info">
 			<h5>
 				Silahkan upload bukti pembayaran Anda pada form yang tertera dibawah ini!
 			</h5>
 		</div>
 		<div class="row">
 			<div class="col-lg-6 col-md-12 col-12">
 				<div class="checkbox-form">
 					<div class="row">
 						<div class="col-md-6">
 							<div class="checkout-form-list">
 								<label>First Name <span class="required">*</span></label>
 								{!! Form::text('first_name', null, ['readonly' => true, 'required' => true]) !!}
 							</div>
 						</div>
 						<div class="col-md-6">
 							<div class="checkout-form-list">
 								<label>Last Name <span class="required">*</span></label>
 								{!! Form::text('last_name', null, ['readonly' => true, 'required' => true]) !!}
 							</div>
 						</div>
 						<div class="col-md-12">
 							<div class="checkout-form-list">
 								<label>Address <span class="required">*</span></label>
 								{!! Form::text('address1', null, ['readonly' => true, 'required' => true, 'placeholder' => 'Home number and
 								street name']) !!}
 							</div>
 						</div>
 						<div class="col-md-6">
 							<div class="checkout-form-list">
 								<label>Phone <span class="required">*</span></label>
 								{!! Form::text('phone', null, ['readonly' => true, 'required' => true, 'placeholder' => 'Phone']) !!}
 							</div>
 						</div>
 						<div class="col-md-6">
 							<div class="checkout-form-list">
 								<label>Email Address </label>
 								{!! Form::text('email', null, ['placeholder' => 'Email', 'readonly' => true]) !!}
 							</div>
 						</div>
            <div class="col-md-6">
							<div class="checkout-form-list">
								<label>Petugas </label>
								{{-- {!! Form::text('petugas', null, ['placeholder' => 'Petugas', 'readonly' => true]) !!} --}}
								<input type="text" name="petugas"
									value="{{ $petugas->first_name }} {{ $petugas->last_name }}" placeholder="Petugas"
									readonly>
							</div>
						</div>
            <div class="col-md-6">
							<div class="checkout-form-list">
								<label>Paket </label>
								{{-- {!! Form::text('paket', null, ['placeholder' => 'Paket', 'readonly' => true]) !!} --}}
								<input type="text" name="paket"
									value="{{ $paket->name }}" placeholder="Paket"
									readonly>
							</div>
						</div>
            <div class="col-md-6">
							<div class="checkout-form-list">
								<label hidden="">Id Petugas </label>
								{{-- {!! Form::text('user_id', null, ['placeholder' => 'Petugas', 'readonly' => true]) !!} --}}
								<input type="text" name="user_id" hidden=""
									value="{{ $petugas->id }}" placeholder="Petugas"
									readonly>
							</div>
						</div>
            <div class="col-md-6">
							<div class="checkout-form-list">
								<label hidden="">Status Verifikasi </label>
								{{-- {!! Form::text('status_verifikasi', null, ['placeholder' => 'Status Verifikasi', 'readonly' => true]) !!} --}}
								<input type="text" name="status_verifikasi" hidden=""
									value="{{ $status_verifikasi }}" placeholder="Status Verifikasi"
									readonly>
							</div>
						</div>
 					</div>
 				</div>
 			</div>
 			<div class="col-lg-6 col-md-12 col-12">
 				<div class="your-order">
 					<h5>Upload Bukti Pembayaran</h5>
 					<div class="your-order-table table-responsive">
 						<table>
 							<tfoot>
                  <input type="file" name="image">
 							</tfoot>
 						</table>
 					</div>
 				</div>
 			</div>
      <div class="payment-method">
        <div class="payment-accordion">
          <div class="order-button-payment">
            <button type="submit" name="submit" class="btn btn-primary">Kirim</button>
          </div>
        </div>
      </div>
 		</div>
 		{!! Form::close() !!}
 	</div>
 </div>
 <!-- checkout-area end -->
 @endsection

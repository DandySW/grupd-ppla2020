@extends('themes.ezone.layout')

@section('content')

@php
$formTitle = !empty($cleaning) ? 'Update' : 'New';
$disableInput = !empty($cleaning) ? true : false;
@endphp

<div class="content">
    <div class="row">
        <div class="col-lg-6">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom">
                    <h2>Pilih Paket & Petugas</h2>
                </div>
                <div class="card-body">
                    @include('themes.ezone.partials.flash', ['$errors' => $errors])
                    @if (!empty($cleaning))
                    {!! Form::model($attribute, ['url' => ['cleanings', $cleaning->id], 'method' => 'PUT']) !!}
                    {!! Form::hidden('id') !!}
                    @else
                    {!! Form::open(['url' => 'cleanings']) !!}
                    @endif
                    <fieldset class="form-group">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- <legend class="col-form-label pt-0">General</legend> -->
                                <!-- <div class="form-group">
                                        {!! Form::label('code', 'Code') !!}
                                        {!! Form::text('code', null, ['class' => 'form-control', 'readonly' => $disableInput]) !!}
                                    </div> -->
                                <!-- <div class="form-group">
                                        {!! Form::label('name', 'Name') !!}
                                        {!! Form::text('name', null, ['class' => 'form-control']) !!}
                                    </div> -->
                                <div class="form-group">

                                </div>
                                <div class="form-group">
                                    <select id="user" name="user">
                                        <option selected>Pilih Paket</option>
                                        @foreach($cleanings as $cleaning)
                                        <option value="{{$cleaning->id}}">{{$cleaning->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select id="user" name="user">
                                        <option selected>Pilih Petugas</option>
                                        @foreach($user_datas as $data)
                                        <option value="{{$data->id}}">{{$data->first_name}} {{$data->last_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">

                        </div>
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">

                        </div>
                    </fieldset>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Save</button>
                        <a href="{{ url('cleanings') }}" class="btn btn-secondary btn-default">Back</a>
                    </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@extends('themes.ezone.layout')

@section('content')

@php
$formTitle = !empty($cleaning) ? 'Update' : 'New';
$disableInput = !empty($cleaning) ? true : false;
@endphp

<div class="content">
    <div class="row">
        <div class="col-lg-6">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom">
                    <h2>Pilih Paket & Petugas</h2>
                </div>
                <div class="card-body">
                    <fieldset class="form-group">
                        <div class="row">
                            <div class="col-lg-12">
                                <form action="{{ url('cleanings/store')}}" method="POST">
                                    @csrf
                                    <div class="form-group">
                                        <label>Silahkan pilih paket yang Anda inginkan!</label>
                                        <select name="cleaning_id" class="form-control @error('cleaning_id') is-invalid @enderror">
                                          <option value="">- Pilih -</option>
                                            @foreach($cleanings as $cleann)
                                             <option value="{{ $cleann->id }}">{{$cleann->name}}</option>
                                            @endforeach
                                        </select>
                                        @error('cleaning_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Silahkan pilih petugas kebersihan yang Anda inginkan!</label>
                                        <select name="user_id" class="form-control @error('user_id') is-invalid @enderror">
                                            <option value="">- Pilih -</option>
                                            @foreach($user_datas as $data)
                                            <option value="{{ $data->id }}">{{$data->first_name}} {{$data->last_name}}</option>
                                            @endforeach
                                        </select>
                                        @error('user_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                            </div>
                        </div>
                    </fieldset>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-success">Save</button>
                    </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

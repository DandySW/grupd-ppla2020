@extends('themes.ezone.layout')

@section('content')

@php
$formTitle = !empty($cleaning) ? 'Update' : 'New';
$disableInput = !empty($cleaning) ? true : false;
@endphp

<div class="content">
  <div class="row justify-content-md-center">
    <div class="col-lg-6">
      <div class="alert alert-warning">
  			<h6><strong>Catatan :</strong></h6>
        <h6><strong>Jasa layanan kebersihan hanya tersedia di wilayah Kabupaten Jember, Jawa Timur. Apabila terjadi suatu hal diluar catatan, bukan tanggung jawab kami.</strong></h6>
  		</div>
        <!-- <li class="nav-item active">
          <a class="nav-link" href="/">Home <span class="sr-only">(current)</span></a>
        </li> -->
      <div class="card card-default">
        <div class="card-header card-header-border-bottom">
          <h4 class="row justify-content-center"><strong>PILIH PAKET DAN PETUGAS LAYANAN KEBERSIHAN</strong></h4>
        </div>
        <div class="card-body">
          <div class="alert alert-info">
            Klik <a href="{{ url('ketentuanpaket') }}"><strong>disini</strong></a> terlebih dahulu untuk melihat ketentuan paket.
            </div>
          <fieldset class="form-group">
            <div class="row">
              <div class="col-lg-12">
                <form action="{{ url('cleanings/store')}}" method="POST">
                  @csrf
                  <div class="form-group">
                    <label><strong>Silahkan pilih paket yang Anda inginkan!</strong></label>
                    <select name="cleaning_id" class="form-control @error('cleaning_id') is-invalid @enderror">
                      <option value="">- Pilih Paket -</option>
                      @foreach($cleanings as $cleann)
                      <option value="{{ $cleann->id }}">{{$cleann->name}}</option>
                      @endforeach
                    </select>
                    @error('cleaning_id')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                  </div>
                  <div class="form-group">
                    <label><strong>Silahkan pilih petugas kebersihan yang Anda inginkan!</strong></label>
                    <select name="user_id" class="form-control @error('user_id') is-invalid @enderror">
                      <option value="">- Pilih Petugas -</option>
                      @foreach($user_datas as $data)
                      <option value="{{ $data->id }}">{{$data->first_name}} {{$data->last_name}}</option>
                      @endforeach
                    </select>
                    @error('user_id')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                  </div>
                </div>
              </div>
            </fieldset>
            <div class="form-footer pt-5 border-top">
              <button type="submit" class="btn btn-success">Save</button>
            </div>
            {!! Form::close() !!}
          </div>
        </div>
      </div>
    </div>
  </div>
  @endsection

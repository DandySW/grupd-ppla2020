@extends('themes.ezone.layout')

@section('content')

@php
    $formTitle = !empty($attribute) ? 'Update' : 'New';
    $disableInput = !empty($attribute) ? true : false;
@endphp

<div class="content">
    <div class="row">
        <div class="col-lg-6">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom">
                        <h2>Pilih Paket & Petugas</h2>
                </div>
                <div class="card-body">
                    @include('themes.ezone.partials.flash', ['$errors' => $errors])
                    @if (!empty($attribute))
                        {!! Form::model($attribute, ['url' => ['cleanings', $attribute->id], 'method' => 'PUT']) !!}
                        {!! Form::hidden('id') !!}
                    @else
                        {!! Form::open(['url' => 'cleanings']) !!}
                    @endif
                        <fieldset class="form-group">
                            <div class="row">
                                <div class="col-lg-12">
                                    <!-- <legend class="col-form-label pt-0">General</legend> -->
                                    <!-- <div class="form-group">
                                        {!! Form::label('code', 'Code') !!}
                                        {!! Form::text('code', null, ['class' => 'form-control', 'readonly' => $disableInput]) !!}
                                    </div> -->
                                    <!-- <div class="form-group">
                                        {!! Form::label('name', 'Name') !!}
                                        {!! Form::text('name', null, ['class' => 'form-control']) !!}
                                    </div> -->
                                    <div class="form-group">

                                    </div>
                                    <div class="form-group">
                                      <select id="user" name="user">
                                        <option selected>Pilih Pekerja</option>
                                        @foreach($user_datas as $data)
                                        <option value="{{$data->id}}">{{$data->role}}</option>
                                          @endforeach
                                      </select>

                                    </div>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset class="form-group">
                            <div class="row">

                            </div>
                        </fieldset>
                        <fieldset class="form-group">
                                <div class="row">

                                </div>
                            </fieldset>
                        <div class="form-footer pt-5 border-top">
                            <button type="submit" class="btn btn-primary btn-default">Save</button>
                            <a href="{{ url('cleanings') }}" class="btn btn-secondary btn-default">Back</a>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

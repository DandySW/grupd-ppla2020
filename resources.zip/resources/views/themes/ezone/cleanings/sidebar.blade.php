<div class="shop-sidebar mr-50">
    <form method="GET" action="{{ url('cleanings')}}">

    </form>

    @if ($categorycleanings)
		<div class="sidebar-widget mb-45">
			<h3 class="sidebar-title">Categories Cleaning</h3>
			<div class="sidebar-categories">
				<ul>
					@foreach ($categorycleanings as $categorycleaning)
							<li><a href="{{ url('cleanings?categorycleaning='. $categorycleaning->slug) }}">{{ $categorycleaning->name }}</a></li>
					@endforeach
				</ul>
			</div>
		</div>
	@endif
</div>

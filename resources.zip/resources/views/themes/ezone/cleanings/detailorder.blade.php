@extends('themes.ezone.layout')

@section('content')

	<!-- shopping-cart-area start -->
	<div class="cart-main-area pt-95 pb-100">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<h1 class="cart-heading">Detail Order Cleaning</h1>
						<div class="table-content table-responsive">
							<table>
								<thead>
									<tr>
										<th>Paket</th>
										<th>Price</th>
										<th>Petugas</th>
										<th>Total</th>
									</tr>
								</thead>
								<tbody>
									@forelse ($cleaning as $clean)
											<tr>
													<td>{{ $clean->name }}</td>
													<td>{{ number_format($clean->price) }}</td>
													<td>#</td>
													<td>{{ number_format($clean->price) }}</td>
											</tr>
									@empty
											<tr>
													<td colspan="7">No records found</td>
											</tr>
									@endforelse
								</tbody>
							</table>
						</div>
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="coupon-all">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-5 ml-auto">
								<div class="cart-page-total">
									<!-- <h2>Cart totals</h2> -->
									<!-- <ul>
										<li>Subtotal<span>{{ number_format(\Cart::getSubTotal()) }}</span></li>
										<li>Total<span>{{ number_format(\Cart::getTotal()) }}</span></li>
									</ul> -->
									<a href="{{ url('orders/checkout') }}">Proceed to checkout</a>
								</div>
							</div>
						</div>
					{!! Form::close() !!}
				</div>
			</div>
		</div>
	</div>
	<!-- shopping-cart-area end -->
@endsection

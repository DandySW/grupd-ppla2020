@extends('themes.ezone.layout')

@section('content')

<!-- shopping-cart-area start -->
<div class="cart-main-area pt-95 pb-100">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h1 class="cart-heading">Detail Order Cleaning</h1>
				<div class="table-content table-responsive">
					<table>
						<thead>
							<tr>
								<th>Paket</th>
								<th>Price</th>
								<th>Petugas</th>
								<th hidden="">Status Verifikasi</th>
							</tr>
						</thead>
						<tbody>
							{{-- @foreach ($detailorder as $detail) --}}
							<tr>
								<td name="paket">{{ $detail->name }}</td>
								<td name="price">{{ number_format($detail->price) }}</td>
								<td name="petugas">{{ $detail->first_name }} {{ $detail->last_name }}</td>
								<td name="status_verifikasi" hidden="">{{ $detail->status_verifikasi }}</td>
							</tr>
							{{-- @endforeach --}}
						</tbody>
					</table>
				</div>
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="coupon-all">
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-5 ml-auto">
						<div class="cart-page-total">
							<h2>Total</h2>
							<ul>
								<li>Subtotal<span>{{ number_format($detail->price) }}</span></li>
							</ul>
							<a href="{{ url('ordercleanings/checkout') }}">Proceed to checkout</a>

							<!-- <form action="{{ url('cleanings') }}" method="post">
							{{csrf_field()}}
							<input type="number" name="status" value="0" readonly="" hidden="">
							<button class="btn btn-primary" type="submit">Batal Pesan</button> -->

						</div>
					</div>
				</div>
				{!! Form::close() !!}
			</div>
		</div>
	</div>
</div>
<!-- shopping-cart-area end -->
@endsection

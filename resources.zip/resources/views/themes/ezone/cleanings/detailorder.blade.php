@extends('themes.ezone.layout')

@section('content')

	<!-- shopping-cart-area start -->
	<div class="cart-main-area pt-95 pb-100">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<h1 class="cart-heading">Detail Order Cleaning</h1>
						<div class="table-content table-responsive">
							<table>
								<thead>
									<tr>
										<th>Paket</th>
										<th>Price</th>
										<th>Total</th>
										<th>Petugas</th>
									</tr>
								</thead>
								<tbody>
									@foreach ($cleanings as $clean)
											<tr>
													<td value="{{$clean->id}}">{{ $clean->name }}</td>
													<td value="{{$clean->id}}">{{ number_format($clean->price) }}</td>
													<td value="{{$clean->id}}">{{ number_format($clean->price) }}</td>
									@foreach ($user_datas as $user)
													<td value="{{$user->id}}">{{ $user->first_name }} {{ $user->last_name }}</td>
									@endforeach
											</tr>
									@endforeach
								</tbody>
							</table>
						</div>
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="coupon-all">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-5 ml-auto">
								<div class="cart-page-total">
									<!-- <h2>Cart totals</h2> -->
									<!-- <ul>
										<li>Subtotal<span>{{ number_format(\Cart::getSubTotal()) }}</span></li>
										<li>Total<span>{{ number_format(\Cart::getTotal()) }}</span></li>
									</ul> -->
									<a href="{{ url('cleanings/checkout') }}">Proceed to checkout</a>
								</div>
							</div>
						</div>
					{!! Form::close() !!}
				</div>
			</div>
		</div>
	</div>
	<!-- shopping-cart-area end -->
@endsection

<div class="col-lg-12">
    <div class="product-wrapper mb-30 single-product-list product-list-right-pr mb-60">
        <div class="product-img list-img-width">
            <a href="{{ url('cleaning/'. $cleaning->slug) }}">
                @if ($cleaning->cleaningImages->first())
					<img src="{{ asset('storage/'.$cleaning->cleaningImages->first()->medium) }}" alt="{{ $cleaning->name }}">
				@else
					<img src="{{ asset('themes/ezone/assets/img/product/fashion-colorful/1.jpg') }}" alt="{{ $cleaning->name }}">
				@endif
            </a>
            <span>hot</span>
            <div class="product-action-list-style">
                <a class="animate-right" title="Quick View" data-toggle="modal" data-target="#exampleModal" href="#">
                    <i class="pe-7s-look"></i>
                </a>
            </div>
        </div>
        <div class="product-content-list">
            <div class="product-list-info">
                <h4><a href="{{ url('cleaning/'. $cleaning->slug) }}">{{ $cleaning->name }}</a></h4>
                <span>{{ number_format($cleaning->priceLabel()) }}</span>
                <p>{!! $cleaning->short_description !!}</p>
            </div>
            <div class="product-list-cart-wishlist">
                <div class="product-list-cart">
                    <a class="btn-hover list-btn-style add-to-card" href=""  cleaning-id="{{ $cleaning->id }}" cleaning-type="{{ $cleaning->type }}" cleaning-slug="{{ $cleaning->slug }}">add to cart</a>
                </div>
                <div class="product-list-wishlist">
                    <a class="btn-hover list-btn-wishlist add-to-fav" title="Favorite"  cleaning-slug="{{ $cleaning->slug }}" href="">
                        <i class="pe-7s-like"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="col-md-6 col-xl-4">
	<div class="product-wrapper mb-30">
		<div class="product-img">
			<a href="{{ url('cleaning/'. $cleaning->slug) }}">
				@if ($cleaning->cleaningImages->first())
					<img src="{{ asset('storage/'.$cleaning->cleaningImages->first()->medium) }}" alt="{{ $cleaning->name }}">
				@else
					<img src="{{ asset('themes/ezone/assets/img/product/fashion-colorful/1.jpg') }}" alt="{{ $cleaning->name }}">
				@endif
			</a>

			<div class="product-action">

				<a class="animate-top add-to-card" title="Add To Cart" href="" cleaning-id="{{ $cleaning->id }}" cleaning-type="{{ $cleaning->type }}" cleaning-slug="{{ $cleaning->slug }}">
					<i class="pe-7s-cart"></i>
				</a>
				<a class="animate-right quick-view" title="Quick View" cleaning-slug="{{ $cleaning->slug }}" href="">
					<i class="pe-7s-look"></i>
				</a>
			</div>
		</div>
		<div class="product-content">
			<h4><a href="{{ url('cleaning/'. $cleaning->slug) }}">{{ $cleaning->name }}</a></h4>
			<span>{{ number_format($cleaning->priceLabel()) }}</span>
		</div>
	</div>
</div>

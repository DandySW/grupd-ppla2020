<div class="row">
	@forelse ($cleanings as $cleaning)
		@include('themes.ezone.cleanings.list_box')
	@empty
		No cleaning found!
	@endforelse
</div>

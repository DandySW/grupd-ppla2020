<div class="header-cart">
	<a class="icon-cart-furniture" href="{{ url('details') }}">
		<i class="ti-shopping-cart"></i>
		<span class="shop-count-furniture green">{{ \Cart::getTotalQuantity() }}</span>
	</a>
	@if (!\Cart::isEmpty())
		<ul class="cart-dropdown">
			@foreach (\Cart::getContent() as $item)
				@php
					$cleaning = isset($item->associatedModel->parent) ? $item->associatedModel->parent : $item->associatedModel;
					$image = !empty($cleaning->cleaningImages) ? asset('storage/'.$cleaning->cleaningImages) : asset('themes/ezone/assets/img/cart/3.jpg')
				@endphp
				<li class="single-product-cart">
					<div class="cart-img">
						<a href="{{ url('cleaning/'. $cleaning->slug) }}"><img src="{{ $image }}" alt="{{ $cleaning->name }}" style="width:100px"></a>
					</div>
					<div class="cart-title">
						<h5><a href="{{ url('cleaning/'. $cleaning->slug) }}">{{ $item->name }}</a></h5>
						<span>{{ number_format($item->price) }} x {{ $item->quantity }}</span>
					</div>
					<div class="cart-delete">
						<a href="{{ url('details/remove/'. $item->id)}}" class="delete"><i class="ti-trash"></i></a>
					</div>
				</li>
			@endforeach
			<li class="cart-space">
				<div class="cart-sub">
					<h4>Subtotal</h4>
				</div>
				<div class="cart-price">
					<h4>{{ number_format(\Cart::getSubTotal()) }}</h4>
				</div>
			</li>
			<li class="cart-btn-wrapper">
				<a class="cart-btn btn-hover" href="{{ url('details') }}">view cart</a>
				<a class="cart-btn btn-hover" href="{{ url('ordercleanings/checkout') }}">checkout</a>
			</li>
		</ul>
	@endif
</div>

<div class="sidebar-widget mb-45">
	<h3 class="sidebar-title">Menu Profile</h3>
	<div class="sidebar-categories">
		<ul>
			<li><a href="{{ url('profile') }}">Profile</a></li>
		</ul>
	</div>
</div>

<div class="sidebar-widget mb-45">
	<h3 class="sidebar-title">Menu Order Produk</h3>
	<div class="sidebar-categories">
		<ul>
			<li><a href="{{ url('orders') }}">Order Produk</a></li>
		</ul>
	</div>
</div>

<div class="sidebar-widget mb-45">
	<h3 class="sidebar-title">Menu Order Jasa</h3>
	<div class="sidebar-categories">
		<ul>
			<li><a href="{{ url('detailpeternak') }}">Order Jasa</a></li>
		</ul>
	</div>
</div>

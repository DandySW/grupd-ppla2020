<div class="sidebar-widget mb-45">
	<h3 class="sidebar-title">User Menu</h3>
	<div class="sidebar-categories">
		<ul>
			<li><a href="{{ url('profile') }}">Profile</a></li>
			<li><a href="{{ url('orders') }}">Cart Order Produk</a></li>
			<li><a href="{{ url('orderservices') }}">Cart Order Jasa</a></li>
		</ul>
	</div>
</div>

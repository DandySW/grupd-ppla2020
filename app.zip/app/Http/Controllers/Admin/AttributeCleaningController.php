<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

use App\Http\Requests\AttributeCleaningRequest;
use App\Http\Requests\AttributeCleaningOptionRequest;

use App\Models\AttributeCleaning;
use App\Models\AttributeCleaningOption;

use Session;

use App\Authorizable;

class AttributeCleaningController extends Controller
{
    use Authorizable;

    public function __construct()
    {
        parent::__construct();

        $this->data['currentAdminMenu'] = 'catalog';
        $this->data['currentAdminSubMenu'] = 'attributecleaning';

        $this->data['types'] = AttributeCleaning::types();
        $this->data['booleanOptions'] = AttributeCleaning::booleanOptions();
        $this->data['validations'] = AttributeCleaning::validations();
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->data['attributescleaning'] = AttributeCleaning::orderBy('name', 'ASC')->paginate(10);

        return view('admin.attributescleaning.index', $this->data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $this->data['attributecleaning'] = null;

        return view('admin.attributescleaning.form', $this->data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AttributeCleaningRequest $request)
    {
        $params = $request->except('_token');
        $params['is_required'] = (bool) $params['is_required'];
        $params['is_unique'] = (bool) $params['is_unique'];
        $params['is_configurable'] = (bool) $params['is_configurable'];
        $params['is_filterable'] = (bool) $params['is_filterable'];

        if (AttributeCleaning::create($params)) {
            Session::flash('success', 'Attribute Cleaning has been saved');
        }

        return redirect('admin/attributescleaning');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $attributecleaning = AttributeCleaning::findOrFail($id);

        $this->data['attributecleaning'] = $attributecleaning;

        return view('admin.attributescleaning.form', $this->data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(AttributeCleaningRequest $request, $id)
    {
        $params = $request->except('_token');
        $params['is_required'] = (bool) $params['is_required'];
        $params['is_unique'] = (bool) $params['is_unique'];
        $params['is_configurable'] = (bool) $params['is_configurable'];
        $params['is_filterable'] = (bool) $params['is_filterable'];

        unset($params['code']);
        unset($params['type']);

        $attributecleaning = AttributeCleaning::findOrFail($id);

        if ($attributecleaning->update($params)) {
            Session::flash('success', 'Attribute Cleaning has been saved');
        }

        return redirect('admin/attributescleaning');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $attributecleaning = AttributeCleaning::findOrFail($id);

        if ($attributecleaning->delete()) {
            Session::flash('success', 'Attribute Cleaning has been deleted');
        }

        return redirect('admin/attributescleaning');
    }

    public function options($attributecleaningID)
    {
        if (empty($attributecleaningID)) {
            return redirect('admin/attributescleaning');
        }

        $attributecleaning = AttributeCleaning::findOrFail($attributecleaningID);
        $this->data['attributecleaning'] = $attributecleaning;

        return view('admin.attributescleaning.options', $this->data);
    }

    public function store_option(AttributeCleaningOptionRequest $request, $attributecleaningID)
    {
        if (empty($attributecleaningID)) {
            return redirect('admin/attributescleaning');
        }

        $params = [
            'attributecleaning_id' => $attributecleaningID,
            'name' => $request->get('name'),
        ];

        if (AttributeCleaningOption::create($params)) {
            Session::flash('success', 'option has been saved');
        }

        return redirect('admin/attributescleaning/'. $attributecleaningID .'/options');
    }

    public function edit_option($optionID)
    {
        $option = AttributeCleaningOption::findOrFail($optionID);

        $this->data['AttributeCleaningOption'] = $option;
        $this->data['attributecleaning'] = $option->attributecleaning;

        return view('admin.attributescleaning.options', $this->data);
    }

    public function update_option(AttributeCleaningOptionRequest $request, $optionID)
    {
        $option = AttributeCleaningOption::findOrFail($optionID);
        $params = $request->except('_token');

        if ($option->update($params)) {
            Session::flash('success', 'Option has been updated');
        }

        return redirect('admin/attributescleaning/'. $option->attributecleaning->id .'/options');
    }

    public function remove_option($optionID)
    {
        if (empty($optionID)) {
            return redirect('admin/attributescleaning');
        }

        $option = AttributeCleaningOption::findOrFail($optionID);

        if ($option->delete()) {
            Session::flash('success', 'option has been deleted');
        }

        return redirect('admin/attributescleaning/'. $option->attributecleaning->id .'/options');
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\OrderCleaning;
use App\Models\OrderCleaningItem;
use App\Models\CleaningInventory;

use \App\Exceptions\OutOfStockException;

// use App\Authorizable;

/**
 * OrderCleaningController
 *
 * PHP version 7
 *
 * @category OrderCleaningController
 * @package  OrderCleaningController
 * @author   Sugiarto <sugiarto.dlingo@gmail.com>
 * @license  https://opensource.org/licenses/MIT MIT License
 * @link     http://localhost/
 */
class OrderCleaningController extends Controller
{
	// use Authorizable;

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();

		$this->data['currentAdminMenu'] = 'order';
		$this->data['currentAdminSubMenu'] = 'ordercleaning';
		$this->data['statuses'] = OrderCleaning::STATUSES;
	}
	/**
	 * Display a listing of the resource.
	 *
	 * @param Request $request request params
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index(Request $request)
	{
		$ordercleanings = OrderCleaning::orderBy('created_at', 'DESC');

		$q = $request->input('q');
		if ($q) {
			$ordercleanings = $ordercleanings->where('code', 'like', '%'. $q .'%')
				->orWhere('customer_first_name', 'like', '%'. $q .'%')
				->orWhere('customer_last_name', 'like', '%'. $q .'%');
		}


		if ($request->input('status') && in_array($request->input('status'), array_keys(OrderCleaning::STATUSES))) {
			$ordercleanings = $ordercleanings->where('status', '=', $request->input('status'));
		}

		$startDate = $request->input('start');
		$endDate = $request->input('end');

		if ($startDate && !$endDate) {
			\Session::flash('error', 'The end date is required if the start date is present');
			return redirect('admin/ordercleanings');
		}

		if (!$startDate && $endDate) {
			\Session::flash('error', 'The start date is required if the end date is present');
			return redirect('admin/ordercleanings');
		}

		if ($startDate && $endDate) {
			if (strtotime($endDate) < strtotime($startDate)) {
				\Session::flash('error', 'The end date should be greater or equal than start date');
				return redirect('admin/ordercleanings');
			}

			$ordercleaning = $ordercleanings->whereRaw("DATE(order_date) >= ?", $startDate)
				->whereRaw("DATE(order_date) <= ? ", $endDate);
		}

		$this->data['ordercleanings'] = $ordercleanings->paginate(10);

		return view('admin.ordercleanings.index', $this->data);
	}

	/**
	 * Display the trashed orders.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function trashed()
	{
		$this->data['ordercleanings'] = Order::onlyTrashed()->orderBy('created_at', 'DESC')->paginate(10);

		return view('admin.ordercleanings.trashed', $this->data);
	}

	/**
	 * Display the specified resource.
	 *
	 * @param int $id order ID
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function show($id)
	{
		$ordercleaning = OrderCleaning::withTrashed()->findOrFail($id);

		$this->data['ordercleaning'] = $ordercleaning;

		return view('admin.ordercleanings.show', $this->data);
	}

	/**
	 * Display cancel order form
	 *
	 * @param int $id order ID
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function cancel($id)
	{
		$ordercleaning = OrderCleaning::where('id', $id)
			->whereIn('status', [OrderCleaning::CREATED, OrderCleaning::CONFIRMED])
			->firstOrFail();

		$this->data['ordercleaning'] = $order;

		return view('admin.ordercleanings.cancel', $this->data);
	}

	/**
	 * Doing the cancel process
	 *
	 * @param Request $request request params
	 * @param int     $id      order ID
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function doCancel(Request $request, $id)
	{
		$request->validate(
			[
				'cancellation_note' => 'required|max:255',
			]
		);

		$ordercleaning = OrderCleaning::findOrFail($id);

		$cancelOrderCleaning = \DB::transaction(
			function () use ($ordercleaning, $request) {
				$params = [
					'status' => Order::CANCELLED,
					'cancelled_by' => \Auth::user()->id,
					'cancelled_at' => now(),
					'cancellation_note' => $request->input('cancellation_note'),
				];

				if ($cancelOrderCleaning = $ordercleaning->update($params) && $ordercleaning->orderCleaningItems->count() > 0) {
					foreach ($ordercleaning->orderCleaningItems as $item) {
						CleaningInventory::increaseStock($item->cleaning_id, $item->qty);
					}
				}

				return $cancelOrderCleaning;
			}
		);

		\Session::flash('success', 'The order cleaning has been cancelled');

		return redirect('admin/ordercleanings');
	}

	/**
	 * Marking order as completed
	 *
	 * @param Request $request request params
	 * @param int     $id      order ID
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function doComplete(Request $request, $id)
	{
		$ordercleaning = OrderCleaning::findOrFail($id);

		if (!$ordercleaning->isDelivered()) {
			\Session::flash('error', 'Mark as complete the order can be done if the latest status is delivered');
			return redirect('admin/ordercleanings');
		}

		$ordercleaning->status = OrderCleaning::COMPLETED;
		$ordercleaning->approved_by = \Auth::user()->id;
		$ordercleaning->approved_at = now();

		if ($ordercleaning->save()) {
			\Session::flash('success', 'The order cleaning has been marked as completed!');
			return redirect('admin/ordercleanings');
		}
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param int $id order ID
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function destroy($id)
	{
		$ordercleaning = OrderCleaning::withTrashed()->findOrFail($id);

		if ($ordercleaning->trashed()) {
			$canDestroy = \DB::transaction(
				function () use ($ordercleaning) {
					OrderCleaningItem::where('ordercleaning_id', $ordercleaning->id)->delete();
					$ordercleaning->shipment->delete();
					$ordercleaning->forceDelete();

					return true;
				}
			);

			if ($canDestroy) {
				\Session::flash('success', 'The order cleaning has been removed permanently');
			} else {
				\Session::flash('success', 'The order cleaning could not be removed permanently');
			}

			return redirect('admin/ordercleanings/trashed');
		} else {
			$canDestroy = \DB::transaction(
				function () use ($ordercleaning) {
					if (!$ordercleaning->isCancelled()) {
						foreach ($ordercleaning->orderCleaningItems as $item) {
							CleaningInventory::increaseStock($item->cleaning_id, $item->qty);
						}
					};

					$ordercleaning->delete();

					return true;
				}
			);

			if ($canDestroy) {
				\Session::flash('success', 'The order cleaning has been removed');
			} else {
				\Session::flash('success', 'The order cleaning could not be removed');
			}

			return redirect('admin/ordercleanings');
		}
	}

	/**
	 * Restoring the soft deleted order
	 *
	 * @param int $id order ID
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function restore($id)
	{
		$ordercleaning = OrderCleaning::onlyTrashed()->findOrFail($id);

		$canRestore = \DB::transaction(
			function () use ($ordercleaning) {
				$isOutOfStock = false;
				if (!$ordercleaning->isCancelled()) {
					foreach ($ordercleaning->orderCleaningItems as $item) {
						try {
							CleaningInventory::reduceStock($item->cleaning_id, $item->qty);
						} catch (OutOfStockException $e) {
							$isOutOfStock = true;
							\Session::flash('error', $e->getMessage());
						}
					}
				};

				if ($isOutOfStock) {
					return false;
				} else {
					return $ordercleaning->restore();
				}
			}
		);

		if ($canRestore) {
			\Session::flash('success', 'The order cleaning has been restored');
			return redirect('admin/ordercleanings');
		} else {
			if (!\Session::has('error')) {
				\Session::flash('error', 'The order cleaning could not be restored');
			}
			return redirect('admin/ordercleanings/trashed');
		}
	}
}

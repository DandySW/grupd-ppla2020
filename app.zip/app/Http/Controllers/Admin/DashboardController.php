<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\Models\Pembayaran;
use App\Models\KonfirmasiPembayaran;

class DashboardController extends Controller
{
	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index()
	{
		$ordercleanings = Pembayaran::all();
		// $ordercleanings = DB::table('pembayarans')
		// 									->join('konfirmasi_pembayarans', 'konfirmasi_pembayarans.id_pembayaran', 'pembayarans.id')
		// 									->get();
		// return $ordercleanings;
		return view('admin.dashboards.halo', $this->data)->with(compact('ordercleanings'));
	}

	public function lihat($id)
	{
		return view('admin.dashboards.lihat', $this->data);
	}

	public function pilih(Request $request, $id)
	{
		$ordercleanings = Pembayaran::where('id', $id)->first();

		// dd($ordercleanings);

		$konfirmasi = new KonfirmasiPembayaran;

		$konfirmasi->name = $request->name;
		$konfirmasi->address1 = $request->address1;
		$konfirmasi->phone = $request->phone;
		$konfirmasi->petugas = $request->petugas;
		$konfirmasi->paket = $request->paket;
		$konfirmasi->info = $request->info;

		$konfirmasi->save();

		// return $konfirmasi;

		return view('admin.dashboards.pilih', $this->data)->with(compact('ordercleanings', 'id'));
	}
}

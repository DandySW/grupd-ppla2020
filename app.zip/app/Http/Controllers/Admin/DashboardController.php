<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Pembayaran;

class DashboardController extends Controller
{
	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index()
	{
		$ordercleanings = Pembayaran::all();

		return view('admin.dashboards.halo', $this->data)->with(compact('ordercleanings'));
	}

	public function lihat($id)
	{
		return view('admin.dashboards.lihat', $this->data);
	}

	public function pilih($id)
	{
		$ordercleanings = Pembayaran::all()->first();
		return view('admin.dashboards.pilih', $this->data)->with(compact('ordercleanings'));
	}
}

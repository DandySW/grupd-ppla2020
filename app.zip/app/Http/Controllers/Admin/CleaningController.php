<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

use App\Http\Requests\CleaningRequest;
use App\Http\Requests\CleaningImageRequest;

use App\Models\Cleaning;
use App\Models\CategoryCleaning;
use App\Models\CleaningImage;
use App\Models\CleaningInventory;

use Str;
use Auth;
use DB;
use Session;
// use App\Authorizable;

class CleaningController extends Controller
{
	// use Authorizable;

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();

		$this->data['currentAdminMenu'] = 'catalog';
		$this->data['currentAdminSubMenu'] = 'cleaning';

		$this->data['statuses'] = Cleaning::statuses();
		$this->data['types'] = Cleaning::types();
	}
	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index()
	{
		$this->data['cleanings'] = Cleaning::orderBy('name', 'ASC')->paginate(10);

		return view('admin.cleanings.index', $this->data);
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function create()
	{
		$categorycleanings = CategoryCleaning::orderBy('name', 'ASC')->get();

		$this->data['categorycleanings'] = $categorycleanings->toArray();
		$this->data['cleaning'] = null;
		$this->data['cleaningID'] = 0;
		$this->data['categorycleaningIDs'] = [];

		return view('admin.cleanings.form', $this->data);
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param CleaningRequest $request params
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function store(CleaningRequest $request)
	{
		$params = $request->except('_token');
		$params['slug'] = Str::slug($params['name']);
		$params['user_id'] = Auth::user()->id;

		$cleaning = DB::transaction(
			function () use ($params) {
				$categorycleaningIds = !empty($params['categorycleaning_ids']) ? $params['categorycleaning_ids'] : [];
				$cleaning = Cleaning::create($params);
				$cleaning->categorycleanings()->sync($categorycleaningIds);

				return $cleaning;
			}
		);

		if ($cleaning) {
			Session::flash('success', 'Cleaning has been saved');
		} else {
			Session::flash('error', 'Cleaning could not be saved');
		}

		return redirect('admin/cleanings/'. $cleaning->id .'/edit/');
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param int $id cleaning ID
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id)
	{
		if (empty($id)) {
			return redirect('admin/cleanings/create');
		}

		$cleaning = Cleaning::findOrFail($id);
		$cleaning->qty = isset($cleaning->cleaningInventory) ? $cleaning->cleaningInventory->qty : null;

		$categorycleanings = CategoryCleaning::orderBy('name', 'ASC')->get();

		$this->data['categorycleanings'] = $categorycleanings->toArray();
		$this->data['cleaning'] = $cleaning;
		$this->data['cleaningID'] = $cleaning->id;
		$this->data['categorycleaningIDs'] = $cleaning->categorycleanings->pluck('id')->toArray();

		return view('admin.cleanings.form', $this->data);
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param CleaningRequest $request params
	 * @param int            $id      cleaning ID
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function update(CleaningRequest $request, $id)
	{
		$params = $request->except('_token');
		$params['slug'] = Str::slug($params['name']);

		$cleaning = Cleaning::findOrFail($id);

		$saved = false;
		$saved = DB::transaction(
			function () use ($cleaning, $params) {
				$categorycleaningIds = !empty($params['categorycleaning_ids']) ? $params['categorycleaning_ids'] : [];
				$cleaning->update($params);
				$cleaning->categorycleanings()->sync($categorycleaningIds);
				CleaningInventory::updateOrCreate(['cleaning_id' => $cleaning->id], ['qty' => $params['qty']]);

				return true;
			}
		);

		if ($saved) {
			Session::flash('success', 'Cleaning has been saved');
		} else {
			Session::flash('error', 'Cleaning could not be saved');
		}

		return redirect('admin/cleanings');
	}

	/**
	 * Cleaning variants
	 *
	 * @param array $params params
	 *
	 * @return void
	 */
	private function _updateCleaningVariants($params)
	{
		if ($params['variants']) {
			foreach ($params['variants'] as $cleaningParams) {
				$cleaning = Cleaning::find($cleaningParams['id']);
				$cleaning->update($cleaningParams);

				$cleaning->status = $params['status'];
				$cleaning->save();

				CleaningInventory::updateOrCreate(['cleaning_id' => $cleaning->id], ['qty' => $cleaningParams['qty']]);
			}
		}
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param int $id cleaning id
	 *
	 * @return void
	 */
	public function destroy($id)
	{
		$cleaning  = Cleaning::findOrFail($id);

		if ($cleaning->delete()) {
			Session::flash('success', 'Cleaning has been deleted');
		}

		return redirect('admin/cleanings');
	}

	/**
	 * Show cleaning images
	 *
	 * @param int $id cleaning id
	 *
	 * @return void
	 */
	public function images($id)
	{
		if (empty($id)) {
			return redirect('admin/cleanings/create');
		}

		$cleaning = Cleaning::findOrFail($id);

		$this->data['cleaningID'] = $cleaning->id;
		$this->data['cleaningImages'] = $cleaning->cleaningImages;

		return view('admin.cleanings.images', $this->data);
	}

	/**
	 * Show add image form
	 *
	 * @param int $id product id
	 *
	 * @return Response
	 */
	public function addImage($id)
	{
		if (empty($id)) {
			return redirect('admin/cleanings');
		}

		$cleaning = Cleaning::findOrFail($id);

		$this->data['cleaningID'] = $cleaning->id;
		$this->data['cleaning'] = $cleaning;

		return view('admin.cleanings.image_form', $this->data);
	}

	/**
	 * Upload image
	 *
	 * @param CleaningImageRequest $request params
	 * @param int                 $id      product id
	 *
	 * @return Response
	 */
	public function uploadImage(CleaningImageRequest $request, $id)
	{
		$cleaning = Cleaning::findOrFail($id);

		if ($request->has('image')) {
			$image = $request->file('image');
			$name = $cleaning->slug . '_' . time();
			$fileName = $name . '.' . $image->getClientOriginalExtension();

			$folder = CleaningImage::UPLOAD_DIR. '/images';

			$filePath = $image->storeAs($folder . '/original', $fileName, 'public');

			$resizedImage = $this->_resizeImage($image, $fileName, $folder);

			$params = array_merge(
				[
					'cleaning_id' => $cleaning->id,
					'path' => $filePath,
				],
				$resizedImage
			);

			if (CleaningImage::create($params)) {
				Session::flash('success', 'Image has been uploaded');
			} else {
				Session::flash('error', 'Image could not be uploaded');
			}

			return redirect('admin/cleanings/' . $id . '/images');
		}
	}

	/**
	 * Resize image
	 *
	 * @param file   $image    raw file
	 * @param string $fileName image file name
	 * @param string $folder   folder name
	 *
	 * @return Response
	 */
	private function _resizeImage($image, $fileName, $folder)
	{
		$resizedImage = [];

		$smallImageFilePath = $folder . '/small/' . $fileName;
		$size = explode('x', CleaningImage::SMALL);
		list($width, $height) = $size;

		$smallImageFile = \Image::make($image)->fit($width, $height)->stream();
		if (\Storage::put('public/' . $smallImageFilePath, $smallImageFile)) {
			$resizedImage['small'] = $smallImageFilePath;
		}

		$mediumImageFilePath = $folder . '/medium/' . $fileName;
		$size = explode('x', CleaningImage::MEDIUM);
		list($width, $height) = $size;

		$mediumImageFile = \Image::make($image)->fit($width, $height)->stream();
		if (\Storage::put('public/' . $mediumImageFilePath, $mediumImageFile)) {
			$resizedImage['medium'] = $mediumImageFilePath;
		}

		$largeImageFilePath = $folder . '/large/' . $fileName;
		$size = explode('x', CleaningImage::LARGE);
		list($width, $height) = $size;

		$largeImageFile = \Image::make($image)->fit($width, $height)->stream();
		if (\Storage::put('public/' . $largeImageFilePath, $largeImageFile)) {
			$resizedImage['large'] = $largeImageFilePath;
		}

		$extraLargeImageFilePath  = $folder . '/xlarge/' . $fileName;
		$size = explode('x', CleaningImage::EXTRA_LARGE);
		list($width, $height) = $size;

		$extraLargeImageFile = \Image::make($image)->fit($width, $height)->stream();
		if (\Storage::put('public/' . $extraLargeImageFilePath, $extraLargeImageFile)) {
			$resizedImage['extra_large'] = $extraLargeImageFilePath;
		}

		return $resizedImage;
	}

	/**
	 * Remove image
	 *
	 * @param int $id image id
	 *
	 * @return Response
	 */
	public function removeImage($id)
	{
		$image = CleaningImage::findOrFail($id);

		if ($image->delete()) {
			Session::flash('success', 'Image has been deleted');
		}

		return redirect('admin/cleanings/' . $image->cleaning->id . '/images');
	}
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

use App\Http\Requests\CleaningRequest;

use App\Models\Cleaning;


use Str;
use Auth;
use DB;
use Session;
// use App\Authorizable;

class CleaningController extends Controller
{
	// use Authorizable;

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();

		$this->data['currentAdminMenu'] = 'catalog';
		$this->data['currentAdminSubMenu'] = 'cleaning';

		$this->data['statuses'] = Cleaning::statuses();
	}
	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index()
	{
		$this->data['cleanings'] = Cleaning::orderBy('name', 'ASC')->paginate(10);

		return view('admin.cleanings.index', $this->data);
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function create()
	{
		$this->data['cleaning'] = null;
		$this->data['cleaningID'] = 0;

		return view('admin.cleanings.form', $this->data);
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param CleaningRequest $request params
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function store(CleaningRequest $request)
	{
		$params = $request->except('_token');
		$params['slug'] = Str::slug($params['name']);
		$params['user_id'] = Auth::user()->id;

		$cleaning = DB::transaction(
			function () use ($params) {
				$cleaning = Cleaning::create($params);

				return $cleaning;
			}
		);

		if ($cleaning) {
			Session::flash('success', 'Cleaning has been saved');
		} else {
			Session::flash('error', 'Cleaning could not be saved');
		}

		return redirect('admin/cleanings/'. $cleaning->id .'/edit/');
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param int $id product ID
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id)
	{
		if (empty($id)) {
			return redirect('admin/cleanings/create');
		}

		$cleaning = Cleaning::findOrFail($id);
		$this->data['cleaning'] = $cleaning;
		$this->data['cleaningID'] = $cleaning->id;

		return view('admin.cleanings.form', $this->data);
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param ProductRequest $request params
	 * @param int            $id      product ID
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function update(CleaningRequest $request, $id)
	{
		$params = $request->except('_token');
		$params['slug'] = Str::slug($params['name']);

		$cleaning = Cleaning::findOrFail($id);

		$saved = false;
		$saved = DB::transaction(
			function () use ($cleaning, $params) {

				$cleaning->update($params);


				return true;
			}
		);

		if ($saved) {
			Session::flash('success', 'Cleaning has been saved');
		} else {
			Session::flash('error', 'Cleaning could not be saved');
		}

		return redirect('admin/cleanings');
	}
}

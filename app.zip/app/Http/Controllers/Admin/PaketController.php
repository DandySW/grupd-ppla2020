<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\KetentuanPaket;
use Illuminate\Support\Facades\DB;


// use Str;
// use Auth;
// use DB;
// use Session;
// use App\Authorizable;

class PaketController extends Controller
{
	// use Authorizable;

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();

		//
	}
	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index()
	{
    $ketentuans = KetentuanPaket::all();
		return view('admin.pakets.index', $this->data)->with(compact('ketentuans'));
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function create(Request $request)
	{
    //
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param CleaningRequest $request params
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function store(CleaningRequest $request)
	{
		//
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param int $id product ID
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id)
	{
		$ketentuans = DB::table('ketentuan_pakets')->where('id', $id)->first();

		// return $ketentuans;

		return view('admin.pakets.form', $this->data)->with(compact('ketentuans', 'id'));
	}

	public function editProcess(Request $request, $id)
	{
		$ketentuans = KetentuanPaket::all();
		DB::table('ketentuan_pakets')->where('id', $id)
		->update([
			'isi' => $request->isi
		]);

		// return $request;

		return view('admin.pakets.index', $this->data)->with(compact('ketentuans'));
	}
}

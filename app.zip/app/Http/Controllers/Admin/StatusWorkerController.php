<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\Models\User;

class StatusWorkerController extends Controller
{
	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();
    $this->data['currentAdminMenu'] = 'role-user';
		$this->data['currentAdminSubMenu'] = 'status_worker';
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index(Request $request)
	{
    $workers = User::where('role', 3)->get();

    // return $worker;
		return view('admin.statusworkers.index', $this->data)->with(compact('workers'));
	}

  public function status($id)
	{
		$statusworkers = User::where('id', $id)->first();

		$status_sekarang = $statusworkers->status;

		if($status_sekarang == 1){
			User::where('id', $id)->update([
				'status'=>0
			]);

		} else {
			User::where('id', $id)->update([
				'status'=>1
			]);
		}

		return redirect('admin/statusworkers');
	}
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\CategoryCleaningRequest;

use App\Models\CategoryCleaning;

use Str;
use Session;

// use App\Authorizable;

class CategoryCleaningController extends Controller
{
    // use Authorizable;

    public function __construct() {
        parent::__construct();

        $this->data['currentAdminMenu'] = 'catalog';
        $this->data['currentAdminSubMenu'] = 'categorycleaning';
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->data['categorycleanings'] = CategoryCleaning::orderBy('name', 'ASC')->paginate(10);

        return view('admin.categorycleanings.index', $this->data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categorycleanings = CategoryCleaning::orderBy('name', 'asc')->get();

        $this->data['categorycleanings'] = $categorycleanings->toArray();
        $this->data['categorycleaning'] = null;

        return view('admin.categorycleanings.form', $this->data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CategoryCleaningRequest $request)
    {
        $params = $request->except('_token');
        $params['slug'] = Str::slug($params['name']);
        $params['parent_id'] = (int)$params['parent_id'];

        if (CategoryCleaning::create($params)) {
            Session::flash('success', 'Category has been saved');
        }
        return redirect('admin/categorycleanings');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $categorycleaning = CategoryCleaning::findOrFail($id);
        $categorycleanings = CategoryCleaning::where('id', '!=', $id)->orderBy('name', 'asc')->get();

        $this->data['categorycleanings'] = $categorycleanings->toArray();
        $this->data['categorycleaning'] = $categorycleaning;
        return view('admin.categorycleanings.form', $this->data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(CategoryCleaningRequest $request, $id)
    {
        $params = $request->except('_token');
        $params['slug'] = Str::slug($params['name']);
        $params['parent_id'] = (int)$params['parent_id'];

        $categorycleaning = CategoryCleaning::findOrFail($id);
        if ($categorycleaning->update($params)) {
            Session::flash('success', 'Category has been updated.');
        }

        return redirect('admin/categorycleanings');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $categorycleaning  = CategoryCleaning::findOrFail($id);

        if ($categorycleaning->delete()) {
            Session::flash('success', 'Category has been deleted');
        }

        return redirect('admin/categorycleanings');
    }
}

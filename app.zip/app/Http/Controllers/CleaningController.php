<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Cleaning;
use App\Models\CleaningAttributeValue;
use App\Models\AttributeOption;
use App\Models\CategoryCleaning;

use Str;

/**
 * CleaningController
 *
 * PHP version 7
 *
 * @category CleaningController
 * @package  CleaningController
 * @author   Sugiarto <sugiarto.dlingo@gmail.com>
 * @license  https://opensource.org/licenses/MIT MIT License
 * @link     http://localhost/
 */
class CleaningController extends Controller
{
	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();

		$this->data['q'] = null;

		$this->data['categorycleanings'] = CategoryCleaning::parentCategoryCleanings()
			->orderBy('name', 'asc')
			->get();

		$this->data['minPrice'] = Cleaning::min('price');
		$this->data['maxPrice'] = Cleaning::max('price');

		$this->data['colors'] = AttributeOption::whereHas(
			'attribute',
			function ($query) {
					$query->where('code', 'color')
						->where('is_filterable', 1);
			}
		)
		->orderBy('name', 'asc')->get();

		$this->data['sizes'] = AttributeOption::whereHas(
			'attribute',
			function ($query) {
				$query->where('code', 'size')
					->where('is_filterable', 1);
			}
		)->orderBy('name', 'asc')->get();

		$this->data['sorts'] = [
			url('cleanings') => 'Default',
			url('cleanings?sort=price-asc') => 'Price - Low to High',
			url('cleanings?sort=price-desc') => 'Price - High to Low',
			url('cleanings?sort=created_at-desc') => 'Newest to Oldest',
			url('cleanings?sort=created_at-asc') => 'Oldest to Newest',
		];

		$this->data['selectedSort'] = url('products');
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @param Request $request request param
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index(Request $request)
	{
		$cleanings = Cleaning::active();

		$cleanings = $this->_searchCleanings($cleanings, $request);
		$cleanings = $this->_filterCleaningsByPriceRange($cleanings, $request);
		$cleanings = $this->_filterCleaningsByAttribute($cleanings, $request);
		$cleanings = $this->_sortCleanings($cleanings, $request);

		$this->data['cleanings'] = $cleanings->paginate(9);
		return $this->loadTheme('cleanings.index', $this->data);
	}

	/**
	 * Search cleanings
	 *
	 * @param array   $products array of products
	 * @param Request $request  request param
	 *
	 * @return \Illuminate\Http\Response
	 */
	private function _searchCleanings($cleanings, $request)
	{
		if ($q = $request->query('q')) {
			$q = str_replace('-', ' ', Str::slug($q));

			$cleanings = $cleanings->whereRaw('MATCH(name, slug, short_description, description) AGAINST (? IN NATURAL LANGUAGE MODE)', [$q]);

			$this->data['q'] = $q;
		}

		if ($categoryCleaningSlug = $request->query('categorycleaning')) {
			$categorycleaning = CategoryCleaning::where('slug', $categoryCleaningSlug)->firstOrFail();

			$childIds = CategoryCleaning::childIds($categorycleaning->id);
			$categorycleaningIds = array_merge([$categorycleaning->id], $childIds);

			$cleanings = $cleanings->whereHas(
				'categorycleanings',
				function ($query) use ($categorycleaningIds) {
					$query->whereIn('categorycleanings.id', $categorycleaningIds);
				}
			);
		}

		return $cleanings;
	}

	/**
	 * Filter cleanings by price range
	 *
	 * @param array   $cleanings array of cleanings
	 * @param Request $request  request param
	 *
	 * @return \Illuminate\Http\Response
	 */
	private function _filterCleaningsByPriceRange($cleanings, $request)
	{
		$lowPrice = null;
		$highPrice = null;

		if ($priceSlider = $request->query('price')) {
			$prices = explode('-', $priceSlider);

			$lowPrice = !empty($prices[0]) ? (float)$prices[0] : $this->data['minPrice'];
			$highPrice = !empty($prices[1]) ? (float)$prices[1] : $this->data['maxPrice'];

			if ($lowPrice && $highPrice) {
				$cleanings = $cleanings->where('price', '>=', $lowPrice)
					->where('price', '<=', $highPrice)
					->orWhereHas(
						'variants',
						function ($query) use ($lowPrice, $highPrice) {
							$query->where('price', '>=', $lowPrice)
								->where('price', '<=', $highPrice);
						}
					);

				$this->data['minPrice'] = $lowPrice;
				$this->data['maxPrice'] = $highPrice;
			}
		}

		return $cleanings;
	}

	/**
	 * Filter cleanings by attribute
	 *
	 * @param array   $cleanings array of cleanings
	 * @param Request $request  request param
	 *
	 * @return \Illuminate\Http\Response
	 */
	private function _filterCleaningsByAttribute($cleanings, $request)
	{
		if ($attributeOptionID = $request->query('option')) {
			$attributeOption = AttributeOption::findOrFail($attributeOptionID);

			$cleanings = $cleanings->whereHas(
				'CleaningAttributeValues',
				function ($query) use ($attributeOption) {
					$query->where('attribute_id', $attributeOption->attribute_id)
						->where('text_value', $attributeOption->name);
				}
			);
		}

		return $cleanings;
	}

	/**
	 * Sort cleanings
	 *
	 * @param array   $cleanings array of cleanings
	 * @param Request $request  request param
	 *
	 * @return \Illuminate\Http\Response
	 */
	private function _sortCleanings($cleanings, $request)
	{
		if ($sort = preg_replace('/\s+/', '', $request->query('sort'))) {
			$availableSorts = ['price', 'created_at'];
			$availableOrder = ['asc', 'desc'];
			$sortAndOrder = explode('-', $sort);

			$sortBy = strtolower($sortAndOrder[0]);
			$orderBy = strtolower($sortAndOrder[1]);

			if (in_array($sortBy, $availableSorts) && in_array($orderBy, $availableOrder)) {
				$cleanings = $cleanings->orderBy($sortBy, $orderBy);
			}

			$this->data['selectedSort'] = url('cleanings?sort='. $sort);
		}

		return $cleanings;
	}

	/**
	 * Display the specified resource.
	 *
	 * @param string $slug cleaning slug
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function show($slug)
	{
		$cleaning = Cleaning::active()->where('slug', $slug)->first();

		if (!$cleaning) {
			return redirect('cleanings');
		}

		if ($cleaning->configurable()) {
			$this->data['colors'] = CleaningAttributeValue::getAttributeOptions($cleaning, 'color')->pluck('text_value', 'text_value');
			$this->data['sizes'] = CleaningAttributeValue::getAttributeOptions($cleaning, 'size')->pluck('text_value', 'text_value');
		}

		$this->data['cleaning'] = $cleaning;

		return $this->loadTheme('cleanings.show', $this->data);
	}

	/**
	 * Quick view cleaning.
	 *
	 * @param string $slug cleaning slug
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function quickView($slug)
	{
		$cleaning = Cleaning::active()->where('slug', $slug)->firstOrFail();
		if ($cleaning->configurable()) {
			$this->data['colors'] = CleaningAttributeValue::getAttributeOptions($cleaning, 'color')->pluck('text_value', 'text_value');
			$this->data['sizes'] = CleaningAttributeValue::getAttributeOptions($cleaning, 'size')->pluck('text_value', 'text_value');
		}

		$this->data['cleaning'] = $cleaning;

		return $this->loadTheme('cleanings.quick_view', $this->data);
	}
}

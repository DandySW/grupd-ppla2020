<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\CleaningP;
use App\Models\Cleaning;
use App\Models\User;
use Session;
use DB;

class CleaningController extends Controller
{
    public function __construct()
    {
      parent::__construct();

    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cleanings = \App\Models\Cleaning::all();
        $user_datas = \App\Models\User::where('role', 3)->get();
        // dd($cleanings);
        return view('themes.ezone.cleanings.form', compact('cleanings', 'user_datas'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      $cleanings = Cleaning::findOrFail($request);
      $user_datas = User::findOrFail($request);
      // return $request;
      return view('themes.ezone.cleanings.detailorder', compact('cleanings', 'user_datas'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
      //
    }
}

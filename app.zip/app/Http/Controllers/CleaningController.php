<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\CleaningP;
use App\Models\Cleaning;
use App\Models\User;
use Session;

class CleaningController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user_datas = User::where('role', 3)->get();
        $cleanings = Cleaning::all();
        // dd($cleanings);
        return view('themes.ezone.cleanings.form', compact('user_datas', 'cleanings'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Session::put('cleaning', $request->all());
        // dd(Session::get('cleaning'));
        return redirect()->route('cleanings.detailorder');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        $cleaning = Session::get('cleaning');
        return view('themes.ezone.cleanings.detailorder', compact('cleaning'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function store_option(CleaningOptionRequest $request, $cleaningID)
    {
        //
    }

    public function edit_option($optionID)
    {
        //
    }

    public function update_option(CleaningOptionRequest $request, $optionID)
    {
        //
    }

    public function remove_option($optionID)
    {
        //
    }
}

<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;
use App\Models\Cleaning;
use App\Models\DetailOrder;
use App\Models\User;
use Illuminate\Support\Facades\Session;

class CleaningController extends Controller
{
  public function __construct()
  {
    parent::__construct();
  }
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index()
  {
    $cleanings = \App\Models\Cleaning::all();
    $user_datas = \App\Models\User::where('role', 3)->where('status', '=', 0)->get();

    // if(date('H:i') < date('H:i', strtotime('07:00')) or date('H:i') >= date('H:i', strtotime('17:00')))
    // {
    //   foreach ($user_datas as $user_data) {
    //     User::where('id', $user_data->id)->update([
  	// 			'status'=>1
  	// 		]);
    //   }
    // }
    // else{
    //   foreach ($user_datas as $user_data) {
    //     User::where('id', $user_data->id)->update([
  	// 			'status'=>1
  	// 		]);
    //   }
    // }
    // dd($cleanings);
    return view('themes.ezone.cleanings.form', compact('cleanings', 'user_datas'));
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request)
  {
    $cleaning = Cleaning::findOrFail($request->cleaning_id);
    $user_data = User::findOrFail($request->user_id);
    // dd($cleaning);
    // $user = User::findOrFail($request->user_id);
    // DetailOrder::findOrFail($request);

    $request->validate([
      'cleaning_id' => 'required',
      'user_id' => 'required',
    ], [
      'cleaning_id.required' => "Paket tidak boleh kosong",
      'user_id.required' => "Petugas tidak boleh kosong",
    ]);

    $detailorder = new DetailOrder;
    $detailorder->name = $cleaning->id;
    $detailorder->price = $cleaning->price;
    $detailorder->user = $request->user_id;
    $detailorder->status_verifikasi = $user_data->status;
    $detailorder->save();

    // $nomor = 1;
    //
    // $id = $request->user_id;
    //
    // DB::table('users')->where('id', $id)
    // ->update([
    //   "status" => $nomor,
    // ]);

    Session::put('detailorder', $detailorder);

    // return $request;
    return redirect('cleanings/detailorder');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function show(Request $request)
  {
    $id_detail = Session::get('detailorder');
    $id_detail = $id_detail->id;
    // dd($id_detail);

    $detail = DB::select("SELECT detail_orders.price, detail_orders.status_verifikasi, cleanings.name, users.first_name, users.last_name, users.status FROM `detail_orders`, `cleanings`, `users` WHERE cleanings.id = detail_orders.name and users.id = cleanings.user_id and detail_orders.id = $id_detail");
    $detail = $detail[0];

    // $nomor = 0;
    // $id = $request->petugas;
    // DB::table('users')->where('id', $id)
    // ->update([
    //   "status" => $nomor,
    // ]);

    return view('themes.ezone.cleanings.detailorder', compact('detail'));
  }
}

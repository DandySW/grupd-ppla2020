<?php

namespace App\Http\Controllers\Worker;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\KetentuanPaket;


// use Str;
// use Auth;
// use DB;
// use Session;
// use App\Authorizable;

class PaketController extends Controller
{
	// use Authorizable;

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();

		//
	}
	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index()
	{
    $ketentuans = KetentuanPaket::all();
		return view('worker.pakets.index', compact('ketentuans'));
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function create()
	{
    //
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param CleaningRequest $request params
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function store(CleaningRequest $request)
	{
		//
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param int $id product ID
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id)
	{
		//
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param ProductRequest $request params
	 * @param int            $id      product ID
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function update(CleaningRequest $request, $id)
	{
		//
	}
}

<?php

namespace App\Http\Controllers\Worker;
use App\Http\Controllers\Controller;

class LayananController extends Controller
{
  public function __construct()
  {
    parent::__construct();

    $this->data['currentWorkerMenu'] = 'catalog';
    
  }
	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index()
	{
		return view('worker.index');
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function create()
	{
		//
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param CleaningRequest $request params
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function store(CleaningRequest $request)
	{
		//
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param int $id product ID
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id)
	{
		//
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param ProductRequest $request params
	 * @param int            $id      product ID
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function update(CleaningRequest $request, $id)
	{
		//
	}
}

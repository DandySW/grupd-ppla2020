<?php

namespace App\Http\Controllers\Worker;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\Models\Pembayaran;
use App\Models\KonfirmasiPembayaran;

class LayananController extends Controller
{
  public function __construct()
  {
    parent::__construct();

    $this->data['currentWorkerMenu'] = 'catalog';

  }

	public function index()
	{
    $petugas = \Auth::user();
    $petugas = $petugas->first_name;

    $konfirmasi = KonfirmasiPembayaran::where('petugas', 'Dandy Satrio')->get();
    $konfirmasi->order_date = date('Y-m-d H:i:s', time());

    // dd($konfirmasi);

    $ordercleanings = Pembayaran::where('petugas', 'like', $petugas.'%');

    // return $ordercleanings;
		return view('worker.index', compact('ordercleanings', 'konfirmasi'));
	}
}

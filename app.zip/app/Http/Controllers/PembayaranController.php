<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpFoundation\Request;

use App\Models\Slide;
use App\Models\User;
use App\Models\Cleaning;
use App\Models\Pembayaran;

class PembayaranController extends Controller
{
  public function __construct()
  {
    parent::__construct();

    $this->middleware('auth');
  }

  public function index(Request $request)
  {
    $this->data['user'] = \Auth::user();
    $detail = \Session::get('detailorder');

    $id_petugas = $detail->user;
    $petugas = User::findOrFail($id_petugas);

    $id_paket = $detail->name;
    $paket = Cleaning::findOrFail($id_paket);
    // return $pembayaran;

    // return $pembayaran;

    return $this->loadTheme('paymentcleanings.create', $this->data)->with(compact('petugas', 'paket'));
  }

  public function store(Request $request)
  {
    $slides = Slide::active()->orderBy('position', 'ASC')->get();
    $this->data['slides'] = $slides;

    $pembayaran = new Pembayaran();

    $pembayaran->first_name = $request->first_name;
    $pembayaran->last_name = $request->last_name;
    $pembayaran->address1 = $request->address1;
    $pembayaran->phone = $request->phone;
    $pembayaran->email_verified_at = $request->email;
    $pembayaran->petugas = $request->petugas;
    $pembayaran->paket = $request->paket;
    $pembayaran->order_date = date('Y-m-d H:i:s', time());

    if ($request->hasfile('image')) {
      $file = $request->file('image');
      $extension = $file->getClientOriginalExtension(); //getting image extension
      $filename = time() . '.' . $extension;
      $file->move('uploads/pembayaran/', $filename);
      $pembayaran->image = $filename;
    }else {

      $pembayaran->image = 'GAMBAR KOSONG';
    }

    $pembayaran->save();

    // return $request;
    // return $pembayaran;
    return $this->loadTheme('home', $this->data);
  }
}

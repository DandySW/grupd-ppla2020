<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Request;

use App\Models\Slide;
use App\Models\User;
use App\Models\Cleaning;
use App\Models\DetailOrder;
use App\Models\Pembayaran;

class PembayaranController extends Controller
{
  public function __construct()
  {
    parent::__construct();

    $this->middleware('auth');
  }

  public function index(Request $request)
  {
    $this->data['user'] = \Auth::user();

    $detail = \Session::get('detailorder');
    $id_detail = $detail->id;

    $id_petugas = $detail->user;
    $petugas = User::findOrFail($id_petugas);

    $id_paket = $detail->name;
    $paket = Cleaning::findOrFail($id_paket);

    $status_verifikasi = DetailOrder::findOrFail($id_detail);
		$status_verifikasi = $status_verifikasi['status_verifikasi'];

    // return $pembayaran;
    // return $status;

    return $this->loadTheme('paymentcleanings.create', $this->data)->with(compact('petugas', 'paket', 'status_verifikasi'));
  }

  public function store(Request $request)
  {
    $slides = Slide::active()->orderBy('position', 'ASC')->get();
    $this->data['slides'] = $slides;

    $request->validate([
      'image' => 'required|mimes:jpg,jpeg,png'
    ]);

    $pembayaran = new Pembayaran();

    $pembayaran->first_name = $request->first_name;
    $pembayaran->last_name = $request->last_name;
    $pembayaran->address1 = $request->address1;
    $pembayaran->phone = $request->phone;
    $pembayaran->email_verified_at = $request->email;
    $pembayaran->petugas = $request->petugas;
    $pembayaran->user_id = $request->user_id;
    $pembayaran->paket = $request->paket;
    $pembayaran->status_verifikasi = $request->status_verifikasi;
    $pembayaran->order_date = date('Y-m-d H:i:s', time());

    if ($request->hasfile('image')) {
      $file = $request->file('image');
      $extension = time().rand(100,999).".".$file->getClientOriginalExtension(); //getting image extension
      $filename = time() . '.' . $extension;
      $file->move('uploads/pembayaran/', $filename);
      $pembayaran->image = $filename;
    }else {

      $pembayaran->image = 'GAMBAR KOSONG';
    }

    $pembayaran->save();

    $nomor = 1;

    $id = $request->petugas;

    DB::table('users')->where('petugas', $id)
    ->update([
      "status" => $nomor,
    ]);

    // return $request;
    // return $pembayaran;
    return $this->loadTheme('home', $this->data);
  }

  public function detailPeternak()
	{
		$nama = \Auth::user()->first_name;
		$ordercleanings = Pembayaran::where('first_name', $nama)->get();

		return view('themes.ezone.ordercleanings.detailpeternak', compact('ordercleanings'));
	}

  public function selesai(Request $request)
  {
    $id = $request->id;

    DB::table('pembayarans as pe')->join('users as us', 'user_id', '=', 'us.id')->where('pe.id', $id)
    ->update([
      "us.status" => $request['status'],
    ]);

    return redirect('detailpeternak');
  }
}

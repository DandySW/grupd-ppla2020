<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\OrderCleaningRequest;
use App\Models\OrderCleaning;
use App\Models\OrderCleaningItem;
use App\Models\ShipmentCleaning;
use App\Models\Cleaning;
use App\Models\DetailOrder;
use App\Models\Pembayaran;

// use Illuminate\Support\Facades\Session;

/**
 * OrderController
 *
 * PHP version 7
 *
 * @category OrderCleaningController
 * @package  OrderCleaningController
 * @author   Sugiarto <sugiarto.dlingo@gmail.com>
 * @license  https://opensource.org/licenses/MIT MIT License
 * @link     http://localhost/
 */
class OrderCleaningController extends Controller
{
	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();

		$this->middleware('auth');
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index()
	{
		$ordercleanings = OrderCleaning::forUser(\Auth::user())
			->orderBy('created_at', 'DESC')
			->paginate(10);

		$this->data['ordercleanings'] = $ordercleanings;

		return $this->loadTheme('ordercleanings.index', $this->data);
	}

	/**
	 * Display the specified resource.
	 *
	 * @param int $id order ID
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function show($id)
	{
		$ordercleaning = OrderCleaning::forUser(\Auth::user())->findOrFail($id);
		$this->data['ordercleaning'] = $ordercleaning;

		return $this->loadTheme('ordercleanings.show', $this->data);
	}

	/**
	 * Show the checkout page
	 *
	 * @return void
	 */
	public function checkout()
	{
		$this->data['user'] = \Auth::user();

		$id_detail = \Session::get('detailorder');
		$id_detail = $id_detail->id;

		$price = DetailOrder::findOrFail($id_detail);
		$price = $price['price'];

		return $this->loadTheme('ordercleanings.checkout', $this->data)->with(compact('price'));
	}

	public function detailPeternak()
	{
		$ordercleanings = Pembayaran::where('first_name', 'Tasta')->get();

		return view('themes.ezone.ordercleanings.detailpeternak', compact('ordercleanings'));
	}
}

<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AttributeCleaningOptionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $attributecleaningID = (int) $this->get('attributecleaning_id');
        $id = (int) $this->get('id');

        if ($this->method() == 'PUT') {
            $name = 'required|unique:attributecleaning_options,name,'.$id.',id,attributecleaning_id,'.$attributecleaningID;
        } else {
            $name = 'required|unique:attributecleaning_options,name,NULL,id,attributecleaning_id,'.$attributecleaningID;
        }

        return [
            'name' => $name,
        ];
    }
}

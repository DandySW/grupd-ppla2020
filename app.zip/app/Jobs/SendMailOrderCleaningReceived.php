<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

/**
 * SendMailOrderReceived
 *
 * PHP version 7
 *
 * @category SendMailOrderReceived
 * @package  SendMailOrderReceived
 * @author   Sugiarto <sugiarto.dlingo@gmail.com>
 * @license  https://opensource.org/licenses/MIT MIT License
 * @link     http://localhost/
 */

class SendMailOrderCleaningReceived implements ShouldQueue
{
	use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

	protected $ordercleaning;
	protected $user;

	/**
	 * Create a new job instance.
	 *
	 * @param OrderCleaning $order order object
	 * @param User  $user  user auth
	 *
	 * @return void
	 */
	public function __construct($ordercleaning, $user)
	{
		$this->ordercleaning = $ordercleaning;
		$this->user = $user;
	}

	/**
	 * Execute the job.
	 *
	 * @return void
	 */
	public function handle()
	{
		$orderCleaningReceivedEmail = new \App\Mail\OrderCleaningReceived($this->ordercleaning);

		\Mail::to($this->user->email)->send($orderCleaningReceivedEmail);
	}
}

<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

/**
 * OrderReceived
 *
 * PHP version 7
 *
 * @category OrderCleaningReceived
 * @package  OrderCleaningReceived
 * @author   Sugiarto <sugiarto.dlingo@gmail.com>
 * @license  https://opensource.org/licenses/MIT MIT License
 * @link     http://localhost/
 */
class OrderCleaningReceived extends Mailable
{
	use Queueable, SerializesModels;

	public $ordercleaning;
	/**
	 * Create a new message instance.
	 *
	 * @param OrderCleaning $order order object
	 *
	 * @return void
	 */
	public function __construct($ordercleaning)
	{
		$this->ordercleaning = $ordercleaning;
	}

	/**
	 * Build the message.
	 *
	 * @return $this
	 */
	public function build()
	{
		return $this->markdown('emails.ordercleanings.received');
	}
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * CleaningInventory
 *
 * PHP version 7
 *
 * @category CleaningInventory
 * @package  CleaningInventory
 * @author   Sugiarto <sugiarto.dlingo@gmail.com>
 * @license  https://opensource.org/licenses/MIT MIT License
 * @link     http://localhost/
 */
class CleaningInventory extends Model
{
	protected $table='cleaning_inventories';
	protected $fillable = [
		'cleaning_id',
		'qty',
	];

	/**
	 * Define relationship with the Product
	 *
	 * @return void
	 */
	public function cleaning()
	{
		return $this->belongsTo('App\Models\Cleaning');
	}

	/**
	 * Reduce stock cleaning
	 *
	 * @param int $cleaningId cleaning ID
	 * @param int $qty       qty cleaning
	 *
	 * @return void
	 */
	public static function reduceStock($productcleaningId, $qty)
	{
		$inventory = self::where('cleaning_id', $cleaningId)->firstOrFail();

		if ($inventory->qty < $qty) {
			$cleaning = Cleaning::findOrFail($cleaningId);
			throw new \App\Exceptions\OutOfStockException('The cleaning '. $cleaning->sku .' is out of stock');
		}

		$inventory->qty = $inventory->qty - $qty;
		$inventory->save();
	}

	/**
	 * Increase stock product
	 *
	 * @param int $productId product ID
	 * @param int $qty       qty product
	 *
	 * @return void
	 */
	public static function increaseStock($cleaningId, $qty)
	{
		$inventory = self::where('cleaning_id', $cleaningId)->firstOrFail();
		$inventory->qty = $inventory->qty + $qty;
		$inventory->save();
	}
}

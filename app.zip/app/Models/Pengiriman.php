<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pengiriman extends Model
{
  protected $fillable = ['first_name', 'address1', 'phone', 'petugas', 'info'];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DetailOrder extends Model
{
  public $timestamps = false;
  protected $fillable = [
		'name',
		'price',
		'user',
    'status',
    'first_name',
    'last_name',
	];

  public function pembayaran()
  {
    return $this->belongsTo(Pembayaran::class);
  }
}

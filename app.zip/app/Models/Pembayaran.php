<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pembayaran extends Model
{
  protected $fillable = ['first_name', 'last_name', 'address1', 'phone', 'email_verified_at', 'petugas', 'order_date', 'image', 'status_verifikasi'];

  public function detailorder()
  {
    return $this->hasOne(DetailOrder::class);
  }

  public function user()
  {
    return $this->hasOne(User::class);
  }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Cleaning extends Model
{

	protected $fillable = [
		'parent_id',
		'user_id',
		'name',
		'slug',
		'price',
		'status',
	];

	// public const DRAFT = 0;
	public const ACTIVE = 1;
	// public const INACTIVE = 2;

	public const STATUSES = [
		// self::DRAFT => 'draft',
		self::ACTIVE => 'active',
		// self::INACTIVE => 'inactive',
	];

	/**
	 * Define relationship with the User
	 *
	 * @return void
	 */
	public function user()
	{
		return $this->belongsTo('App\Models\User');
	}

	/**
	 * Define relationship with the Parent
	 *
	 * @return void
	 */
	public function parent()
	{
		return $this->belongsTo('App\Models\Cleaning', 'parent_id');
	}

	/**
	 * Define relationship with the Shipment
	 *
	 * @return void
	 */
	public static function statuses()
	{
		return self::STATUSES;
	}

	/**
	 * Get status label
	 *
	 * @return string
	 */
	public function statusLabel()
	{
		$statuses = $this->statuses();

		return isset($this->status) ? $statuses[$this->status] : null;
	}

	/**
	 * Scope active product
	 *
	 * @param Eloquent $query query builder
	 *
	 * @return Eloquent
	 */
	public function scopeActive($query)
	{
		return $query->where('status', 1)
			->where('parent_id', null);
	}

	/**
	 * Get price label
	 *
	 * @return string
	 */
	public function priceLabel()
	{
		return $this->cleanings->first()->price;
	}

	public static function getSubTotal()
	{
		//
	}
}

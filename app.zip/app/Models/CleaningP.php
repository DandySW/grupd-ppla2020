<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CleaningP extends Model
{
  protected $table = "cleanings";
  protected $fillable = [
		'parent_id',
		'user_id',
		'name',
		'slug',
		'price',
		'status',
	];

  public function priceLabel()
	{
		return ($this->cleanings->count() > 0) ? $this->cleanings->first()->price : $this->price;
	}
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CleaningP extends Model
{
    return $this->belongsTo('App\Models\Service');
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class KonfirmasiPembayaran extends Model
{
  protected $table = 'konfirmasi_pembayarans';
  protected $fillable = ['name', 'address1', 'phone', 'petugas', 'info'];
}

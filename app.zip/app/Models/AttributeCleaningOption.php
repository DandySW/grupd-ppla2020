<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AttributeCleaningOption extends Model
{
    protected $fillable = ['attributecleaning_id', 'name'];

    public function attributecleaning()
    {
        return $this->belongsTo('App\Models\AttributeCleaning');
    }
}

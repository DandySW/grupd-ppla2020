<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class KetentuanPaket extends Model
{
	protected $table = 'ketentuan_pakets';

	protected $fillable = ['isi'];
}

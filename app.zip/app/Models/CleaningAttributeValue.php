<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CleaningAttributeValue extends Model
{
    protected $table='cleaning_attribute_values';
    protected $fillable = [
        'cleaning_id',
        'attributecleaning_id',
        'text_value',
        'boolean_value',
        'integer_value',
        'float_value',
        'datetime_value',
        'date_value',
        'json_value',
    ];

    public function cleaning()
    {
        return $this->belongsTo('App\Models\Cleaning');
    }

    public function attributecleaning()
    {
        return $this->belongsTo('App\Models\AttributeCleaning');
    }

    public static function getAttributeCleaningOptions($cleaning, $attributeCleaningCode)
    {
        $cleaningVariantIDs = $cleaning->variants->pluck('id');
        $attributecleaning = AttributeCleaning::where('code', $attributeCleaningCode)->first();

        $attributeCleaningOptions = CleaningAttributeValue::where('attributecleaning_id', $attributecleaning->id)
                            ->whereIn('cleaning_id', $cleaningVariantIDs)
                            ->get();

        return $attributeCleaningOptions;
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CategoryCleaning extends Model
{
    protected $table='categorycleanings';
    protected $fillable = ['name', 'slug', 'parent_id'];

    public function childs() {
        return $this->hasMany('App\Models\CategoryCleaning', 'parent_id');
    }

    public function parent() {
        return $this->belongsTo('App\Models\CategoryCleaning', 'parent_id');
    }

    public function cleanings()
    {
        return $this->belongsToMany('App\Models\Cleaning', 'cleaning_categories');
    }

    public function scopeParentCategoryCleanings($query)
    {
        return $query->where('parent_id', 0);
    }

    public static function childIds($parentId = 0)
	{
		$categorycleanings = CategoryCleaning::select('id','name','parent_id')->where('parent_id', $parentId)->get()->toArray();

		$childIds = [];
		if(!empty($categorycleanings)){
			foreach($categorycleanings as $categorycleaning){
				$childIds[] = $categorycleaning['id'];
				$childIds = array_merge($childIds, CategoryCleaning::childIds($categorycleaning['id']));
			}
		}

		return $childIds;
	}
}

<?php
/**
 * Web Routes
 *
 * Here is where you can register web routes for your application. These
 * routes are loaded by the RouteServiceProvider within a group which
 * contains the "web" middleware group. Now create something great!
 *
 * @category WebRoutes
 * @package  WebRoutes
 * @author   Sugiarto <sugiarto.dlingo@gmail.com>
 * @license  https://opensource.org/licenses/MIT MIT License
 * @link     http://localhost/
 */

Route::get('/', 'HomeController@index');
Route::get('/products', 'ProductController@index');
Route::get('/product/{slug}', 'ProductController@show');
Route::get('/products/quick-view/{slug}', 'ProductController@quickView');

Route::get('/cleanings', 'CleaningController@index');
Route::get('/cleaning/{slug}', 'CleaningController@show');
Route::get('/cleanings/quick-view/{slug}', 'CleaningController@quickView');

Route::get('/carts', 'CartController@index');
Route::get('/carts/remove/{cartID}', 'CartController@destroy');
Route::post('/carts', 'CartController@store');
Route::post('/carts/update', 'CartController@update');

Route::get('/cartcleanings', 'CartCleaningController@index');
Route::get('/cartcleanings/remove/{cartCleaningID}', 'CartCleaningController@destroy');
Route::post('/cartcleanings', 'CartCleaningController@store');
Route::post('/cartcleanings/update', 'CartCleaningController@update');

Route::get('orders/checkout', 'OrderController@checkout');
Route::post('orders/checkout', 'OrderController@doCheckout');
Route::post('orders/shipping-cost', 'OrderController@shippingCost');
Route::post('orders/set-shipping', 'OrderController@setShipping');
Route::get('orders/received/{orderID}', 'OrderController@received');
Route::get('orders/cities', 'OrderController@cities');
Route::get('orders', 'OrderController@index');
Route::get('orders/{orderID}', 'OrderController@show');

Route::get('ordercleanings/checkout', 'OrderCleaningController@checkout');
Route::post('ordercleanings/checkout', 'OrderCleaningController@doCheckout');
Route::post('ordercleanings/shipping-cost', 'OrderCleaningController@shippingCost');
Route::post('ordercleanings/set-shipping', 'OrderCleaningController@setShipping');
Route::get('ordercleanings/received/{orderCleaningID}', 'OrderCleaningController@received');
Route::get('ordercleanings/cities', 'OrderCleaningController@cities');
Route::get('ordercleanings', 'OrderCleaningController@index');
Route::get('ordercleanings/{orderCleaningID}', 'OrderCleaningController@show');

Route::post('payments/notification', 'PaymentController@notification');
Route::get('payments/completed', 'PaymentController@completed');
Route::get('payments/failed', 'PaymentController@failed');
Route::get('payments/unfinish', 'PaymentController@unfinish');

Route::resource('favorites', 'FavoriteController');

Route::get('profile', 'Auth\ProfileController@index');
Route::post('profile', 'Auth\ProfileController@update');

Route::group(
	['namespace' => 'Admin', 'prefix' => 'admin', 'middleware' => ['auth']],
	function () {
		Route::get('dashboard', 'DashboardController@index');
		Route::resource('categories', 'CategoryController');

		Route::resource('categorycleanings', 'CategoryCleaningController');

		Route::resource('products', 'ProductController');
		Route::get('products/{productID}/images', 'ProductController@images')->name('products.images');
		Route::get('products/{productID}/add-image', 'ProductController@addImage')->name('products.add_image');
		Route::post('products/images/{productID}', 'ProductController@uploadImage')->name('products.upload_image');
		Route::delete('products/images/{imageID}', 'ProductController@removeImage')->name('products.remove_image');

		Route::resource('cleanings', 'CleaningController');
		Route::get('cleanings/{cleaningID}/images', 'CleaningController@images')->name('cleanings.images');
		Route::get('cleanings/{cleaningID}/add-image', 'CleaningController@addImage')->name('cleanings.add_image');
		Route::post('cleanings/images/{cleaningID}', 'CleaningController@uploadImage')->name('cleanings.upload_image');
		Route::delete('cleanings/images/{imageID}', 'CleaningController@removeImage')->name('cleanings.remove_image');

		Route::resource('attributes', 'AttributeController');
		Route::get('attributes/{attributeID}/options', 'AttributeController@options')->name('attributes.options');
		Route::get('attributes/{attributeID}/add-option', 'AttributeController@add_option')->name('attributes.add_option');
		Route::post('attributes/options/{attributeID}', 'AttributeController@store_option')->name('attributes.store_option');
		Route::delete('attributes/options/{optionID}', 'AttributeController@remove_option')->name('attributes.remove_option');
		Route::get('attributes/options/{optionID}/edit', 'AttributeController@edit_option')->name('attributes.edit_option');
		Route::put('attributes/options/{optionID}', 'AttributeController@update_option')->name('attributes.update_option');

		Route::resource('attributescleaning', 'AttributeCleaningController');
		Route::get('attributescleaning/{attributeCleaningID}/options', 'AttributeCleaningController@options')->name('attributescleaning.options');
		Route::get('attributescleaning/{attributeCleaningID}/add-option', 'AttributeCleaningController@add_option')->name('attributescleaning.add_option');
		Route::post('attributescleaning/options/{attributeCleaningID}', 'AttributeCleaningController@store_option')->name('attributescleaning.store_option');
		Route::delete('attributescleaning/options/{optionID}', 'AttributeCleaningController@remove_option')->name('attributescleaning.remove_option');
		Route::get('attributescleaning/options/{optionID}/edit', 'AttributeCleaningController@edit_option')->name('attributescleaning.edit_option');
		Route::put('attributescleaning/options/{optionID}', 'AttributeCleaningController@update_option')->name('attributescleaning.update_option');

		Route::resource('roles', 'RoleController');
		Route::resource('users', 'UserController');

		Route::get('orders/trashed', 'OrderController@trashed');
		Route::get('orders/restore/{orderID}', 'OrderController@restore');
		Route::resource('orders', 'OrderController');
		Route::get('orders/{orderID}/cancel', 'OrderController@cancel');
		Route::put('orders/cancel/{orderID}', 'OrderController@doCancel');
		Route::post('orders/complete/{orderID}', 'OrderController@doComplete');

		Route::get('ordercleanings/trashed', 'OrderCleaningController@trashed');
		Route::get('ordercleanings/restore/{orderCleaningID}', 'OrderCleaningController@restore');
		Route::resource('ordercleanings', 'OrderCleaningController');
		Route::get('ordercleanings/{orderCleaningID}/cancel', 'OrderCleaningController@cancel');
		Route::put('ordercleanings/cancel/{orderCleaningID}', 'OrderCleaningController@doCancel');
		Route::post('ordercleanings/complete/{orderCleaningID}', 'OrderCleaningController@doComplete');

		Route::resource('shipments', 'ShipmentController');

		Route::resource('slides', 'SlideController');
		Route::get('slides/{slideID}/up', 'SlideController@moveUp');
		Route::get('slides/{slideID}/down', 'SlideController@moveDown');

		Route::get('reports/revenue', 'ReportController@revenue');
		Route::get('reports/product', 'ReportController@product');
		Route::get('reports/inventory', 'ReportController@inventory');
		Route::get('reports/payment', 'ReportController@payment');
	}
);

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

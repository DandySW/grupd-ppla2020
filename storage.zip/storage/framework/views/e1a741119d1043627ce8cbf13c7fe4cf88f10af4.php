<!--
	====================================
	——— LEFT SIDEBAR WITH FOOTER
	=====================================
-->
<aside class="left-sidebar bg-sidebar">
	<div id="sidebar" class="sidebar sidebar-with-footer">
		<!-- Aplication Brand -->
		<div class="app-brand">
			<a href="<?php echo e(url('worker/layanankebersihan')); ?>">
			<span class="brand-name">LAYANAN SIPAKAN</span>
			</a>
		</div>
		<!-- begin sidebar scrollbar -->
		<div class="sidebar-scrollbar">

			<!-- sidebar menu -->
			<ul class="nav sidebar-inner" id="sidebar-menu">
				<li  class="has-sub" >
					<a class="sidenav-item-link" href="<?php echo e(url('worker/layanankebersihan')); ?>">
						<i class="mdi mdi-view-dashboard-outline"></i>
						<span class="nav-text">Cleaning Service</span>
					</a>

				</li>
			</ul>
		</div>
	</div>
</aside>
<?php /**PATH C:\xampp\htdocs\sipakan\resources\views/worker/partials/sidebar.blade.php ENDPATH**/ ?>
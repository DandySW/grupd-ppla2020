<?php $__env->startSection('title', 'Create'); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-lg-6">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom">
                        <h2>Create User</h2>
                </div>
                <div class="card-body">
                    <?php echo Form::open(['route' => ['users.store'] ]); ?>

                        <?php echo $__env->make('admin.users.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!-- Submit Form Button -->
                        <div class="form-footer pt-5 border-top">
                            <?php echo Form::submit('Create', ['class' => 'btn btn-primary']); ?>

                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/admin/users/create.blade.php ENDPATH**/ ?>
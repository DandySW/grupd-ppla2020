<?php $__env->startSection('content'); ?>
<div class="breadcrumb-area pt-205 breadcrumb-padding pb-210" style="background-image: url(<?php echo e(asset('themes/ezone/assets/img/bg/breadcrumb.jpg')); ?>)">
	<div class="container-fluid">
		<div class="breadcrumb-content text-center">
			<h2>Forgot Password</h2>
			<ul>
				<li><a href="#">home</a></li>
				<li>Forgot Password</li>
			</ul>
		</div>
	</div>
</div>
<!-- register-area start -->
<div class="register-area ptb-100">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 col-12 col-lg-12 col-xl-6 ml-auto mr-auto">
				<div class="login">
					<div class="login-form-container">
						<div class="login-form">
							<?php if(session('status')): ?>
								<div class="alert alert-success" role="alert">
									<?php echo e(session('status')); ?>

								</div>
							<?php endif; ?>

							<form method="POST" action="<?php echo e(route('password.email')); ?>">
								<?php echo csrf_field(); ?>
								<div class="form-group row">
									<div class="col-md-12">
										<input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="<?php echo e(__('E-Mail Address')); ?>">

										<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
									</div>
								</div>
								<div class="form-group row mb-0">
									<div class="col-md-12">
										<div class="button-box">
											<button type="submit" class="default-btn floatright"><?php echo e(__('Send Password Reset Link')); ?></button>
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- register-area end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.ezone.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/auth/password/email.blade.php ENDPATH**/ ?>
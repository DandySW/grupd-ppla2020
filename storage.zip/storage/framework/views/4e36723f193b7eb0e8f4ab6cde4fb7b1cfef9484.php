<!--
 ====================================
 ——— LEFT SIDEBAR WITH FOOTER
 =====================================
-->
<aside class="left-sidebar bg-sidebar">
 <div id="sidebar" class="sidebar sidebar-with-footer">
   <!-- Aplication Brand -->
   <div class="app-brand">
     <a href="<?php echo e(url('admin/dashboard')); ?>">
     <span class="brand-name">LaraShop Dashboard</span>
     </a>
   </div>
   <!-- begin sidebar scrollbar -->
   <div class="sidebar-scrollbar">

     <!-- sidebar menu -->
     <ul class="nav sidebar-inner" id="sidebar-menu">
       <li  class="has-sub  <?php echo e(($currentAdminMenu == 'catalog') ? 'expand active' : ''); ?>" >
         <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse" data-target="#dashboard"
           aria-expanded="false" aria-controls="dashboard">
           <i class="mdi mdi-view-dashboard-outline"></i>
           <span class="nav-text">Catalog</span> <b class="caret"></b>
         </a>
         <ul  class="collapse  <?php echo e(($currentAdminMenu == 'catalog') ? 'show' : ''); ?>"  id="dashboard"
           data-parent="#sidebar-menu">
           <div class="sub-menu">
             <li  class="<?php echo e(($currentAdminSubMenu == 'product') ? 'active' : ''); ?>">
               <a class="sidenav-item-link" href="<?php echo e(url('admin/products')); ?>">
               <span class="nav-text">Products</span>
               </a>
             </li>
             <li class="<?php echo e(($currentAdminSubMenu == 'category') ? 'active' : ''); ?>">
               <a class="sidenav-item-link" href="<?php echo e(url('admin/categories')); ?>">
               <span class="nav-text">Categories</span>
               </a>
             </li>
             <li class="<?php echo e(($currentAdminSubMenu == 'attribute') ? 'active' : ''); ?>">
               <a class="sidenav-item-link" href="<?php echo e(url('admin/attributes')); ?>">
               <span class="nav-text">Attributes</span>
               </a>
             </li>
           </div>
         </ul>
       </li>
       <li  class="has-sub <?php echo e(($currentAdminMenu == 'order') ? 'expand active' : ''); ?>">
         <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse" data-target="#auth"
           aria-expanded="false" aria-controls="dashboard">
           <i class="mdi mdi-cart-outline"></i>
           <span class="nav-text">Orders</span> <b class="caret"></b>
         </a>
         <ul class="collapse <?php echo e(($currentAdminMenu == 'order') ? 'show' : ''); ?>"  id="auth"
           data-parent="#sidebar-menu">
           <div class="sub-menu">
             <li  class="<?php echo e(($currentAdminSubMenu == 'order') ? 'active' : ''); ?>" >
               <a class="sidenav-item-link" href="<?php echo e(url('admin/orders')); ?>">
               <span class="nav-text">Orders</span>
               </a>
             </li>
             <li class="<?php echo e(($currentAdminSubMenu == 'trashed-order') ? 'active' : ''); ?>">
               <a class="sidenav-item-link" href="<?php echo e(url('admin/orders/trashed')); ?>">
               <span class="nav-text">Trashed</span>
               </a>
             </li>
             <li class="<?php echo e(($currentAdminSubMenu == 'shipment') ? 'active' : ''); ?>">
               <a class="sidenav-item-link" href="<?php echo e(url('admin/shipments')); ?>">
               <span class="nav-text">Shipments</span>
               </a>
             </li>
           </div>
         </ul>
       </li>
       <li  class="has-sub <?php echo e(($currentAdminMenu == 'role-user') ? 'expand active' : ''); ?>">
         <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse" data-target="#auth"
           aria-expanded="false" aria-controls="dashboard">
           <i class="mdi mdi-account-multiple-outline"></i>
           <span class="nav-text">Users &amp; Roles</span> <b class="caret"></b>
         </a>
         <ul class="collapse <?php echo e(($currentAdminMenu == 'role-user') ? 'show' : ''); ?>"  id="auth"
           data-parent="#sidebar-menu">
           <div class="sub-menu">
             <li  class="<?php echo e(($currentAdminSubMenu == 'user') ? 'active' : ''); ?>" >
               <a class="sidenav-item-link" href="<?php echo e(url('admin/users')); ?>">
               <span class="nav-text">Users</span>
               </a>
             </li>
             <li class="<?php echo e(($currentAdminSubMenu == 'role') ? 'active' : ''); ?>">
               <a class="sidenav-item-link" href="<?php echo e(url('admin/roles')); ?>">
               <span class="nav-text">Roles</span>
               </a>
             </li>
           </div>
         </ul>
       </li>
     </ul>
   </div>
 </div>
</aside>
<?php /**PATH C:\xampp\htdocs\sipakan\resources\views/admin/partials/sidebar.blade.php ENDPATH**/ ?>
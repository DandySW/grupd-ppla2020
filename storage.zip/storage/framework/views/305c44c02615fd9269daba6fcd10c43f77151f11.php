<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="row">
    <div class="col-lg-9">
      <div class="card card-default">
        <div class="card-header card-header-border-bottom">
          <h2>Update Form</h2>
        </div>
        <div class="card-body">
          <form action="<?php echo e(url('admin/ketentuanpaket/create')); ?>" method="POST">
            <?php echo csrf_field(); ?>
          <div class="form-group">
            <?php echo Form::label('name', 'Ketentuan Paket'); ?>

            <?php echo Form::textarea('name', null, ['class' => 'form-control', 'placeholder' => 'Tulis disini']); ?>

          </div>
          <div class="form-footer pt-5 border-top">
            <button type="submit" class="btn btn-primary btn-default">Save</button>
            <a href="<?php echo e(url('admin/ketentuanpaket')); ?>" class="btn btn-secondary btn-default">Back</a>
          </div>
          <?php echo Form::close(); ?>

        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/admin/pakets/create.blade.php ENDPATH**/ ?>
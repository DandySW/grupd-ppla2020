<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="row">
			<div class="col-lg-12">
				<div class="card card-default">
					<div class="card-header card-header-border-bottom">
						<h2>Product Report</h2>
					</div>
					<div class="card-body">
						<?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<table class="table table-bordered table-striped">
							<thead>
								<th>Name</th>
								<th>SKU</th>
								<th>Items Sold</th>
								<th>Net Revenue</th>
								<th>Orders</th>
								<th>Stock</th>
							</thead>
							<tbody>
								<?php
									$totalNetRevenue = 0;
								?>
								<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<tr>
										<td><?php echo e($product->name); ?></td>
										<td><?php echo e($product->sku); ?></td>
										<td><?php echo e($product->items_sold); ?></td>
										<td><?php echo e(\General::priceFormat($product->net_revenue)); ?></td>
										<td><?php echo e($product->num_of_orders); ?></td>
										<td><?php echo e($product->stock); ?></td>
									</tr>

									<?php
										$totalNetRevenue += $product->net_revenue;
									?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<tr>
										<td colspan="6">No records found</td>
									</tr>
								<?php endif; ?>

								<?php if($products): ?>
									<tr>
										<td>&nbsp;</td>
										<td>&nbsp;</td>
										<td>&nbsp;</td>
										<td><?php echo e(\General::priceFormat($totalNetRevenue)); ?></td>
										<td>&nbsp;</td>
										<td>&nbsp;</td>
									</tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/admin/reports/product.blade.php ENDPATH**/ ?>
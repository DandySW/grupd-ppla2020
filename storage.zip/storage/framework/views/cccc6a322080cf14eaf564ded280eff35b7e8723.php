<!-- product area start -->
<?php if($products): ?>
	<div class="popular-product-area wrapper-padding-3 pt-115 pb-115">
		<div class="container-fluid">
			<div class="section-title-6 text-center mb-50">
				<h2>Popular Product</h2>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text</p>
			</div>
			<div class="product-style">
				<div class="popular-product-active owl-carousel">
					<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php
							$product = $product->parent ?: $product;
						?>
						<div class="product-wrapper">
							<div class="product-img">
								<a href="<?php echo e(url('product/'. $product->slug)); ?>">
									<?php if($product->productImages->first()): ?>
										<img src="<?php echo e(asset('storage/'.$product->productImages->first()->medium)); ?>" alt="<?php echo e($product->name); ?>">
									<?php else: ?>
										<img src="<?php echo e(asset('themes/ezone/assets/img/product/fashion-colorful/1.jpg')); ?>" alt="<?php echo e($product->name); ?>">
									<?php endif; ?>
								</a>
								<div class="product-action">
									<a class="animate-left add-to-fav" title="Wishlist"  product-slug="<?php echo e($product->slug); ?>" href="">
										<i class="pe-7s-like"></i>
									</a>
									<a class="animate-top add-to-card" title="Add To Cart" href="" product-id="<?php echo e($product->id); ?>" product-type="<?php echo e($product->type); ?>" product-slug="<?php echo e($product->slug); ?>">
										<i class="pe-7s-cart"></i>
									</a>
									<a class="animate-right quick-view" title="Quick View" product-slug="<?php echo e($product->slug); ?>" href="">
										<i class="pe-7s-look"></i>
									</a>
								</div>
							</div>
							<div class="funiture-product-content text-center">
								<h4><a href="<?php echo e(url('product/'. $product->slug)); ?>"><?php echo e($product->name); ?></a></h4>
								<span><?php echo e(number_format($product->priceLabel())); ?></span>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
	</div>
	<!-- product area end -->
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/partials/popular_products.blade.php ENDPATH**/ ?>
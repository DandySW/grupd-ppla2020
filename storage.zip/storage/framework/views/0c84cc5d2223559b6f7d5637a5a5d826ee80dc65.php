<div class="row">
	<?php $__empty_1 = true; $__currentLoopData = $cleanings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cleaning): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<?php echo $__env->make('themes.ezone.cleanings.list_box', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		No cleaning found!
	<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/cleanings/list_view.blade.php ENDPATH**/ ?>
<div class="sidebar-widget mb-45">
	<h3 class="sidebar-title">User Menu</h3>
	<div class="sidebar-categories">
		<ul>
			<li><a href="<?php echo e(url('profile')); ?>">Profile</a></li>
			<li><a href="<?php echo e(url('orders')); ?>">Cart Order Produk</a></li>
			<li><a href="<?php echo e(url('orderservices')); ?>">Cart Order Jasa</a></li>
		</ul>
	</div>
</div>
<?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/partials/user_menu.blade.php ENDPATH**/ ?>
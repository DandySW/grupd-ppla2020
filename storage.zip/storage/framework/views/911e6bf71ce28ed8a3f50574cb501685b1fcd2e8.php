<?php $__env->startSection('content'); ?>
	<!-- header end -->
	<div class="breadcrumb-area pt-205 breadcrumb-padding pb-210" style="background-image: url(<?php echo e(asset('themes/ezone/assets/img/bg/breadcrumb.jpg')); ?>)">
		<div class="container">
			<div class="breadcrumb-content text-center">
				<h2>cart page</h2>
				<ul>
					<li><a href="<?php echo e(url('/')); ?>">home</a></li>
					<li> cart page</li>
				</ul>
			</div>
		</div>
	</div>
	<!-- shopping-cart-area start -->
	<div class="cart-main-area pt-95 pb-100">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<h1 class="cart-heading">Cart</h1>
					<?php echo Form::open(['url' => 'carts/update']); ?>

						<div class="table-content table-responsive">
							<table>
								<thead>
									<tr>
										<th>remove</th>
										<th>images</th>
										<th>Product</th>
										<th>Price</th>
										<th>Quantity</th>
										<th>Total</th>
									</tr>
								</thead>
								<tbody>
									<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
										<?php
											$product = isset($item->associatedModel->parent) ? $item->associatedModel->parent : $item->associatedModel;
											$image = !empty($product->productImages->first()) ? asset('storage/'.$product->productImages->first()->path) : asset('themes/ezone/assets/img/cart/3.jpg')
										?>
										<tr>
											<td class="product-remove">
												<a href="<?php echo e(url('carts/remove/'. $item->id)); ?>" class="delete"><i class="pe-7s-close"></i></a>
											</td>
											<td class="product-thumbnail">
												<a href="<?php echo e(url('product/'. $product->slug)); ?>"><img src="<?php echo e($image); ?>" alt="<?php echo e($product->name); ?>" style="width:100px"></a>
											</td>
											<td class="product-name"><a href="<?php echo e(url('product/'. $product->slug)); ?>"><?php echo e($item->name); ?></a></td>
											<td class="product-price-cart"><span class="amount"><?php echo e(number_format($item->price)); ?></span></td>
											<td class="product-quantity">
												
												<?php echo Form::number('items['. $item->id .'][quantity]', $item->quantity, ['min' => 1, 'required' => true]); ?>

											</td>
											<td class="product-subtotal"><?php echo e(number_format($item->price * $item->quantity)); ?></td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
										<tr>
											<td colspan="6">The cart is empty!</td>
										</tr>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="coupon-all">
									<div class="coupon2">
										<input class="button" name="update_cart" value="Update cart" type="submit">
									</div>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-5 ml-auto">
								<div class="cart-page-total">
									<h2>Cart totals</h2>
									<ul>
										<li>Subtotal<span><?php echo e(number_format(\Cart::getSubTotal())); ?></span></li>
										<li>Total<span><?php echo e(number_format(\Cart::getTotal())); ?></span></li>
									</ul>
									<a href="<?php echo e(url('orders/checkout')); ?>">Proceed to checkout</a>
								</div>
							</div>
						</div>
					<?php echo Form::close(); ?>

				</div>
			</div>
		</div>
	</div>
	<!-- shopping-cart-area end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.ezone.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/carts/index.blade.php ENDPATH**/ ?>
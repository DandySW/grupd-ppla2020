<footer class="footer mt-auto">
            <script>
                var d = new Date();
                var year = d.getFullYear();
                document.getElementById("copy-year").innerHTML = year;
            </script>
        </footer>
<?php /**PATH C:\xampp\htdocs\sipakan\resources\views/admin/partials/footer.blade.php ENDPATH**/ ?>
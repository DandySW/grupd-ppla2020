<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="row">
    <div class="col-lg-9">
      <div class="card card-default">
        <div class="card-header card-header-border-bottom">
          <h2>Update Form</h2>
        </div>
        <div class="card-body">
          <form action="<?php echo e(url('admin/pakets/' . $ketentuans->id)); ?>" method="POST">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
          <div class="form-group">
            <label>Ketentuan Paket</label>
            <textarea name="isi" class="form-control" maxlength="10000" required>"<?php echo e($ketentuans->isi); ?>"</textarea>
          </div>
          <div class="form-footer pt-5 border-top">
            <button type="submit" class="btn btn-primary btn-default">Save</button>
          </div>
        </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/admin/pakets/form.blade.php ENDPATH**/ ?>
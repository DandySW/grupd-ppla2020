<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-default">
        <div class="card-header card-header-border-bottom">
          <h2>Ketentuan Paket</h2>
        </div>
        <div class="card-body">
          <div class="form-group">
            <label>Isi Ketentuan</label>
            <textarea class="form-control" readonly="true">
            <?php $__currentLoopData = $ketentuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo e($item->isi); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </textarea>
          </div>
          <div class="text-right">
            <a href="<?php echo e(url('admin/pakets/edit/' . $item->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
          </div>
        </div>
      </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/admin/pakets/index.blade.php ENDPATH**/ ?>
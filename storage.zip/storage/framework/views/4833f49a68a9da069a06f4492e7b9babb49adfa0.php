<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-lg-6">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom">
                    <h2>Cancel Order #<?php echo e($order->code); ?></h2>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('admin.partials.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo Form::model($order, ['url' => ['admin/orders/cancel', $order->id], 'method' => 'PUT']); ?>

                    <?php echo Form::hidden('id'); ?>

                    <div class="form-group">
                        <?php echo Form::label('cancellation_note', 'Cancellation Note'); ?>

                        <?php echo Form::textarea('cancellation_note', null, ['class' => 'form-control']); ?>

                    </div>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Cancel the Order</button>
                        <a href="<?php echo e(url('admin/orders')); ?>" class="btn btn-secondary btn-default">Back</a>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom">
                    <h2>Cart Order</h2>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6">
                            <p class="text-dark mb-2" style="font-weight: normal; font-size:16px; text-transform: uppercase;">Billing Address</p>
                            <address>
                                <?php echo e($order->customer_first_name); ?> <?php echo e($order->customer_last_name); ?>

                                <br> <?php echo e($order->customer_address1); ?>

                                <br> <?php echo e($order->customer_address2); ?>

                                <br> Email: <?php echo e($order->customer_email); ?>

                                <br> Phone: <?php echo e($order->customer_phone); ?>

                                <br> Postcode: <?php echo e($order->customer_postcode); ?>

                            </address>
                        </div>
                        <div class="col-xl-6 col-lg-6">
                            <p class="text-dark mb-2" style="font-weight: normal; font-size:16px; text-transform: uppercase;">Carts</p>
                            <address>
                                ID: <span class="text-dark">#<?php echo e($order->code); ?></span>
                                <br> <?php echo e(\General::datetimeFormat($order->order_date)); ?>

                                <br> Status: <?php echo e($order->status); ?>

                                <br> Payment Status: <?php echo e($order->payment_status); ?>

                                <br> Shipped by: <?php echo e($order->shipping_service_name); ?>

                            </address>
                        </div>
                    </div>
                    <table class="table mt-3 table-striped table-responsive table-responsive-large" style="width:100%">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Item</th>
                                <th>Qty</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($item->sku); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->qty); ?></td>
                                    <td><?php echo e(\General::priceFormat($item->sub_total)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6">Order item not found!</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="row justify-content-end">
                        <div class="col-lg-5 col-xl-6 col-xl-3 ml-sm-auto">
                            <ul class="list-unstyled mt-4">
                                <li class="mid pb-3 text-dark">Subtotal
                                    <span class="d-inline-block float-right text-default"><?php echo e(\General::priceFormat($order->base_total_price)); ?></span>
                                </li>
                                <li class="mid pb-3 text-dark">Tax(10%)
                                    <span class="d-inline-block float-right text-default"><?php echo e(\General::priceFormat($order->tax_amount)); ?></span>
                                </li>
                                <li class="mid pb-3 text-dark">Shipping Cost
                                    <span class="d-inline-block float-right text-default"><?php echo e(\General::priceFormat($order->shipping_cost)); ?></span>
                                </li>
                                <li class="pb-3 text-dark">Total
                                    <span class="d-inline-block float-right"><?php echo e(\General::priceFormat($order->grand_total)); ?></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/admin/orders/cancel.blade.php ENDPATH**/ ?>
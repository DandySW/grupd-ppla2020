<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\sipakan\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/table.blade.php ENDPATH**/ ?>
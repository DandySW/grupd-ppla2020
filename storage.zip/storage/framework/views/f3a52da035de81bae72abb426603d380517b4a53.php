<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-default">
        <div class="card-header card-header-border-bottom">
          <h2>Order Cleaning Services</h2>
        </div>
        <div class="col-lg-8 sm-2">
          <form class="form-inline" method="GET">
            <div class="form-group mx-sm-2 mb-2">
              <input name="keyword" type="text" class="form-control" placeholder="Nama Petugas">
            </div>
            <button type="submit" class="btn btn-primary mb-2">Search</button>
          </form>
        </div>
        <div class="card-body">
          <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <table class="table table-bordered table-striped">
            <thead>
              <th>No.</th>
              <th>Aksi Petugas</th>
              <th>Aksi Kerja</th>
              <th>Waktu</th>
              <th>Nama</th>
              <th>Alamat</th>
              <th>No. HP</th>
              <th>Petugas</th>
              <th>Paket</th>
              <th>Bukti Pembayaran</th>
              <!-- <th>Info</th>
              <th>Aksi</th> -->
              <th>Status Petugas</th>
              <th>Status Kerja</th>
            </thead>
            <tbody>
              <?php $__currentLoopData = $ordercleanings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><?php echo e($loop->iteration); ?></td>
                      <td>
                        <?php if($item->status_petugas == 0): ?>
                        <a href="<?php echo e(url('admin/dashboard/' . $item->id)); ?>" class="btn btn-sm btn-danger">Non-Aktifkan</a>
                        <?php else: ?>
                        <a href="<?php echo e(url('admin/dashboard/' . $item->id)); ?>" class="btn btn-sm btn-success">Aktifkan</a>
                        <?php endif; ?>
                      </td>
                      <td>Aktifkan</td>
                      <td>
												<span><?php echo e(\General::datetimeFormat($item->order_date)); ?></span>
											</td>
                      <td><?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?></td>
                      <td><?php echo e($item->address1); ?></td>
                      <td><?php echo e($item->phone); ?></td>
                      <td><?php echo e($item->petugas); ?></td>
                      <td><?php echo e($item->paket); ?></td>
                      <td>
                        <a href="<?php echo e(asset('uploads/pembayaran/'.$item->image)); ?>" target="_blank" rel="noopener noreferrer">Lihat Bukti</a>
                      </td>
                      <!-- <td><?php echo e($item->info); ?></td>
                      <td>
                        <?php if($item->info == null): ?>
                        <a href="<?php echo e(url('admin/dashboards/pilih/'. $item->id)); ?>" class="btn btn-warning btn-sm">Pilih</a>
                        <?php endif; ?>
                      </td> -->
                      <td><span class="badge <?php echo e(($item->status_petugas == 0 ? 'badge-success' : 'badge-danger')); ?>"><?php echo e(($item->status_petugas == 0) ? 'Kerja' : 'Tidak Kerja'); ?></span></td>
                      <td>Tidak Aktif</td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/admin/dashboards/halo.blade.php ENDPATH**/ ?>
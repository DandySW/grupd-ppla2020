<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-default">
        <div class="card-header card-header-border-bottom">
          <h2>Petugas Layanan Kebersihan</h2>
        </div>
        <div class="card-body">
          <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <table class="table table-bordered table-striped">
            <thead>
              <th>No.</th>
              <th>Aksi</th>
              <th>Name</th>
              <th>Email</th>
              <th>Created At</th>
              <th>Status</th>
            </thead>
            <tbody>
              <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($worker->id); ?></td>
                <td>
                  <?php if($worker->status == 0): ?>
                  <a href="<?php echo e(url('admin/statusworkers/' . $worker->id)); ?>" class="btn btn-sm btn-danger">x</a>
                  <?php else: ?>
                  <a href="<?php echo e(url('admin/statusworkers/' . $worker->id)); ?>" class="btn btn-sm btn-success">✓</a>
                  <?php endif; ?>
                </td>
                <td><?php echo e($worker->first_name); ?> <?php echo e($worker->last_name); ?></td>
                <td><?php echo e($worker->email); ?></td>
                <td><?php echo e($worker->created_at); ?></td>
                <td><span class="badge <?php echo e(($worker->status == 1 ? 'badge-danger' : 'badge-success')); ?>"><?php echo e(($worker->status == 0) ? 'Aktif' : 'Tidak Aktif'); ?></span></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/admin/statusworkers/index.blade.php ENDPATH**/ ?>
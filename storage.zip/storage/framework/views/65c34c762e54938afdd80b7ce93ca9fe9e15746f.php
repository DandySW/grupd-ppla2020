<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="row">
        <div class="col-lg-4">
            <?php echo $__env->make('admin.cleanings.cleaning_menus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-lg-8">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom">
                        <h2>Upload Images</h2>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('admin.partials.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo Form::open(['url' => ['admin/cleanings/images', $cleaning->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                    <div class="form-group">
                        <?php echo Form::label('image', 'Cleaning Image'); ?>

                        <?php echo Form::file('image', ['class' => 'form-control-file', 'placeholder' => 'cleaning image']); ?>

                    </div>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Save</button>
                        <a href="<?php echo e(url('admin/cleanings/'.$cleaningID.'/images')); ?>" class="btn btn-secondary btn-default">Back</a>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/admin/cleanings/image_form.blade.php ENDPATH**/ ?>
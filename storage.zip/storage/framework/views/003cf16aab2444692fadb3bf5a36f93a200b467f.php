<p class="text-primary mt-4">Product Variants</p>
<hr/>
 <?php $__currentLoopData = $product->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php echo Form::hidden('variants['. $variant->id .'][id]', $variant->id); ?>

    <div class="row">
        <div class="col-md-2">
            <div class="form-group">
                <?php echo Form::label('sku', 'SKU'); ?>

                <?php echo Form::text('variants['. $variant->id .'][sku]', $variant->sku, ['class' => 'form-control']); ?>

            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <?php echo Form::label('name', 'Name'); ?>

                <?php echo Form::text('variants['. $variant->id .'][name]', $variant->name, ['class' => 'form-control']); ?>

            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <?php echo Form::label('price', 'Price'); ?>

                <?php echo Form::text('variants['. $variant->id .'][price]', $variant->price, ['class' => 'form-control', 'required' => true]); ?>

            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <?php echo Form::label('qty', 'Stock'); ?>

                <?php echo Form::text('variants['. $variant->id .'][qty]', ($variant->productInventory) ? $variant->productInventory->qty : null, ['class' => 'form-control', 'required' => true]); ?>

            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <?php echo Form::label('weight', 'Weight'); ?>

                <?php echo Form::text('variants['. $variant->id .'][weight]', $variant->weight, ['class' => 'form-control', 'required' => true]); ?>

            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<hr/>
<?php /**PATH C:\xampp\htdocs\sipakan\resources\views/admin/products/configurable.blade.php ENDPATH**/ ?>
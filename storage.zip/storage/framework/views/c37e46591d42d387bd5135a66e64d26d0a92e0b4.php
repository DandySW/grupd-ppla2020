<button type="button" class="close" data-dismiss="modal" aria-label="Close">
	<span class="pe-7s-close" aria-hidden="true"></span>
</button>
<div class="modal-dialog modal-quickview-width" role="document">
	<div class="modal-content">
		<div class="modal-body">
			<div class="qwick-view-left">
				<div class="quick-view-learg-img">
					<div class="quick-view-tab-content tab-content">
						<?php
							$i = 1
						?>
						<?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="tab-pane fade <?php echo e(($i == 1) ? 'active show' : ''); ?>" id="modal<?php echo e($i); ?>" role="tabpanel">
								<?php if($image->medium): ?>
									<img src="<?php echo e(asset('storage/'.$image->medium)); ?>" alt="<?php echo e($product->name); ?>" style="width:320px;">
								<?php else: ?>
									<img src="<?php echo e(asset('themes/ezone/assets/img/quick-view/l3.jpg')); ?>" alt="">
								<?php endif; ?>
							</div>
							<?php
								$i++
							?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
				<div class="quick-view-list nav" role="tablist">
					<?php
						$i = 1
					?>
					<?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<a class="<?php echo e(($i == 1) ? 'active' : ''); ?> mr-12" href="#modal<?php echo e($i); ?>" data-toggle="tab" role="tab">
							<?php if($image->small): ?>
								<img src="<?php echo e(asset('storage/'.$image->small)); ?>" alt="<?php echo e($product->name); ?>" style="width:100px; height:112px">
							<?php else: ?>
								<img src="<?php echo e(asset('themes/ezone/assets/img/quick-view/s3.jpg')); ?>" alt="<?php echo e($product->name); ?>">
							<?php endif; ?>
						</a>
						<?php
							$i++
						?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			<div class="qwick-view-right">
				<div class="qwick-view-content">
					<h3><?php echo e($product->name); ?></h3>
					<div class="price">
						<span class="new"><?php echo e(number_format($product->priceLabel())); ?></span>
						
					</div>
					<p><?php echo e($product->short_description); ?></p>
					<?php echo Form::open(['url' => 'carts']); ?>

						<?php echo e(Form::hidden('product_id', $product->id)); ?>

						<?php if($product->configurable()): ?>
							<div class="quick-view-select">
								<div class="select-option-part">
									<label>Size*</label>
									<?php echo Form::select('size', $sizes , null, ['class' => 'select', 'placeholder' => '- Please Select -', 'required' => true]); ?>

								</div>
								<div class="select-option-part">
									<label>Color*</label>
									<?php echo Form::select('color', $colors , null, ['class' => 'select', 'placeholder' => '- Please Select -', 'required' => true]); ?>

								</div>
							</div>
						<?php endif; ?>

						<div class="quickview-plus-minus">
							<div class="cart-plus-minus">
								<?php echo Form::number('qty', 1, ['class' => 'cart-plus-minus-box', 'placeholder' => 'qty', 'min' => 1]); ?>

							</div>
							<div class="quickview-btn-cart">
								<button type="submit" class="submit contact-btn btn-hover">add to cart</button>
							</div>
							<div class="quickview-btn-wishlist">
								
							</div>
						</div>
					<?php echo Form::close(); ?>

				</div>
			</div>
		</div>
	</div>
</div>
<?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/products/quick_view.blade.php ENDPATH**/ ?>
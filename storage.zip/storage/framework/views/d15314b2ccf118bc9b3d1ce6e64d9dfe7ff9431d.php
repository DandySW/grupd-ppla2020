<div class="col-lg-12">
    <div class="product-wrapper mb-30 single-product-list product-list-right-pr mb-60">
        <div class="product-img list-img-width">
            <a href="<?php echo e(url('cleaning/'. $cleaning->slug)); ?>">
                <?php if($cleaning->cleaningImages->first()): ?>
					<img src="<?php echo e(asset('storage/'.$cleaning->cleaningImages->first()->medium)); ?>" alt="<?php echo e($cleaning->name); ?>">
				<?php else: ?>
					<img src="<?php echo e(asset('themes/ezone/assets/img/product/fashion-colorful/1.jpg')); ?>" alt="<?php echo e($cleaning->name); ?>">
				<?php endif; ?>
            </a>
            <span>hot</span>
            <div class="product-action-list-style">
                <a class="animate-right" title="Quick View" data-toggle="modal" data-target="#exampleModal" href="#">
                    <i class="pe-7s-look"></i>
                </a>
            </div>
        </div>
        <div class="product-content-list">
            <div class="product-list-info">
                <h4><a href="<?php echo e(url('cleaning/'. $cleaning->slug)); ?>"><?php echo e($cleaning->name); ?></a></h4>
                <span><?php echo e(number_format($cleaning->priceLabel())); ?></span>
                <p><?php echo $cleaning->short_description; ?></p>
            </div>
            <div class="product-list-cart-wishlist">
                <div class="product-list-cart">
                    <a class="btn-hover list-btn-style add-to-card" href=""  cleaning-id="<?php echo e($cleaning->id); ?>" cleaning-type="<?php echo e($cleaning->type); ?>" cleaning-slug="<?php echo e($cleaning->slug); ?>">add to cart</a>
                </div>
                <div class="product-list-wishlist">
                    <a class="btn-hover list-btn-wishlist add-to-fav" title="Favorite"  cleaning-slug="<?php echo e($cleaning->slug); ?>" href="">
                        <i class="pe-7s-like"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/cleanings/list_box.blade.php ENDPATH**/ ?>
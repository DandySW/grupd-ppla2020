<div class="col-md-6 col-xl-4">
	<div class="product-wrapper mb-30">
		<div class="product-img">
			<a href="<?php echo e(url('product/'. $product->slug)); ?>">
				<?php if($product->productImages->first()): ?>
					<img src="<?php echo e(asset('storage/'.$product->productImages->first()->path)); ?>" alt="<?php echo e($product->name); ?>">
				<?php else: ?>
					<img src="<?php echo e(asset('themes/ezone/assets/img/product/fashion-colorful/1.jpg')); ?>" alt="<?php echo e($product->name); ?>">
				<?php endif; ?>
			</a>
			<span>hot</span>
			<div class="product-action">
				<a class="animate-left" title="Wishlist" href="#">
					<i class="pe-7s-like"></i>
				</a>
				<a class="animate-top" title="Add To Cart" href="#">
					<i class="pe-7s-cart"></i>
				</a>
				<a class="animate-right" title="Quick View" data-toggle="modal" data-target="#exampleModal" href="#">
					<i class="pe-7s-look"></i>
				</a>
			</div>
		</div>
		<div class="product-content">
			<h4><a href="<?php echo e(url('product/'. $product->slug)); ?>"><?php echo e($product->name); ?></a></h4>
			<span><?php echo e(number_format($product->price_label())); ?></span>
		</div>
	</div>
</div>
<?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/products/grid_box.blade.php ENDPATH**/ ?>
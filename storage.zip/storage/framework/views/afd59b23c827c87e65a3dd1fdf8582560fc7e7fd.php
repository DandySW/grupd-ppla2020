<?php $__env->startSection('content'); ?>

<!-- shopping-cart-area start -->
<div class="cart-main-area pt-95 pb-100">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h3 class="cart-heading">Order Cleaning Services</h3>
				<div class="table-content table-responsive">
					<table>
						<thead>
							<tr>
								<th>No.</th>
								<th>Waktu</th>
								<th>Petugas</th>
								<th>Bukti Pembayaran</th>
							</tr>
						</thead>
						<tbody>
              <?php $__currentLoopData = $ordercleanings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><?php echo e($loop->iteration); ?></td>
											<td>
												<span><?php echo e(\General::datetimeFormat($item->order_date)); ?></span>
											</td>
											<td><?php echo e($item->petugas); ?></td>
                      <td>
                        <a href="<?php echo e(asset('uploads/pembayaran/'.$item->image)); ?>" target="_blank" rel="noopener noreferrer">Lihat Gambar</a>
                      </td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="coupon-all">
						</div>
					</div>
				</div>
				<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</div>
<!-- shopping-cart-area end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.ezone.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/ordercleanings/detailpeternak.blade.php ENDPATH**/ ?>
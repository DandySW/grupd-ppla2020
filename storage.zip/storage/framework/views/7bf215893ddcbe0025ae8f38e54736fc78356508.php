 
 <?php $__env->startSection('content'); ?>

 <!-- checkout-area start -->
 <div class="checkout-area ptb-100">
 	<div class="container">
 		<?php echo $__env->make('admin.partials.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 		<?php echo Form::model($user, ['url' => ['/'], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

    <?php echo csrf_field(); ?>
 		<div class="alert alert-info">
 			<h5>
 				Silahkan upload bukti pembayaran Anda pada form yang tertera dibawah ini!
 			</h5>
 		</div>
 		<div class="row">
 			<div class="col-lg-6 col-md-12 col-12">
 				<div class="checkbox-form">
 					<div class="row">
 						<div class="col-md-6">
 							<div class="checkout-form-list">
 								<label>First Name <span class="required">*</span></label>
 								<?php echo Form::text('first_name', null, ['required' => true]); ?>

 							</div>
 						</div>
 						<div class="col-md-6">
 							<div class="checkout-form-list">
 								<label>Last Name <span class="required">*</span></label>
 								<?php echo Form::text('last_name', null, ['required' => true]); ?>

 							</div>
 						</div>
 						<div class="col-md-12">
 							<div class="checkout-form-list">
 								<label>Address <span class="required">*</span></label>
 								<?php echo Form::text('address1', null, ['required' => true, 'placeholder' => 'Home number and
 								street name']); ?>

 							</div>
 						</div>
 						<div class="col-md-6">
 							<div class="checkout-form-list">
 								<label>Phone <span class="required">*</span></label>
 								<?php echo Form::text('phone', null, ['required' => true, 'placeholder' => 'Phone']); ?>

 							</div>
 						</div>
 						<div class="col-md-6">
 							<div class="checkout-form-list">
 								<label>Email Address </label>
 								<?php echo Form::text('email', null, ['placeholder' => 'Email', 'readonly' => true]); ?>

 							</div>
 						</div>
 					</div>
 				</div>
 			</div>
 			<div class="col-lg-6 col-md-12 col-12">
 				<div class="your-order">
 					<h5>Upload Bukti Pembayaran</h5>
 					<div class="your-order-table table-responsive">
 						<table>
 							<tfoot>
                  <input type="file" name="image">
 							</tfoot>
 						</table>
 					</div>
 				</div>
 			</div>
      <div class="payment-method">
        <div class="payment-accordion">
          <div class="order-button-payment">
            <button type="submit" name="submit" class="btn btn-primary">Kirim</button>
          </div>
        </div>
      </div>
 		</div>
 		<?php echo Form::close(); ?>

 	</div>
 </div>
 <!-- checkout-area end -->
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.ezone.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/paymentcleanings/create.blade.php ENDPATH**/ ?>
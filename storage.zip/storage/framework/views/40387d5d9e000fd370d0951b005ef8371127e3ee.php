<?php if($slides): ?>
	<div class="slider-area">
		<div class="slider-active owl-carousel">
			<?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="single-slider-4 slider-height-6 bg-img" style="background-image: url(<?php echo e(asset('storage/'. $slide->extra_large)); ?>)">
				<div class="container">
					<div class="row">
						<div class="ml-auto col-lg-6">
							<div class="furniture-content fadeinup-animated">
								<h2 class="animated"><?php echo $slide->title; ?></h2>
								<p class="animated"><?php echo e($slide->body); ?></p>

							</div>
						</div>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</div>
	</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/partials/slider.blade.php ENDPATH**/ ?>
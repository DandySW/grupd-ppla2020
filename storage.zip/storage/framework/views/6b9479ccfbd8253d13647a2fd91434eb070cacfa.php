<?php $__env->startSection('content'); ?>

<?php
    $formTitle = !empty($category) ? 'Update' : 'New'
?>

<div class="content">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom">
                        <h2><?php echo e($formTitle); ?> Category</h2>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('partials.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php if(!empty($category)): ?>
                        <?php echo Form::model($category, ['url' => ['categories', $category->id], 'method' => 'PUT']); ?>

                        <?php echo Form::hidden('id'); ?>

                    <?php else: ?>
                        <?php echo Form::open(['url' => 'categories']); ?>

                    <?php endif; ?>
                        <div class="form-group">
                            <?php echo Form::label('name', 'Name'); ?>

                            <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'category name']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('parent_id', 'Parent'); ?>

                            <?php echo General::selectMultiLevel('parent_id', $categories, ['class' => 'form-control', 'selected' => !empty(old('parent_id')) ? old('parent_id') : (!empty($category['parent_id']) ? $category['parent_id'] : ''), 'placeholder' => '-- Choose Category --']); ?>

                        </div>
                        <div class="form-footer pt-5 border-top">
                            <button type="submit" class="btn btn-primary btn-default">Save</button>
                            <a href="<?php echo e(url('categories')); ?>" class="btn btn-secondary btn-default">Back</a>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/categories/form.blade.php ENDPATH**/ ?>
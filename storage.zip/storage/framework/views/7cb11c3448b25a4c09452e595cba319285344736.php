<?php $__env->startSection('content'); ?>

<?php
$formTitle = !empty($cleaning) ? 'Update' : 'New';
$disableInput = !empty($cleaning) ? true : false;
?>

<div class="content">
  <div class="row justify-content-md-center">
    <div class="col-lg-6">
      <div class="card card-default">
        <div class="card-header card-header-border-bottom">
          <h2>Pilih Paket & Petugas</h2>
        </div>
        <div class="card-body">
          <fieldset class="form-group">
            <div class="row">
              <div class="col-lg-12">
                <form action="<?php echo e(url('cleanings/store')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <label>Silahkan pilih paket yang Anda inginkan!</label>
                    <select name="cleaning_id" class="form-control <?php if ($errors->has('cleaning_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cleaning_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                      <option value="">- Pilih -</option>
                      <?php $__currentLoopData = $cleanings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cleann): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($cleann->id); ?>"><?php echo e($cleann->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if ($errors->has('cleaning_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cleaning_id'); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>
                  <div class="form-group">
                    <label>Silahkan pilih petugas kebersihan yang Anda inginkan!</label>
                    <select name="user_id" class="form-control <?php if ($errors->has('user_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('user_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                      <option value="">- Pilih -</option>
                      <?php $__currentLoopData = $user_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($data->id); ?>"><?php echo e($data->first_name); ?> <?php echo e($data->last_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if ($errors->has('user_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('user_id'); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>
                </div>
              </div>
            </fieldset>
            <div class="form-footer pt-5 border-top">
              <button type="submit" class="btn btn-success center-block">Save</button>
            </div>
            <?php echo Form::close(); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.ezone.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/cleanings/form.blade.php ENDPATH**/ ?>
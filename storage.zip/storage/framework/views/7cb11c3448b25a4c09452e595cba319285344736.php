<?php $__env->startSection('content'); ?>

<?php
$formTitle = !empty($cleaning) ? 'Update' : 'New';
$disableInput = !empty($cleaning) ? true : false;
?>

<div class="content">
    <div class="row">
        <div class="col-lg-6">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom">
                    <h2>Pilih Paket & Petugas</h2>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('themes.ezone.partials.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php if(!empty($cleaning)): ?>
                    <?php echo Form::model($attribute, ['url' => ['cleanings', $cleaning->id], 'method' => 'PUT']); ?>

                    <?php echo Form::hidden('id'); ?>

                    <?php else: ?>
                    <?php echo Form::open(['url' => 'cleanings']); ?>

                    <?php endif; ?>
                    <fieldset class="form-group">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- <legend class="col-form-label pt-0">General</legend> -->
                                <!-- <div class="form-group">
                                        <?php echo Form::label('code', 'Code'); ?>

                                        <?php echo Form::text('code', null, ['class' => 'form-control', 'readonly' => $disableInput]); ?>

                                    </div> -->
                                <!-- <div class="form-group">
                                        <?php echo Form::label('name', 'Name'); ?>

                                        <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

                                    </div> -->
                                <div class="form-group">

                                </div>
                                <div class="form-group">
                                    <select id="user" name="user">
                                        <option selected>Pilih Paket</option>
                                        <?php $__currentLoopData = $cleanings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cleaning): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cleaning->id); ?>"><?php echo e($cleaning->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select id="user" name="user">
                                        <option selected>Pilih Petugas</option>
                                        <?php $__currentLoopData = $user_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($data->id); ?>"><?php echo e($data->first_name); ?> <?php echo e($data->last_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">

                        </div>
                    </fieldset>
                    <fieldset class="form-group">
                        <div class="row">

                        </div>
                    </fieldset>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Save</button>
                        <a href="<?php echo e(url('cleanings')); ?>" class="btn btn-secondary btn-default">Back</a>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.ezone.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/cleanings/form.blade.php ENDPATH**/ ?>
<div class="col-md-6 col-xl-4">
	<div class="product-wrapper mb-30">
		<div class="product-img">
			<a href="<?php echo e(url('cleaning/'. $cleaning->slug)); ?>">
				<?php if($cleaning->cleaningImages->first()): ?>
					<img src="<?php echo e(asset('storage/'.$cleaning->cleaningImages->first()->medium)); ?>" alt="<?php echo e($cleaning->name); ?>">
				<?php else: ?>
					<img src="<?php echo e(asset('themes/ezone/assets/img/product/fashion-colorful/1.jpg')); ?>" alt="<?php echo e($cleaning->name); ?>">
				<?php endif; ?>
			</a>

			<div class="product-action">

				<a class="animate-top add-to-card" title="Add To Cart" href="" cleaning-id="<?php echo e($cleaning->id); ?>" cleaning-type="<?php echo e($cleaning->type); ?>" cleaning-slug="<?php echo e($cleaning->slug); ?>">
					<i class="pe-7s-cart"></i>
				</a>
				<a class="animate-right quick-view" title="Quick View" cleaning-slug="<?php echo e($cleaning->slug); ?>" href="">
					<i class="pe-7s-look"></i>
				</a>
			</div>
		</div>
		<div class="product-content">
			<h4><a href="<?php echo e(url('cleaning/'. $cleaning->slug)); ?>"><?php echo e($cleaning->name); ?></a></h4>
			<span><?php echo e(number_format($cleaning->priceLabel())); ?></span>
		</div>
	</div>
</div>
<?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/cleanings/grid_box.blade.php ENDPATH**/ ?>
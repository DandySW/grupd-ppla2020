<?php $__env->startSection('content'); ?>

<!-- shopping-cart-area start -->
<div class="cart-main-area pt-95 pb-100">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h1 class="cart-heading">Detail Order Cleaning</h1>
				<div class="table-content table-responsive">
					<table>
						<thead>
							<tr>
								<th>Paket</th>
								<th>Price</th>
								<th>Petugas</th>
							</tr>
						</thead>
						<tbody>
							
							<tr>
								<td name="paket"><?php echo e($detail->name); ?></td>
								<td name="price"><?php echo e(number_format($detail->price)); ?></td>
								<td name="petugas"><?php echo e($detail->first_name); ?> <?php echo e($detail->last_name); ?>

								</td>
							</tr>
							
						</tbody>
					</table>
				</div>
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="coupon-all">
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-5 ml-auto">
						<div class="cart-page-total">
							<h2>Total</h2>
							<ul>
								<li>Subtotal<span><?php echo e(number_format($detail->price)); ?></span></li>
							</ul>
							<a href="<?php echo e(url('ordercleanings/checkout')); ?>">Proceed to checkout</a>
						</div>
					</div>
				</div>
				<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</div>
<!-- shopping-cart-area end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.ezone.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/cleanings/detailorder.blade.php ENDPATH**/ ?>
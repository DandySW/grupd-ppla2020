<?php $__env->startSection('content'); ?>

	<!-- shopping-cart-area start -->
	<div class="cart-main-area pt-95 pb-100">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<h1 class="cart-heading">Detail Order Cleaning</h1>
						<div class="table-content table-responsive">
							<table>
								<thead>
									<tr>
										<th>Paket</th>
										<th>Price</th>
										<th>Petugas</th>
										<th>Total</th>
									</tr>
								</thead>
								<tbody>
									<?php $__empty_1 = true; $__currentLoopData = $cleaning; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clean): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
											<tr>
													<td><?php echo e($clean[0]->name); ?></td>
													<td><?php echo e(number_format($clean[0]->price)); ?></td>
													<td>#</td>
													<td><?php echo e(number_format($clean[0]->price)); ?></td>
											</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
											<tr>
													<td colspan="7">No records found</td>
											</tr>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="coupon-all">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-5 ml-auto">
								<div class="cart-page-total">
									<!-- <h2>Cart totals</h2> -->
									<!-- <ul>
										<li>Subtotal<span><?php echo e(number_format(\Cart::getSubTotal())); ?></span></li>
										<li>Total<span><?php echo e(number_format(\Cart::getTotal())); ?></span></li>
									</ul> -->
									<a href="<?php echo e(url('orders/checkout')); ?>">Proceed to checkout</a>
								</div>
							</div>
						</div>
					<?php echo Form::close(); ?>

				</div>
			</div>
		</div>
	</div>
	<!-- shopping-cart-area end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.ezone.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/cleanings/detailorder.blade.php ENDPATH**/ ?>
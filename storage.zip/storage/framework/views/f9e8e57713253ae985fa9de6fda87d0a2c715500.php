<div class="shop-sidebar mr-50">
    <form method="GET" action="<?php echo e(url('cleanings')); ?>">

    </form>

    <?php if($categorycleanings): ?>
		<div class="sidebar-widget mb-45">
			<h3 class="sidebar-title">Categories Cleaning</h3>
			<div class="sidebar-categories">
				<ul>
					<?php $__currentLoopData = $categorycleanings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorycleaning): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><a href="<?php echo e(url('cleanings?categorycleaning='. $categorycleaning->slug)); ?>"><?php echo e($categorycleaning->name); ?></a></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		</div>
	<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/cleanings/sidebar.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="row justify-content-center">
        <div class="col-lg-3">
            <?php echo $__env->make('products.product_menus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-lg-8">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom">
                        <h2>Upload Images</h2>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('partials.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo Form::open(['url' => ['products/images', $product->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                    <div class="form-group">
                        <?php echo Form::label('image', 'Product Image'); ?>

                        <?php echo Form::file('image', ['class' => 'form-control-file', 'placeholder' => 'product image']); ?>

                    </div>
                    <div class="form-footer pt-5 border-top">
                        <button type="submit" class="btn btn-primary btn-default">Save</button>
                        <a href="<?php echo e(url('products/{productID}/add-image')); ?>" class="btn btn-secondary btn-default">Back</a>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/products/image_form.blade.php ENDPATH**/ ?>
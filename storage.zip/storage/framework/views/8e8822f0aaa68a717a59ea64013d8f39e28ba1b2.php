<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="row justify-content-center">
    <div class="col-lg-8">
      <div class="card card-default">
        <div class="card-body">
          <?php echo $__env->make('themes.ezone.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <h4 class="row justify-content-center"><strong>Ketentuan Paket</strong></h4>
              <?php $__currentLoopData = $ketentuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <textarea readonly><?php echo e($item->isi); ?></textarea>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.ezone.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/pakets/index.blade.php ENDPATH**/ ?>
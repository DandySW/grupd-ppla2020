<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-default">
        <div class="card-header card-header-border-bottom">
          <h2>Order Cleaning Service</h2>
        </div>
        <div class="card-body">
          <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <table class="table table-bordered table-striped">
            <thead>
              <th>No.</th>
              <th>Paket</th>
              <th>Price</th>
              <th>Status</th>
              <th style="width:15%">Action</th>
            </thead>
            <tbody>

            </tbody>
          </table>

        </div>

        <div class="card-footer text-right">
          <a href="#" class="btn btn-primary">Add New</a>
        </div>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/admin/ordercleanings/index.blade.php ENDPATH**/ ?>
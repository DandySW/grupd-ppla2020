<?php $__env->startSection('content'); ?>

<?php
    $formTitle = !empty($cleaning) ? 'Update' : 'New'
?>

<div class="content">
    <div class="row">
        <div class="col-lg-3">
            <?php echo $__env->make('admin.cleanings.cleaning_menus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-lg-9">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom">
                        <h2><?php echo e($formTitle); ?> Cleaning</h2>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('admin.partials.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php if(!empty($cleaning)): ?>
                        <?php echo Form::model($cleaning, ['url' => ['admin/cleanings', $cleaning->id], 'method' => 'PUT']); ?>

                        <?php echo Form::hidden('id'); ?>

                        <?php echo Form::hidden('type'); ?>

                    <?php else: ?>
                        <?php echo Form::open(['url' => 'admin/cleanings']); ?>

                    <?php endif; ?>
                        <div class="form-group">
                            <?php echo Form::label('type', 'Type'); ?>

                            <?php echo Form::select('type', $types , !empty($cleaning) ? $cleaning->type : null, ['class' => 'form-control cleaning-type', 'placeholder' => '-- Choose Cleaning Type --', 'disabled' => !empty($cleaning)]); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('sku', 'SKU'); ?>

                            <?php echo Form::text('sku', null, ['class' => 'form-control', 'placeholder' => 'sku']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('name', 'Name'); ?>

                            <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'name']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('categorycleaning_ids', 'CategoryCleaning'); ?>

                            <?php echo General::selectMultiLevel('categorycleaning_ids[]', $categorycleanings, ['class' => 'form-control', 'multiple' => true, 'selected' => !empty(old('categorycleaning_ids')) ? old('categorycleaning_ids') : $categorycleaningIDs, 'placeholder' => '-- Choose Category --']); ?>

                        </div>
                                <?php echo $__env->make('admin.cleanings.simple', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <div class="form-group">
                                <?php echo Form::label('short_description', 'Short Description'); ?>

                                <?php echo Form::textarea('short_description', null, ['class' => 'form-control', 'placeholder' => 'short description']); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('description', 'Description'); ?>

                                <?php echo Form::textarea('description', null, ['class' => 'form-control', 'placeholder' => 'description']); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('status', 'Status'); ?>

                                <?php echo Form::select('status', $statuses , null, ['class' => 'form-control', 'placeholder' => '-- Set Status --']); ?>

                            </div>

                        <div class="form-footer pt-5 border-top">
                            <button type="submit" class="btn btn-primary btn-default">Save</button>
                            <a href="<?php echo e(url('admin/cleanings')); ?>" class="btn btn-secondary btn-default">Back</a>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/admin/cleanings/form.blade.php ENDPATH**/ ?>
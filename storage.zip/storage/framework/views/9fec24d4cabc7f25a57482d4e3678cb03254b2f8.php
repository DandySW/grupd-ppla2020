<?php $__env->startSection('content'); ?>

<?php
    $formTitle = !empty($cleaning) ? 'Update' : 'New'
?>

<div class="content">
    <div class="row">
        <div class="col-lg-3">

        </div>
        <div class="col-lg-9">
            <div class="card card-default">
                <div class="card-header card-header-border-bottom">
                        <h2><?php echo e($formTitle); ?> Cleaning</h2>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('admin.partials.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php if(!empty($cleaning)): ?>
                        <?php echo Form::model($cleaning, ['url' => ['admin/cleanings', $cleaning->id], 'method' => 'PUT']); ?>

                        <?php echo Form::hidden('id'); ?>

                        <?php echo Form::hidden('type'); ?>

                    <?php else: ?>
                        <?php echo Form::open(['url' => 'admin/cleanings']); ?>

                    <?php endif; ?>
                        <div class="form-group">
                            <?php echo Form::label('name', 'Paket'); ?>

                            <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'name']); ?>

                        </div>
                                <?php echo $__env->make('admin.cleanings.simple', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <div class="form-group">
                                <?php echo Form::label('status', 'Status'); ?>

                                <?php echo Form::select('status', $statuses , null, ['class' => 'form-control', 'placeholder' => '-- Set Status --']); ?>

                            </div>

                        <div class="form-footer pt-5 border-top">
                            <button type="submit" class="btn btn-primary btn-default">Save</button>
                            <a href="<?php echo e(url('admin/cleanings')); ?>" class="btn btn-secondary btn-default">Back</a>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/admin/cleanings/form.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

	<div class="shop-page-wrapper shop-page-padding ptb-100">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-9">
					<?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<div class="login">
						<div class="login-form-container">
							<div class="login-form">
									<?php echo Form::model($user, ['url' => ['admin/profile']]); ?>

									<?php echo csrf_field(); ?>

									<div class="form-group row">
										<div class="col-md-6">
											<?php echo Form::text('first_name', null, ['class' => 'form-control', 'placeholder' => 'First name', 'required' => true]); ?>

											<?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?>
												<span class="invalid-feedback" role="alert">
													<strong><?php echo e($message); ?></strong>
												</span>
											<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
										</div>
										<div class="col-md-6">
											<?php echo Form::text('last_name', null, ['class' => 'form-control', 'placeholder' => 'Last name', 'required' => true]); ?>

											<?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?>
												<span class="invalid-feedback" role="alert">
													<strong><?php echo e($message); ?></strong>
												</span>
											<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
										</div>
									</div>

									<div class="form-group row">
										<div class="col-md-12">
											<?php echo Form::text('company', null, ['class' => 'form-control', 'placeholder' => 'Company']); ?>

											<?php if ($errors->has('company')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('company'); ?>
												<span class="invalid-feedback" role="alert">
													<strong><?php echo e($message); ?></strong>
												</span>
											<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
										</div>
									</div>

									<div class="form-group row">
										<div class="col-md-12">
											<?php echo Form::text('address1', null, ['class' => 'form-control', 'placeholder' => 'Home number and street name']); ?>

											<?php if ($errors->has('address1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address1'); ?>
												<span class="invalid-feedback" role="alert">
													<strong><?php echo e($message); ?></strong>
												</span>
											<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
										</div>
									</div>

									<div class="form-group row">
										<div class="col-md-12">
											<?php echo Form::text('address2', null, ['class' => 'form-control', 'placeholder' => 'Apartment, suite, unit etc. (optional)']); ?>

											<?php if ($errors->has('address2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address2'); ?>
												<span class="invalid-feedback" role="alert">
													<strong><?php echo e($message); ?></strong>
												</span>
											<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
										</div>
									</div>

									<div class="form-group row">
										<div class="col-md-6">
											<?php echo Form::select('province_id', $provinces, Auth::user()->province_id, ['class' => 'form-control', 'id' => 'user-province-id', 'placeholder' => '- Please Select - ', 'required' => true]); ?>

											<?php if ($errors->has('province_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('province_id'); ?>
												<span class="invalid-feedback" role="alert">
													<strong><?php echo e($message); ?></strong>
												</span>
											<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
										</div>
									</div>

									<div class="form-group row">
										<div class="col-md-6">
											<?php echo Form::number('postcode', null, ['class' => 'form-control', 'placeholder' => 'Postcode']); ?>

											<?php if ($errors->has('postcode')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('postcode'); ?>
												<span class="invalid-feedback" role="alert">
													<strong><?php echo e($message); ?></strong>
												</span>
											<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
										</div>
										<div class="col-md-6">
											<?php echo Form::text('phone', null, ['class' => 'form-control', 'placeholder' => 'Phone']); ?>

											<?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
												<span class="invalid-feedback" role="alert">
													<strong><?php echo e($message); ?></strong>
												</span>
											<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
										</div>
									</div>

									<div class="form-group row">
										<div class="col-md-12">
											<?php echo Form::email('email', null, ['class' => 'form-control', 'placeholder' => 'Email', 'required' => true]); ?>

											<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
												<span class="invalid-feedback" role="alert">
													<strong><?php echo e($message); ?></strong>
												</span>
											<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
										</div>
									</div>
									<div class="button-box">
										<button type="submit" class="btn btn-primary">Update Profile</button>
									</div>
								<?php echo Form::close(); ?>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- register-area end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/admin/auth/profile.blade.php ENDPATH**/ ?>
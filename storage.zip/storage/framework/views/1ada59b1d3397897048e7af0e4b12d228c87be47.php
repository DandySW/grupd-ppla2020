<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
            <div class="col-lg-12">
                <div class="card card-default">
                    <div class="card-header card-header-border-bottom">
                        <h2>Category Cleanings</h2>
                    </div>
                    <div class="card-body">
                        <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <table class="table table-bordered table-striped">
                            <thead>
                                <th>No.</th>
                                <th>Name</th>
                                <th>Slug</th>
                                <th>Parent</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $categorycleanings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorycleaning): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($categorycleaning->id); ?></td>
                                        <td><?php echo e($categorycleaning->name); ?></td>
                                        <td><?php echo e($categorycleaning->slug); ?></td>
                                        <td><?php echo e($categorycleaning->parent ? $categorycleaning->parent->name : ''); ?></td>
                                        <td>

                                                <a href="<?php echo e(url('admin/categorycleanings/'. $categorycleaning->id .'/edit')); ?>" class="btn btn-warning btn-sm">edit</a>


                                            <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_categorycleanings')): ?>
                                                <?php echo Form::open(['url' => 'admin/categorycleanings/'. $categorycleaning->id, 'class' => 'delete', 'style' => 'display:inline-block']); ?>

                                                <?php echo Form::hidden('_method', 'DELETE'); ?>

                                                <?php echo Form::submit('remove', ['class' => 'btn btn-danger btn-sm']); ?>

                                                <?php echo Form::close(); ?>

                                            <?php endif; ?> -->
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5">No records found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <?php echo e($categorycleanings->links()); ?>

                    </div>

                        <div class="card-footer text-right">
                            <a href="<?php echo e(url('admin/categorycleanings/create')); ?>" class="btn btn-primary">Add New</a>
                        </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/admin/categorycleanings/index.blade.php ENDPATH**/ ?>
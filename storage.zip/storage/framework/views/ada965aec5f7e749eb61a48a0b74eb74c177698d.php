<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="row justify-content-center">
    <div class="col-lg-3">
      <?php echo $__env->make('attributes.option_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-lg-7">
      <div class="card card-default">
        <div class="card-header card-header-border-bottom">
          <h2>Options for : <?php echo e($attribute->name); ?></h2>
        </div>
        <div class="card-body">
          <table class="table table-bordered table-stripped">
            <thead>
              <th style="width:10%">#</th>
              <th>Name</th>
              <th style="width:30%">Action</th>
            </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $attribute->attributeOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td><?php echo e($option->id); ?></td>
                <td><?php echo e($option->name); ?></td>
                <td>

                  <a href="<?php echo e(url('attributes/options/'. $option->id .'/edit')); ?>" class="btn btn-warning btn-sm">edit</a>

                  <?php echo Form::open(['url' => 'attributes/options/'. $option->id, 'class' => 'delete', 'style' => 'display:inline-block']); ?>

                  <?php echo Form::hidden('_method', 'DELETE'); ?>

                  <?php echo Form::submit('remove', ['class' => 'btn btn-danger btn-sm']); ?>

                  <?php echo Form::close(); ?>


                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="5">No records found</td>
              </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/attributes/options.blade.php ENDPATH**/ ?>
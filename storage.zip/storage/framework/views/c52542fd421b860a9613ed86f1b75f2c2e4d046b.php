<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="row">
			<div class="col-lg-12">
				<div class="card card-default">
					<div class="card-header card-header-border-bottom">
						<h2>Payment Report</h2>
					</div>
					<div class="card-body">
						<?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<table class="table table-bordered table-striped">
							<thead>
								<th>Order ID</th>
								<th>Date</th>
								<th>Status</th>
								<th>Amount</th>
								<th>Gateway</th>
								<th>Payment Type</th>
								<th hidden>Ref</th>
							</thead>
							<tbody>
								<?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<tr>
										<td><?php echo e($payment->code); ?></td>
										<td><?php echo e(\General::datetimeFormat($payment->created_at)); ?></td>
										<td><?php echo e($payment->status); ?></td>
										<td><?php echo e(\General::priceFormat($payment->amount)); ?></td>
										<td><?php echo e($payment->method); ?></td>
										<td><?php echo e($payment->payment_type); ?></td>
										<td hidden><?php echo e($payment->token); ?></td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<tr>
										<td colspan="8">No records found</td>
									</tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sipakan\resources\views/admin/reports/payment.blade.php ENDPATH**/ ?>
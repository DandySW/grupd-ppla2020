<div class="shop-sidebar mr-50">
    <form method="GET" action="<?php echo e(url('products')); ?>">

    </form>

    <?php if($categories): ?>
		<div class="sidebar-widget mb-45">
			<h3 class="sidebar-title">Categories</h3>
			<div class="sidebar-categories">
				<ul>
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><a href="<?php echo e(url('products?category='. $category->slug)); ?>"><?php echo e($category->name); ?></a></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		</div>
	<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/products/sidebar.blade.php ENDPATH**/ ?>
<div class="header-cart">
	<a class="icon-cart-furniture" href="<?php echo e(url('carts')); ?>">
		<i class="ti-shopping-cart"></i>
		<span class="shop-count-furniture green"><?php echo e(\Cart::getTotalQuantity()); ?></span>
	</a>
	<?php if(!\Cart::isEmpty()): ?>
		<ul class="cart-dropdown">
			<?php $__currentLoopData = \Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php
					$product = isset($item->associatedModel->parent) ? $item->associatedModel->parent : $item->associatedModel;
					$image = !empty($product->productImages->first()) ? asset('storage/'.$product->productImages->first()->path) : asset('themes/ezone/assets/img/cart/3.jpg')
				?>
				<li class="single-product-cart">
					<div class="cart-img">
						<a href="<?php echo e(url('product/'. $product->slug)); ?>"><img src="<?php echo e($image); ?>" alt="<?php echo e($product->name); ?>" style="width:100px"></a>
					</div>
					<div class="cart-title">
						<h5><a href="<?php echo e(url('product/'. $product->slug)); ?>"><?php echo e($item->name); ?></a></h5>
						<span><?php echo e(number_format($item->price)); ?> x <?php echo e($item->quantity); ?></span>
					</div>
					<div class="cart-delete">
						<a href="<?php echo e(url('carts/remove/'. $item->id)); ?>" class="delete"><i class="ti-trash"></i></a>
					</div>
				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<li class="cart-space">
				<div class="cart-sub">
					<h4>Subtotal</h4>
				</div>
				<div class="cart-price">
					<h4><?php echo e(number_format(\Cart::getSubTotal())); ?></h4>
				</div>
			</li>
			<li class="cart-btn-wrapper">
				<a class="cart-btn btn-hover" href="<?php echo e(url('carts')); ?>">view cart</a>
				<a class="cart-btn btn-hover" href="<?php echo e(url('orders/checkout')); ?>">checkout</a>
			</li>
		</ul>
	<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\sipakan\resources\views/themes/ezone/partials/mini_cart.blade.php ENDPATH**/ ?>
<!-- Header -->
<header class="main-header " id="header">
            <nav class="navbar navbar-static-top navbar-expand-lg">
              <!-- Sidebar toggle button -->
              <button id="sidebar-toggler" class="sidebar-toggle">
                <span class="sr-only">Toggle navigation</span>
              </button>
              <!-- search form -->
              <div class="search-form d-none d-lg-inline-block">
                <div class="input-group">

                </div>
                <div id="search-results-container">
                  <ul id="search-results"></ul>
                </div>
              </div>

              <div class="navbar-right ">
                <ul class="nav navbar-nav">

                  <!-- User Account -->
                  <li class="dropdown user-menu">
                    <button href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
                      <span class="d-none d-lg-inline-block">Hello, Worker!</span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-right">
                      <!-- User image -->

                      <li>
                        <a href="<?php echo e(url('worker/profile')); ?>">
                          <i class="mdi mdi-account"></i> My Profile
                        </a>
                      </li>

                      <li class="dropdown-footer">
                        <a href="<?php echo e(route('logout')); ?>"
          								onclick="event.preventDefault();
          											document.getElementById('logout-form').submit();"><i class="mdi mdi-logout"></i>
          								<?php echo e(__('Logout')); ?>

          							</a>

          							<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
          								<?php echo csrf_field(); ?>
          							</form>
                      </li>
                    </ul>
                  </li>
                </ul>
              </div>
            </nav>


          </header>
<?php /**PATH C:\xampp\htdocs\sipakan\resources\views/worker/partials/header.blade.php ENDPATH**/ ?>